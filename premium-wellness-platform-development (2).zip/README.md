# MASAR مسار — Post-bac orientation for Morocco

Bilingual (FR/AR, RTL-ready) single-page app that tells a Moroccan baccalaureate
student, from their stream and grades, where they can realistically study:
thresholds, application steps, deadlines and scholarships.

## Run it in 2 minutes

```bash
npm install
npm run dev        # → http://localhost:5173
npm run build      # production bundle → dist/
npx vitest run     # 13 unit tests for the score logic
```

## Architecture

| Layer | Choice | Reason / deviation note |
| --- | --- | --- |
| Stack | React 19 + Vite + TypeScript | Deviation from Next.js: this environment ships a single static file. The data layer is shaped like DB rows (typed records with `sourceId` + `verifiedAt`) so it ports to Postgres/Drizzle unchanged. |
| Routing | `react-router` HashRouter | Static single-file hosting has no server rewrites. |
| Styling | Tailwind CSS 4, tokens in `src/index.css`, light + dark themes (`html.dark`), full RTL via `html[dir]`. |
| Charts | Custom accessible SVG (`TrendChart`, `Sparkline`) | Kept over ECharts for the ≤90 performance budget on mid-range phones. |
| Maps | OpenStreetMap `<iframe>` embeds | No API key, works offline-ish; swap to MapLibre when bundling constraints relax. |
| i18n | `src/i18n.tsx` dictionary (FR + AR), `pick()` for bilingual records | EN can be added as a third dictionary entry set. |
| Search | Norm + aliases (`src/utils/search.ts`) — accent/Arabic-diacritic insensitive, typo-tolerant prefixes, latin & Arabic spellings (ENSA/ensa/إنسا). | Replace with Typesense server-side later; same normaliser. |
| Persistence | `localStorage` only (shortlist, compare, lang, theme, reports, audit demo) | No account by design — minors are core users (law 09-08). |

## Data accuracy rules (enforced in code)

- `src/data/scoring.ts` is the **only** place scores are computed — pure functions,
  unit-tested (`scoring.test.ts`): formula weights validated, missing inputs →
  `null` (never guessed), three verdict groups with exact margins.
- Threshold records are per-year, never overwritten; preselection and final
  cut-offs are separate stages and never mixed in one column or chart.
- `null` everywhere means **Not published** / **غير منشور** — rendered as such.
- Every fact links to a `Source` (publisher, URL, retrieval date) and shows an
  **EXEMPLE** badge while the dataset is demo data.
- Admin demo (`/admin`): CSV import with validation (scale bounds, official
  stream list, year range, duplicate rejection), local audit log, error-report
  queue fed by the "Signaler une erreur" buttons.

## Before launch (currently false by design)

- Replace all `confidence: "example"` records with official figures
  (Cursussup, concours sites, Minhaty, school sites, official PDFs) — the
  pipeline is: collect → extract (PDF/OCR AR+FR) → validate → human review → publish.
- Re-check the Minhaty amounts (2024-25 press figures; rules change 2025-26).
- Native-Arabic review of AR pages, Lighthouse ≥ 90 mobile, axe pass,
  remove the EXAMPLE banner, real domain + analytics/monitoring.
- Phase 2 (behind a flag): retrieval-only orientation assistant citing pages,
  natural-language search → filters, AI PDF extraction drafts with human approval.
