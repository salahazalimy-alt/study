import { useCallback, useEffect, useState } from "react";

/** Local-only stores (no account). Cross-component sync via storage events. */

function useStringSet(key: string) {
  const [items, setItems] = useState<string[]>(() => {
    try {
      return JSON.parse(localStorage.getItem(key) ?? "[]") as string[];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    const onStorage = (e: StorageEvent) => {
      if (e.key === key) {
        try { setItems(JSON.parse(e.newValue ?? "[]")); } catch { /* ignore */ }
      }
    };
    const onCustom = () => {
      try { setItems(JSON.parse(localStorage.getItem(key) ?? "[]")); } catch { /* ignore */ }
    };
    window.addEventListener("storage", onStorage);
    window.addEventListener("masar-store", onCustom);
    return () => {
      window.removeEventListener("storage", onStorage);
      window.removeEventListener("masar-store", onCustom);
    };
  }, [key]);

  const write = useCallback((next: string[]) => {
    setItems(next);
    try { localStorage.setItem(key, JSON.stringify(next)); } catch { /* ignore */ }
    window.dispatchEvent(new Event("masar-store"));
  }, [key]);

  const toggle = useCallback(
    (id: string, max = Infinity): { ok: boolean; items: string[] } => {
      let next: string[];
      if (items.includes(id)) next = items.filter((x) => x !== id);
      else if (items.length >= max) return { ok: false, items };
      else next = [...items, id];
      write(next);
      return { ok: true, items: next };
    },
    [items, write]
  );

  const set = useCallback((ids: string[]) => write(ids), [write]);

  return { items, toggle, set, has: (id: string) => items.includes(id) };
}

export const useShortlist = () => useStringSet("masar:shortlist");
export const useCompare = () => useStringSet("masar:compare");

export function loadIdsFromQuery(searchWithinHash: string): string[] {
  const m = searchWithinHash.match(/ids=([a-z0-9,-]+)/i);
  return m ? m[1].split(",").filter(Boolean) : [];
}
