import { describe, expect, it } from "vitest";
import {
  EVENTS, FORMULAS, INSTITUTIONS, PROGRAMMES, RULES, SCHOLARSHIPS, SOURCES, THRESHOLDS,
} from "./records";
import { STREAMS } from "./types";

const streamKeys = new Set(STREAMS.map((s) => s.key));
const ruleIds = new Set(RULES.map((r) => r.id));
const instIds = new Set(INSTITUTIONS.map((i) => i.id));
const progIds = new Set(PROGRAMMES.map((p) => p.id));
const sourceIds = new Set(SOURCES.map((s) => s.id));

describe("data integrity (pipeline validation mirror)", () => {
  it("every formula's weights sum to 1", () => {
    for (const f of FORMULAS) {
      expect(Math.abs(f.inputs.reduce((s, i) => s + i.weight, 0) - 1)).toBeLessThan(0.001);
    }
  });
  it("every threshold references an existing rule + official stream + source", () => {
    for (const th of THRESHOLDS) {
      expect(ruleIds.has(th.ruleId), th.ruleId).toBe(true);
      expect(streamKeys.has(th.stream)).toBe(true);
      expect(sourceIds.has(th.sourceId)).toBe(true);
    }
  });
  it("scores stay within the /20 scale", () => {
    for (const th of THRESHOLDS) {
      if (th.value !== null) expect(th.value, JSON.stringify(th)).toBeGreaterThan(0);
      if (th.value !== null) expect(th.value).toBeLessThanOrEqual(th.scale);
    }
  });
  it("no duplicated ruleId+stream+year+stage", () => {
    const seen = new Set<string>();
    for (const th of THRESHOLDS) {
      const k = `${th.ruleId}|${th.stream}|${th.year}|${th.stage}`;
      expect(seen.has(k), k).toBe(false);
      seen.add(k);
    }
  });
  it("rules reference existing programmes and formulas", () => {
    for (const r of RULES) {
      expect(progIds.has(r.programmeId)).toBe(true);
      if (r.formulaId) expect(FORMULAS.some((f) => f.id === r.formulaId)).toBe(true);
    }
  });
  it("programmes link to institutions; events link to real institutions or platforms", () => {
    for (const p of PROGRAMMES) expect(instIds.has(p.institutionId)).toBe(true);
    for (const e of EVENTS) if (e.institutionId) expect(instIds.has(e.institutionId)).toBe(true);
  });
  it("every demo figure is explicitly tagged example", () => {
    for (const th of THRESHOLDS) expect(th.confidence).toBe("example");
  });
  it("scholarship amounts, when published, are positive MAD figures", () => {
    for (const s of SCHOLARSHIPS) {
      expect(sourceIds.has(s.sourceId)).toBe(true);
      if (s.amountMAD !== null) expect(s.amountMAD).toBeGreaterThan(0);
    }
  });
  it("dates are ISO-shaped and deadlines precede exams where both exist", () => {
    for (const r of RULES) {
      expect(r.registrationDeadline).toMatch(/^\d{4}-\d{2}-\d{2}$/);
      if (r.examDate) expect(r.examDate > r.registrationDeadline, r.id).toBe(true);
    }
  });
});
