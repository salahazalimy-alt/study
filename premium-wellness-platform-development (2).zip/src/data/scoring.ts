/**
 * Score logic — ONE pure module shared by UI and tests.
 *
 * Rules honoured here:
 * - Formulas are data: inputs + weights + scale. Nothing hard-coded per school.
 * - A missing input means we cannot compute → we say so, never guess.
 * - Past thresholds are facts about the past: callers must label them
 *   "last year's threshold". Classification is guidance, never a promise.
 */

import type { AdmissionRule, BacStream, Formula, Threshold } from "./types";

export interface ScoreInputs {
  overall?: number | null; // bac overall average /20
  national?: number | null; // national exam /20
  regional?: number | null; // regional exam /20
}

/** Which inputs a formula actually needs (checker asks only for these). */
export function requiredInputs(formulas: Formula[], formulaIds: string[]): Formula["inputs"][number]["key"][] {
  const keys = new Set<Formula["inputs"][number]["key"]>();
  for (const id of formulaIds) {
    const f = formulas.find((x) => x.id === id);
    if (f) for (const inp of f.inputs) keys.add(inp.key);
  }
  return [...keys];
}

/**
 * Evaluate a formula. Returns null when a required input is missing and
 * throws on weights that don't sum to ~1 (a data-integrity error).
 */
export function computeScore(formula: Formula, inputs: ScoreInputs): number | null {
  const total = formula.inputs.reduce((s, i) => s + i.weight, 0);
  if (Math.abs(total - 1) > 0.001) {
    throw new Error(`Formula ${formula.id}: weights must sum to 1 (got ${total})`);
  }
  let value = 0;
  for (const inp of formula.inputs) {
    const raw = inputs[inp.key];
    if (raw === null || raw === undefined || Number.isNaN(raw)) return null;
    if (raw < 0 || raw > 20) return null; // out of bac scale
    value += raw * inp.weight;
  }
  // nudge float noise
  return Math.round(value * 100) / 100;
}

export type Verdict = "strong" | "possible" | "outOfReach" | "notPublished";

export interface VerdictResult {
  verdict: Verdict;
  /** student score minus threshold, both on the same scale. null if unknown. */
  gap: number | null;
  threshold: Threshold | null;
  computed: number | null;
}

const STRONG_MARGIN = 0.5;
const POSSIBLE_MARGIN = -1;

/**
 * Classify a student against the LATEST published threshold for a rule+stream.
 * `stage` selects preselection vs final cut-off (never mixed).
 */
export function classify(
  computed: number | null,
  thresholds: Threshold[],
  stream: BacStream,
  stage: Threshold["stage"]
): VerdictResult {
  const relevant = thresholds
    .filter((t) => t.stream === stream && t.stage === stage && t.value !== null)
    .sort((a, b) => b.year - a.year);
  const latest = relevant[0] ?? null;
  if (!latest || latest.value === null || computed === null) {
    return { verdict: "notPublished", gap: null, threshold: latest ?? null, computed };
  }
  const gap = Math.round((computed - latest.value) * 100) / 100;
  const verdict: Verdict =
    gap >= STRONG_MARGIN ? "strong" : gap >= POSSIBLE_MARGIN ? "possible" : "outOfReach";
  return { verdict, gap, threshold: latest, computed };
}

/** Which stage should the checker compare against for a route. */
export function stageForRoute(route: AdmissionRule["route"]): Threshold["stage"] {
  return route === "preselection-exam" || route === "open" ? "preselection" : "final";
}

/** Threshold history for a rule+stream, ascending by year, nulls kept for gaps. */
export function history(thresholds: Threshold[], ruleId: string, stream: BacStream, stage: Threshold["stage"]) {
  return thresholds
    .filter((t) => t.ruleId === ruleId && t.stream === stream && t.stage === stage)
    .sort((a, b) => a.year - b.year);
}

export const fmtScore = (v: number | null | undefined, locale: string): string =>
  v === null || v === undefined
    ? "—"
    : new Intl.NumberFormat(locale, { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(v);

export const fmtGap = (gap: number, locale: string): string => {
  const n = new Intl.NumberFormat(locale, { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(Math.abs(gap));
  return gap >= 0 ? `+${n}` : `−${n}`;
};
