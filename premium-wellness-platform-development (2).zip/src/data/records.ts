/**
 * DATASET — labelled EXAMPLE.
 * Every numeric record ships with confidence "example", a source pointer and
 * a last-verified date, and renders an on-screen EXEMPLE badge. The pipeline
 * (official pages → extract → validate → human review → publish) must replace
 * these with official figures before launch. Nothing here may reach production.
 *
 * State scholarship amounts below are the 2024-25 press-report figures the
 * product brief asked us to use for model testing only.
 */

import type {
  AdmissionRule, BacStream, CalendarEvent, Formula, Institution,
  Programme, Scholarship, Source, Threshold, ThresholdKind, ThresholdStage,
} from "./types";

const VERIFIED = "2026-01-12";

/* -------------------------------- sources ------------------------------- */
export const SOURCES: Source[] = [
  { id: "src-cursussup", publisher_fr: "Plateforme nationale Cursussup", publisher_ar: "المنصة الوطنية كورسوسوب", docType: "page", url: "https://www.cursussup.gov.ma", retrievedAt: VERIFIED },
  { id: "src-enssup", publisher_fr: "Ministère de l'Enseignement Supérieur", publisher_ar: "وزارة التعليم العالي", docType: "announcement", url: "https://www.enssup.gov.ma", retrievedAt: VERIFIED },
  { id: "src-minhaty", publisher_fr: "ONOUSC — plateforme Minhaty", publisher_ar: "المكتب الوطني للأعمال الجامعية — منحتي", docType: "page", url: "https://www.minhaty.ma", retrievedAt: VERIFIED },
  { id: "src-press-2024", publisher_fr: "Presse nationale, rapport 2024-25 (montants à re-vérifier)", publisher_ar: "الصحافة الوطنية، تقرير 2024-25 (المبالغ تحتاج إعادة تحقق)", docType: "press", url: "https://www.minhaty.ma", retrievedAt: VERIFIED },
  { id: "src-ensa-net", publisher_fr: "Réseau national des ENSA — pages concours", publisher_ar: "الشبكة الوطنية لمدارس ENSA", docType: "page", url: "https://www.cursussup.gov.ma", retrievedAt: VERIFIED },
  { id: "src-encg-net", publisher_fr: "Réseau national des ENCG", publisher_ar: "الشبكة الوطنية لمدارس ENCG", docType: "page", url: "https://www.cursussup.gov.ma", retrievedAt: VERIFIED },
  { id: "src-fst-net", publisher_fr: "Réseau des FST", publisher_ar: "شبكة كليات العلوم والتقنيات", docType: "page", url: "https://www.cursussup.gov.ma", retrievedAt: VERIFIED },
  { id: "src-est-net", publisher_fr: "Réseau des EST", publisher_ar: "شبكة المدارس العليا للتكنولوجيا", docType: "page", url: "https://www.cursussup.gov.ma", retrievedAt: VERIFIED },
  { id: "src-um6ss", publisher_fr: "Université Mohammed VI des Sciences de la Santé", publisher_ar: "جامعة محمد السادس للعلوم الصحية", docType: "page", url: "https://www.um6ss.ma", retrievedAt: VERIFIED },
  { id: "src-uir", publisher_fr: "Université Internationale de Rabat", publisher_ar: "الجامعة الدولية للرباط", docType: "page", url: "https://www.uir.ac.ma", retrievedAt: VERIFIED },
  { id: "src-uic", publisher_fr: "Université Internationale de Casablanca", publisher_ar: "جامعة الدار البيضاء الدولية", docType: "page", url: "https://www.uic.ac.ma", retrievedAt: VERIFIED },
  { id: "src-ofppt", publisher_fr: "OFPPT", publisher_ar: "مكتب التكوين المهني", docType: "page", url: "https://www.ofppt.ma", retrievedAt: VERIFIED },
  { id: "src-iav", publisher_fr: "Institut Agronomique et Vétérinaire Hassan II", publisher_ar: "معهد الحسن الثاني للزراعة والبيطرة", docType: "page", url: "https://www.iav.ac.ma", retrievedAt: VERIFIED },
  { id: "src-med-concours", publisher_fr: "Concours commun médecine, pharmacie, médecine dentaire", publisher_ar: "المباراة المشتركة للطب والصيدلة وطب الأسنان", docType: "announcement", url: "https://www.enssup.gov.ma", retrievedAt: VERIFIED },
];

/* -------------------------------- formulas ------------------------------ */
export const FORMULAS: Formula[] = [
  { id: "f-n75-r25", label_fr: "75% examen national + 25% examen régional", label_ar: "75٪ الامتحان الوطني + 25٪ الامتحان الجهوي", inputs: [{ key: "national", weight: 0.75 }, { key: "regional", weight: 0.25 }], scale: 20 },
  { id: "f-n80-r20", label_fr: "80% examen national + 20% examen régional", label_ar: "80٪ الامتحان الوطني + 20٪ الامتحان الجهوي", inputs: [{ key: "national", weight: 0.8 }, { key: "regional", weight: 0.2 }], scale: 20 },
  { id: "f-avg50-n50", label_fr: "50% moyenne générale + 50% examen national", label_ar: "50٪ المعدل العام + 50٪ الامتحان الوطني", inputs: [{ key: "overall", weight: 0.5 }, { key: "national", weight: 0.5 }], scale: 20 },
  { id: "f-nat", label_fr: "Examen national uniquement", label_ar: "الامتحان الوطني فقط", inputs: [{ key: "national", weight: 1 }], scale: 20 },
];

/* ----------------------------- institutions ----------------------------- */
const I = (partial: Omit<Institution, "lat" | "lng"> & { lat: number; lng: number }): Institution => partial;

export const INSTITUTIONS: Institution[] = [
  I({ id: "fmp-rabat", name_fr: "Faculté de Médecine et de Pharmacie de Rabat", name_ar: "كلية الطب والصيدلة بالرباط", short_fr: "FMP Rabat", short_ar: "كلية الطب الرباط", aliases: ["fmp rabat", "medecine rabat", "كلية الطب", "طب الرباط"], category_fr: "Médecine, pharmacie, dentaire", category_ar: "الطب والصيدلة وطب الأسنان", categoryKey: "medicine", sector: "public", city_fr: "Rabat", city_ar: "الرباط", region_key: "rabat-sale", lat: 34.008, lng: -6.853, website: "https://www.enssup.gov.ma", recognition_fr: "Université publique", recognition_ar: "جامعة عمومية", lastVerified: VERIFIED, sourceId: "src-med-concours", about_fr: "Faculté publique de médecine. Admission par concours national commun avec présélection sur une formule combinant l'examen national et l'examen régional.", about_ar: "كلية طب عمومية. الدخول عبر مباراة وطنية مشتركة مع انتقاء أولي حسب نقطة تجمع الامتحان الوطني والجهوي." }),
  I({ id: "fmp-casa", name_fr: "Faculté de Médecine et de Pharmacie de Casablanca", name_ar: "كلية الطب والصيدلة بالدار البيضاء", short_fr: "FMP Casablanca", short_ar: "كلية الطب الدار البيضاء", aliases: ["fmp casa", "medecine casablanca", "طب كازا"], category_fr: "Médecine, pharmacie, dentaire", category_ar: "الطب والصيدلة وطب الأسنان", categoryKey: "medicine", sector: "public", city_fr: "Casablanca", city_ar: "الدار البيضاء", region_key: "casa-settat", lat: 33.589, lng: -7.612, website: "https://www.enssup.gov.ma", recognition_fr: "Université publique", recognition_ar: "جامعة عمومية", lastVerified: VERIFIED, sourceId: "src-med-concours", about_fr: "Faculté publique de médecine, concours national commun, présélection par note de bac pondérée.", about_ar: "كلية طب عمومية بالدار البيضاء، مباراة وطنية مشتركة مع انتقاء أولي بالنقطة الموزونة." }),
  I({ id: "fsjes-casa", name_fr: "Faculté des Sciences Juridiques, Économiques et Sociales — Aïn Sebaâ", name_ar: "كلية العلوم القانونية والاقتصادية والاجتماعية — عين السبع", short_fr: "FSJES Casa", short_ar: "الحقوق كازا", aliases: ["fsjes", "droit casa", "fac droit", "الحقوق", "كلية الحقوق"], category_fr: "Université — faculté de droit", category_ar: "جامعة — كلية الحقوق", categoryKey: "faculty", sector: "public", city_fr: "Casablanca", city_ar: "الدار البيضاء", region_key: "casa-settat", lat: 33.613, lng: -7.536, website: "https://www.enssup.gov.ma", recognition_fr: "Université publique", recognition_ar: "جامعة عمومية", lastVerified: VERIFIED, sourceId: "src-cursussup", about_fr: "Faculté d'accès ouvert : inscription avec le baccalauréat, certaines filières effectuant une sélection selon les places disponibles.", about_ar: "كلية بولوج مفتوح: التسجيل بالبكالوريا، وبعض المسالك تنتقي حسب المقاعد المتوفرة." }),
  I({ id: "flsh-rabat", name_fr: "Faculté des Lettres et des Sciences Humaines — Rabat", name_ar: "كلية الآداب والعلوم الإنسانية — الرباط", short_fr: "FLSH Rabat", short_ar: "الآداب الرباط", aliases: ["flsh", "lettres rabat", "fac lettres", "الآداب", "كلية الآداب"], category_fr: "Université — faculté de lettres", category_ar: "جامعة — كلية الآداب", categoryKey: "faculty", sector: "public", city_fr: "Rabat", city_ar: "الرباط", region_key: "rabat-sale", lat: 34.02, lng: -6.831, website: "https://www.enssup.gov.ma", recognition_fr: "Université publique", recognition_ar: "جامعة عمومية", lastVerified: VERIFIED, sourceId: "src-cursussup", about_fr: "Inscription ouverte aux bacheliers, modules en arabe et en français selon les départements.", about_ar: "تسجيل مفتوح لحاملي البكالوريا، بوحدات بالعربية والفرنسية حسب الشعب." }),
  I({ id: "ensa-marrakech", name_fr: "École Nationale des Sciences Appliquées — Marrakech", name_ar: "المدرسة الوطنية للعلوم التطبيقية — مراكش", short_fr: "ENSA Marrakech", short_ar: "إنسا مراكش", aliases: ["ensa", "إنسا", "ensa marrakech", "ensa marakch"], category_fr: "École d'ingénieurs publique", category_ar: "مدرسة مهندسين عمومية", categoryKey: "engineering", sector: "public", city_fr: "Marrakech", city_ar: "مراكش", region_key: "marrakech-safi", lat: 31.646, lng: -8.02, website: "https://www.uca.ma", recognition_fr: "École publique, diplôme d'ingénieur d'État", recognition_ar: "مدرسة عمومية، دبلوم مهندس الدولة", lastVerified: VERIFIED, sourceId: "src-ensa-net", about_fr: "Cycle ingénieur d'État en 5 ans. Présélection sur formule nationale/régionale puis concours écrit national.", about_ar: "سلك مهندس الدولة في 5 سنوات. انتقاء أولي بالنقطة الموزونة ثم مباراة كتابية وطنية." }),
  I({ id: "ensa-tanger", name_fr: "École Nationale des Sciences Appliquées — Tanger", name_ar: "المدرسة الوطنية للعلوم التطبيقية — طنجة", short_fr: "ENSA Tanger", short_ar: "إنسا طنجة", aliases: ["ensa tanger", "ensa tanja", "إنسا طنجة"], category_fr: "École d'ingénieurs publique", category_ar: "مدرسة مهندسين عمومية", categoryKey: "engineering", sector: "public", city_fr: "Tanger", city_ar: "طنجة", region_key: "tanger-tetouan", lat: 35.733, lng: -5.897, website: "https://www.uae.ma", recognition_fr: "École publique, diplôme d'ingénieur d'État", recognition_ar: "مدرسة عمومية، دبلوم مهندس الدولة", lastVerified: VERIFIED, sourceId: "src-ensa-net", about_fr: "Cycle ingénieur avec présélection nationale sur la formule 75/25 puis concours écrit.", about_ar: "سلك مهندس مع انتقاء وطني بنقطة 75/25 ثم مباراة كتابية." }),
  I({ id: "ensa-agadir", name_fr: "École Nationale des Sciences Appliquées — Agadir", name_ar: "المدرسة الوطنية للعلوم التطبيقية — أكادير", short_fr: "ENSA Agadir", short_ar: "إنسا أكادير", aliases: ["ensa agadir", "إنسا أكادير"], category_fr: "École d'ingénieurs publique", category_ar: "مدرسة مهندسين عمومية", categoryKey: "engineering", sector: "public", city_fr: "Agadir", city_ar: "أكادير", region_key: "souss-massa", lat: 30.395, lng: -9.534, website: "https://www.uiz.ac.ma", recognition_fr: "École publique, diplôme d'ingénieur d'État", recognition_ar: "مدرسة عمومية، دبلوم مهندس الدولة", lastVerified: VERIFIED, sourceId: "src-ensa-net", about_fr: "Cycle ingénieur d'État, présélection par note pondérée puis concours.", about_ar: "سلك مهندس الدولة، انتقاء بالنقطة الموزونة ثم مباراة." }),
  I({ id: "ensam-casa", name_fr: "École Nationale Supérieure d'Arts et Métiers — Casablanca", name_ar: "المدرسة الوطنية العليا للفنون والمهن — الدار البيضاء", short_fr: "ENSAM Casa", short_ar: "إنسام كازا", aliases: ["ensam", "arts et metiers", "إنسام"], category_fr: "École d'ingénieurs publique", category_ar: "مدرسة مهندسين عمومية", categoryKey: "engineering", sector: "public", city_fr: "Casablanca", city_ar: "الدار البيضاء", region_key: "casa-settat", lat: 33.541, lng: -7.662, website: "https://www.uh2c.ac.ma", recognition_fr: "École publique, diplôme d'ingénieur d'État", recognition_ar: "مدرسة عمومية، دبلوم مهندس الدولة", lastVerified: VERIFIED, sourceId: "src-ensa-net", about_fr: "Ingénierie mécanique et industrielle. Présélection sur la note de l'examen national puis concours écrit.", about_ar: "الهندسة الميكانيكية والصناعية. انتقاء بنقطة الامتحان الوطني ثم مباراة كتابية." }),
  I({ id: "encg-casa", name_fr: "École Nationale de Commerce et de Gestion — Casablanca", name_ar: "المدرسة الوطنية للتجارة والتسيير — الدار البيضاء", short_fr: "ENCG Casa", short_ar: "إنسج كازا", aliases: ["encg", "encg casa", "إنسج", "مدرسة التجارة"], category_fr: "École de commerce publique", category_ar: "مدرسة تجارة عمومية", categoryKey: "business", sector: "public", city_fr: "Casablanca", city_ar: "الدار البيضاء", region_key: "casa-settat", lat: 33.566, lng: -7.6, website: "https://www.uh2c.ac.ma", recognition_fr: "École publique, diplôme ENCG", recognition_ar: "مدرسة عمومية، دبلوم ENCG", lastVerified: VERIFIED, sourceId: "src-encg-net", about_fr: "Commerce et gestion en 5 ans. Présélection nationale puis TAFEM (test d'aptitude).", about_ar: "التجارة والتسيير في 5 سنوات. انتقاء وطني ثم اختبار التافيم." }),
  I({ id: "encg-tanger", name_fr: "École Nationale de Commerce et de Gestion — Tanger", name_ar: "المدرسة الوطنية للتجارة والتسيير — طنجة", short_fr: "ENCG Tanger", short_ar: "إنسج طنجة", aliases: ["encg tanger", "encg tanja", "إنسج طنجة"], category_fr: "École de commerce publique", category_ar: "مدرسة تجارة عمومية", categoryKey: "business", sector: "public", city_fr: "Tanger", city_ar: "طنجة", region_key: "tanger-tetouan", lat: 35.742, lng: -5.9, website: "https://www.uae.ma", recognition_fr: "École publique, diplôme ENCG", recognition_ar: "مدرسة عمومية، دبلوم ENCG", lastVerified: VERIFIED, sourceId: "src-encg-net", about_fr: "Présélection sur formule nationale/régionale puis TAFEM.", about_ar: "انتقاء بالنقطة الموزونة ثم اختبار التافيم." }),
  I({ id: "fst-mohammedia", name_fr: "Faculté des Sciences et Techniques — Mohammedia", name_ar: "كلية العلوم والتقنيات — المحمدية", short_fr: "FST Mohammedia", short_ar: "فت المحمدية", aliases: ["fst", "fst mohammedia", "فت"], category_fr: "Faculté des Sciences et Techniques", category_ar: "كلية العلوم والتقنيات", categoryKey: "fst", sector: "public", city_fr: "Mohammedia", city_ar: "المحمدية", region_key: "casa-settat", lat: 33.692, lng: -7.394, website: "https://www.uh2c.ac.ma", recognition_fr: "Établissement public", recognition_ar: "مؤسسة عمومية", lastVerified: VERIFIED, sourceId: "src-fst-net", about_fr: "Licences en sciences et techniques. Présélection (50% moyenne + 50% national) puis examen écrit.", about_ar: "إجازات في العلوم والتقنيات. انتقاء (50٪ معدل + 50٪ وطني) ثم امتحان كتابي." }),
  I({ id: "fst-fes", name_fr: "Faculté des Sciences et Techniques — Fès", name_ar: "كلية العلوم والتقنيات — فاس", short_fr: "FST Fès", short_ar: "فت فاس", aliases: ["fst fes", "fst fès", "فت فاس"], category_fr: "Faculté des Sciences et Techniques", category_ar: "كلية العلوم والتقنيات", categoryKey: "fst", sector: "public", city_fr: "Fès", city_ar: "فاس", region_key: "fes-meknes", lat: 34.042, lng: -4.986, website: "https://www.usmba.ac.ma", recognition_fr: "Établissement public", recognition_ar: "مؤسسة عمومية", lastVerified: VERIFIED, sourceId: "src-fst-net", about_fr: "Licences scientifiques avec présélection puis examen.", about_ar: "إجازات علمية مع انتقاء ثم امتحان." }),
  I({ id: "est-casa", name_fr: "École Supérieure de Technologie — Casablanca", name_ar: "المدرسة العليا للتكنولوجيا — الدار البيضاء", short_fr: "EST Casa", short_ar: "إست كازا", aliases: ["est", "est casa", "إست", "dut"], category_fr: "Technologie — DUT en 2 ans", category_ar: "تكنولوجيا — دبلوم في سنتين", categoryKey: "est", sector: "public", city_fr: "Casablanca", city_ar: "الدار البيضاء", region_key: "casa-settat", lat: 33.594, lng: -7.583, website: "https://www.uh2c.ac.ma", recognition_fr: "Établissement public, DUT", recognition_ar: "مؤسسة عمومية، دبلوم جامعي في التكنولوجيا", lastVerified: VERIFIED, sourceId: "src-est-net", about_fr: "DUT en 2 ans, filières techniques. Présélection sur la plateforme nationale selon la note de l'examen national.", about_ar: "دبلوم جامعي في سنتين، مسالك تقنية. انتقاء عبر المنصة الوطنية حسب نقطة الامتحان الوطني." }),
  I({ id: "est-safi", name_fr: "École Supérieure de Technologie — Safi", name_ar: "المدرسة العليا للتكنولوجيا — آسفي", short_fr: "EST Safi", short_ar: "إست آسفي", aliases: ["est safi", "إست آسفي"], category_fr: "Technologie — DUT en 2 ans", category_ar: "تكنولوجيا — دبلوم في سنتين", categoryKey: "est", sector: "public", city_fr: "Safi", city_ar: "آسفي", region_key: "marrakech-safi", lat: 32.306, lng: -9.24, website: "https://www.uca.ma", recognition_fr: "Établissement public, DUT", recognition_ar: "مؤسسة عمومية، دبلوم جامعي في التكنولوجيا", lastVerified: VERIFIED, sourceId: "src-est-net", about_fr: "DUT en 2 ans, présélection nationale.", about_ar: "دبلوم جامعي في سنتين مع انتقاء وطني." }),
  I({ id: "cpge-rabat", name_fr: "Classes Préparatoires — Lycée Moulay Youssef, Rabat", name_ar: "الأقسام التحضيرية — ثانوية مولاي يوسف، الرباط", short_fr: "CPGE Rabat", short_ar: "التحضيرية الرباط", aliases: ["cpge", "prepa", "les classes preparatoires", "الأقسام التحضيرية", "تحضيرية"], category_fr: "Classes préparatoires aux grandes écoles", category_ar: "الأقسام التحضيرية للمدارس العليا", categoryKey: "cpge", sector: "public", city_fr: "Rabat", city_ar: "الرباط", region_key: "rabat-sale", lat: 34.012, lng: -6.826, website: "https://www.cursussup.gov.ma", recognition_fr: "Voie publique préparatoire", recognition_ar: "مسار تحضيري عمومي", lastVerified: VERIFIED, sourceId: "src-cursussup", about_fr: "MPSI/PCSI en 2 ans vers les concours des grandes écoles. Sélection sur dossier scolaire complet, sans seuil publié.", about_ar: "مسارا MPSI/PCSI في سنتين نحو مباريات المدارس العليا. الانتقاء بالملف الدراسي الكامل، دون عتبة منشورة." }),
  I({ id: "ena-rabat", name_fr: "École Nationale d'Architecture — Rabat", name_ar: "المدرسة الوطنية للهندسة المعمارية — الرباط", short_fr: "ENA Rabat", short_ar: "الهندسة المعمارية الرباط", aliases: ["ena", "architecture", "الهندسة المعمارية", "معمارية"], category_fr: "Institut spécialisé — architecture", category_ar: "معهد متخصص — هندسة معمارية", categoryKey: "institute", sector: "public", city_fr: "Rabat", city_ar: "الرباط", region_key: "rabat-sale", lat: 34.003, lng: -6.849, website: "https://www.enssup.gov.ma", recognition_fr: "Établissement public spécialisé", recognition_ar: "مؤسسة عمومية متخصصة", lastVerified: VERIFIED, sourceId: "src-enssup", about_fr: "Architecture en 6 ans, concours propre à l'école incluant épreuves de dessin et de culture.", about_ar: "الهندسة المعمارية في 6 سنوات، مباراة خاصة بالمدرسة تشمل الرسم والثقافة العامة." }),
  I({ id: "iav-rabat", name_fr: "Institut Agronomique et Vétérinaire Hassan II", name_ar: "معهد الحسن الثاني للزراعة والبيطرة", short_fr: "IAV Hassan II", short_ar: "معهد الزراعة", aliases: ["iav", "agronomie", "veterinaire", "الزراعة", "البيطرة"], category_fr: "Institut spécialisé — agronomie", category_ar: "معهد متخصص — الفلاحة", categoryKey: "institute", sector: "public", city_fr: "Rabat", city_ar: "الرباط", region_key: "rabat-sale", lat: 33.971, lng: -6.847, website: "https://www.iav.ac.ma", recognition_fr: "Grand établissement public", recognition_ar: "مؤسسة عمومية كبرى", lastVerified: VERIFIED, sourceId: "src-iav", about_fr: "Ingénierie agronomique et vétérinaire, sélection sur dossier du bac puis épreuves.", about_ar: "هندسة الفلاحة والبيطرة، انتقاء بالملف ثم اختبارات." }),
  I({ id: "insea-rabat", name_fr: "Institut National de Statistique et d'Économie Appliquée", name_ar: "المعهد الوطني للإحصاء والاقتصاد التطبيقي", short_fr: "INSEA", short_ar: "إنسيا", aliases: ["insea", "statistique", "إنسيا", "الإحصاء"], category_fr: "Institut spécialisé — statistique", category_ar: "معهد متخصص — الإحصاء", categoryKey: "institute", sector: "public", city_fr: "Rabat", city_ar: "الرباط", region_key: "rabat-sale", lat: 33.987, lng: -6.862, website: "https://www.insea.ac.ma", recognition_fr: "Établissement public, diplôme d'ingénieur d'État", recognition_ar: "مؤسسة عمومية، دبلوم مهندس الدولة", lastVerified: VERIFIED, sourceId: "src-enssup", about_fr: "Ingénierie en statistique, data et économie appliquée. Forte présélection mathématique puis concours.", about_ar: "هندسة الإحصاء والبيانات والاقتصاد التطبيقي. انتقاء قوي في الرياضيات ثم مباراة." }),
  I({ id: "ofppt-casa", name_fr: "OFPPT — Institut Spécialisé de Technologie Appliquée", name_ar: "مكتب التكوين المهني — المعهد المتخصص", short_fr: "OFPPT ISTA", short_ar: "أوفبت", aliases: ["ofppt", "ista", "أوفبت", "تكوين مهني"], category_fr: "Formation professionnelle", category_ar: "التكوين المهني", categoryKey: "vocational", sector: "public", city_fr: "Casablanca", city_ar: "الدار البيضاء", region_key: "casa-settat", lat: 33.5892, lng: -7.6, website: "https://www.ofppt.ma", recognition_fr: "Établissement public de formation professionnelle", recognition_ar: "مؤسسة عمومية للتكوين المهني", lastVerified: VERIFIED, sourceId: "src-ofppt", about_fr: "Diplômes Technicien et Technicien Spécialisé, inscription en ligne sur la plateforme OFPPT.", about_ar: "دبلومات تقني وتقني متخصص، التسجيل عبر الإنترنت على منصة المكتب." }),
  I({ id: "um6ss-casa", name_fr: "Université Mohammed VI des Sciences de la Santé — Casablanca", name_ar: "جامعة محمد السادس للعلوم الصحية — الدار البيضاء", short_fr: "UM6SS Casa", short_ar: "جامعة محمد السادس للصحة", aliases: ["um6ss", "medecine privee", "médecine privée", "طب خاص"], category_fr: "Médecine, pharmacie, santé — privé", category_ar: "الطب والصيدلة — خاص", categoryKey: "medicine", sector: "private", city_fr: "Casablanca", city_ar: "الدار البيضاء", region_key: "casa-settat", lat: 33.552, lng: -7.636, website: "https://www.um6ss.ma", recognition_fr: "Université privée reconnue par l'État", recognition_ar: "جامعة خاصة معترف بها من طرف الدولة", lastVerified: VERIFIED, sourceId: "src-um6ss", about_fr: "Campus santé privé reconnu par l'État : médecine, pharmacie, sciences infirmières. Sélection sur dossier puis épreuves propres.", about_ar: "حرم صحي خاص معترف به من الدولة: طب، صيدلة، علوم التمريض. الانتقاء بالملف ثم اختبارات خاصة." }),
  I({ id: "uir-rabat", name_fr: "Université Internationale de Rabat", name_ar: "الجامعة الدولية للرباط", short_fr: "UIR Rabat", short_ar: "الجامعة الدولية", aliases: ["uir", "universite internationale rabat", "الجامعة الدولية"], category_fr: "Université privée", category_ar: "جامعة خاصة", categoryKey: "private", sector: "private", city_fr: "Rabat", city_ar: "الرباط", region_key: "rabat-sale", lat: 33.943, lng: -6.731, website: "https://www.uir.ac.ma", recognition_fr: "Université privée reconnue par l'État", recognition_ar: "جامعة خاصة معترف بها من طرف الدولة", lastVerified: VERIFIED, sourceId: "src-uir", about_fr: "Ingénierie, business, architecture et sciences politiques au Technopolis de Rabat. Candidature en ligne, tests ou entretiens selon l'école.", about_ar: "هندسة وتجارة وعمارة وعلوم سياسية في تكنوبوليس الرباط. الترشيح عبر الإنترنت مع اختبارات أو مقابلات حسب المدرسة." }),
  I({ id: "uic-casa", name_fr: "Université Internationale de Casablanca", name_ar: "جامعة الدار البيضاء الدولية", short_fr: "UIC Casablanca", short_ar: "جامعة كازا الدولية", aliases: ["uic", "universite internationale casablanca", "جامعة كازا الدولية"], category_fr: "Université privée", category_ar: "جامعة خاصة", categoryKey: "private", sector: "private", city_fr: "Casablanca", city_ar: "الدار البيضاء", region_key: "casa-settat", lat: 33.501, lng: -7.656, website: "https://www.uic.ac.ma", recognition_fr: "Université privée reconnue par l'État", recognition_ar: "جامعة خاصة معترف بها من طرف الدولة", lastVerified: VERIFIED, sourceId: "src-uic", about_fr: "Ingénierie, management, droit et santé. Admission sur dossier et entretien de motivation.", about_ar: "هندسة وتدبير وقانون وصحة. القبول بالملف ومقابلة تحفيزية." }),
];

/* ------------------------------ programmes ------------------------------ */
const P = (p: Omit<Programme, "seats"> & { seats: number | null }): Programme => p;

export const PROGRAMMES: Programme[] = [
  P({ id: "pr-fmp-rabat-med", institutionId: "fmp-rabat", name_fr: "Médecine générale", name_ar: "الطب العام", field: "medicine", level: "Doctorat", durationYears: 7, languages: ["fr"], tuitionMAD: null, seats: 190 }),
  P({ id: "pr-fmp-casa-med", institutionId: "fmp-casa", name_fr: "Médecine générale", name_ar: "الطب العام", field: "medicine", level: "Doctorat", durationYears: 7, languages: ["fr"], tuitionMAD: null, seats: 205 }),
  P({ id: "pr-fsjes-droit", institutionId: "fsjes-casa", name_fr: "Licence Droit privé", name_ar: "الإجازة في القانون الخاص", field: "law", level: "Licence", durationYears: 3, languages: ["ar", "fr"], tuitionMAD: null, seats: null }),
  P({ id: "pr-fsjes-eco", institutionId: "fsjes-casa", name_fr: "Licence Économie et gestion", name_ar: "الإجازة في الاقتصاد والتدبير", field: "economics", level: "Licence", durationYears: 3, languages: ["ar", "fr"], tuitionMAD: null, seats: null }),
  P({ id: "pr-flsh-lettres", institutionId: "flsh-rabat", name_fr: "Licence Études françaises", name_ar: "الإجازة في الدراسات الفرنسية", field: "letters", level: "Licence", durationYears: 3, languages: ["fr"], tuitionMAD: null, seats: null }),
  P({ id: "pr-flsh-geo", institutionId: "flsh-rabat", name_fr: "Licence Géographie", name_ar: "الإجازة في الجغرافيا", field: "letters", level: "Licence", durationYears: 3, languages: ["ar"], tuitionMAD: null, seats: null }),
  P({ id: "pr-ensama-info", institutionId: "ensa-marrakech", name_fr: "Génie informatique", name_ar: "هندسة المعلوميات", field: "engineering", level: "Ingénieur", durationYears: 5, languages: ["fr"], tuitionMAD: null, seats: 120 }),
  P({ id: "pr-ensata-info", institutionId: "ensa-tanger", name_fr: "Génie informatique", name_ar: "هندسة المعلوميات", field: "engineering", level: "Ingénieur", durationYears: 5, languages: ["fr"], tuitionMAD: null, seats: 110 }),
  P({ id: "pr-ensaa-info", institutionId: "ensa-agadir", name_fr: "Génie informatique", name_ar: "هندسة المعلوميات", field: "engineering", level: "Ingénieur", durationYears: 5, languages: ["fr"], tuitionMAD: null, seats: 90 }),
  P({ id: "pr-ensam-gindus", institutionId: "ensam-casa", name_fr: "Génie industriel", name_ar: "الهندسة الصناعية", field: "engineering", level: "Ingénieur", durationYears: 5, languages: ["fr"], tuitionMAD: null, seats: 140 }),
  P({ id: "pr-encg-mg", institutionId: "encg-casa", name_fr: "Management et gestion", name_ar: "التدبير والتسيير", field: "business", level: "Licence", durationYears: 5, languages: ["fr", "ar"], tuitionMAD: null, seats: 240 }),
  P({ id: "pr-encgta-mg", institutionId: "encg-tanger", name_fr: "Management et gestion", name_ar: "التدبير والتسيير", field: "business", level: "Licence", durationYears: 5, languages: ["fr", "ar"], tuitionMAD: null, seats: 180 }),
  P({ id: "pr-fstmo-info", institutionId: "fst-mohammedia", name_fr: "Licence MIP (Maths-Informatique-Physique)", name_ar: "إجازة رياضيات-معلوميات-فيزياء", field: "science", level: "Licence", durationYears: 3, languages: ["fr"], tuitionMAD: null, seats: 260 }),
  P({ id: "pr-fstfe-info", institutionId: "fst-fes", name_fr: "Licence MIP (Maths-Informatique-Physique)", name_ar: "إجازة رياضيات-معلوميات-فيزياء", field: "science", level: "Licence", durationYears: 3, languages: ["fr"], tuitionMAD: null, seats: 240 }),
  P({ id: "pr-estc-dut-info", institutionId: "est-casa", name_fr: "DUT Génie informatique", name_ar: "دبلوم تقني جامعي في المعلوميات", field: "tech", level: "DUT", durationYears: 2, languages: ["fr"], tuitionMAD: null, seats: 90 }),
  P({ id: "pr-ests-dut-te", institutionId: "est-safi", name_fr: "DUT Techniques de management", name_ar: "دبلوم تقني جامعي في تقنيات التدبير", field: "tech", level: "DUT", durationYears: 2, languages: ["fr", "ar"], tuitionMAD: null, seats: 80 }),
  P({ id: "pr-cpge-mpsi", institutionId: "cpge-rabat", name_fr: "MPSI / PCSI (prépa scientifique)", name_ar: "أقسام تحضيرية علمية", field: "science", level: "CPGE", durationYears: 2, languages: ["fr"], tuitionMAD: null, seats: 220 }),
  P({ id: "pr-ena-archi", institutionId: "ena-rabat", name_fr: "Diplôme d'architecte", name_ar: "دبلوم مهندس معماري", field: "architecture", level: "Ingénieur", durationYears: 6, languages: ["fr"], tuitionMAD: null, seats: 60 }),
  P({ id: "pr-iav-agro", institutionId: "iav-rabat", name_fr: "Ingénieur agronome", name_ar: "مهندس فلاحي", field: "agronomy", level: "Ingénieur", durationYears: 5, languages: ["fr"], tuitionMAD: null, seats: 150 }),
  P({ id: "pr-insea-data", institutionId: "insea-rabat", name_fr: "Ingénieur Data Engineer", name_ar: "مهندس بيانات", field: "statistics", level: "Ingénieur", durationYears: 3, languages: ["fr"], tuitionMAD: null, seats: 40 }),
  P({ id: "pr-ofppt-ts-dev", institutionId: "ofppt-casa", name_fr: "Technicien Spécialisé Développement digital", name_ar: "تقني متخصص في التطوير الرقمي", field: "tech", level: "Technicien", durationYears: 2, languages: ["fr", "ar"], tuitionMAD: null, seats: 960 }),
  P({ id: "pr-um6ss-med", institutionId: "um6ss-casa", name_fr: "Médecine", name_ar: "الطب", field: "medicine", level: "Doctorat", durationYears: 7, languages: ["fr", "en"], tuitionMAD: 140000, seats: 150 }),
  P({ id: "pr-um6ss-nurse", institutionId: "um6ss-casa", name_fr: "Sciences infirmières", name_ar: "علوم التمريض", field: "health", level: "Licence", durationYears: 4, languages: ["fr"], tuitionMAD: 60000, seats: 120 }),
  P({ id: "pr-uir-eng", institutionId: "uir-rabat", name_fr: "Ingénierie informatique et réseaux", name_ar: "هندسة المعلوميات والشبكات", field: "engineering", level: "Ingénieur", durationYears: 5, languages: ["fr", "en"], tuitionMAD: 80000, seats: 180 }),
  P({ id: "pr-uir-bus", institutionId: "uir-rabat", name_fr: "Business administration", name_ar: "إدارة الأعمال", field: "business", level: "Licence", durationYears: 3, languages: ["en", "fr"], tuitionMAD: 72000, seats: 160 }),
  P({ id: "pr-uic-eng", institutionId: "uic-casa", name_fr: "Ingénierie informatique", name_ar: "هندسة المعلوميات", field: "engineering", level: "Ingénieur", durationYears: 5, languages: ["fr"], tuitionMAD: 65000, seats: 200 }),
  P({ id: "pr-uic-droit", institutionId: "uic-casa", name_fr: "Droit des affaires", name_ar: "قانون الأعمال", field: "law", level: "Licence", durationYears: 4, languages: ["fr", "ar"], tuitionMAD: 45000, seats: 120 }),
];

/* --------------------------- admission rules ---------------------------- */
const R = (r: AdmissionRule): AdmissionRule => r;

export const RULES: AdmissionRule[] = [
  R({ id: "ar-fmp-rabat-2026", programmeId: "pr-fmp-rabat-med", year: 2026, streams: ["SVT", "SPC", "SMA", "SMB"], route: "preselection-exam", formulaId: "f-n75-r25", notes_fr: "Concours commun médecine/pharmacie/dentaire : présélection puis épreuves écrites QCM.", notes_ar: "المباراة المشتركة للطب والصيدلة وطب الأسنان: انتقاء أولي ثم اختبارات كتابية بأسئلة متعددة الخيارات.", registrationOpens: "2026-06-15", registrationDeadline: "2026-06-30", examDate: "2026-07-25", preselectionDate: "2026-07-10" }),
  R({ id: "ar-fmp-casa-2026", programmeId: "pr-fmp-casa-med", year: 2026, streams: ["SVT", "SPC", "SMA", "SMB"], route: "preselection-exam", formulaId: "f-n75-r25", notes_fr: "Même concours national que les autres facultés de médecine.", notes_ar: "نفس المباراة الوطنية لكليات الطب الأخرى.", registrationOpens: "2026-06-15", registrationDeadline: "2026-06-30", examDate: "2026-07-25", preselectionDate: "2026-07-10" }),
  R({ id: "ar-fsjes-2026", programmeId: "pr-fsjes-droit", year: 2026, streams: ["SMA", "SMB", "SPC", "SVT", "SECO", "LETTRES", "STM", "STE"], route: "open", formulaId: null, notes_fr: "Inscription ouverte en ligne via la plateforme nationale puis validation sur place.", notes_ar: "تسجيل مفتوح عبر الإنترنت على المنصة الوطنية ثم التأكيد بالمؤسسة.", registrationOpens: "2026-07-01", registrationDeadline: "2026-09-15", examDate: null, preselectionDate: null }),
  R({ id: "ar-flsh-2026", programmeId: "pr-flsh-lettres", year: 2026, streams: ["LETTRES", "SECO", "SMA", "SMB", "SPC", "SVT"], route: "open", formulaId: null, notes_fr: "Accès ouvert ; niveau de français requis évalué à l'inscription pour certaines filières.", notes_ar: "ولوج مفتوح؛ مستوى الفرنسية يقيّم عند التسجيل لبعض المسالك.", registrationOpens: "2026-07-01", registrationDeadline: "2026-09-20", examDate: null, preselectionDate: null }),
  R({ id: "ar-ensama-2026", programmeId: "pr-ensama-info", year: 2026, streams: ["SMA", "SMB", "SPC", "STM", "STE"], route: "preselection-exam", formulaId: "f-n75-r25", notes_fr: "Candidature sur la plateforme ENSA ; présélection 75/25 puis concours écrit national commun.", notes_ar: "الترشيح عبر منصة ENSA؛ انتقاء 75/25 ثم مباراة كتابية وطنية مشتركة.", registrationOpens: "2026-06-10", registrationDeadline: "2026-06-28", examDate: "2026-07-21", preselectionDate: "2026-07-06" }),
  R({ id: "ar-ensata-2026", programmeId: "pr-ensata-info", year: 2026, streams: ["SMA", "SMB", "SPC", "STM", "STE"], route: "preselection-exam", formulaId: "f-n75-r25", notes_fr: "Même concours commun des ENSA.", notes_ar: "نفس المباراة المشتركة لمدارس ENSA.", registrationOpens: "2026-06-10", registrationDeadline: "2026-06-28", examDate: "2026-07-21", preselectionDate: "2026-07-06" }),
  R({ id: "ar-ensaa-2026", programmeId: "pr-ensaa-info", year: 2026, streams: ["SMA", "SMB", "SPC", "STM", "STE"], route: "preselection-exam", formulaId: "f-n75-r25", notes_fr: "Même concours commun des ENSA.", notes_ar: "نفس المباراة المشتركة لمدارس ENSA.", registrationOpens: "2026-06-10", registrationDeadline: "2026-06-28", examDate: "2026-07-21", preselectionDate: "2026-07-06" }),
  R({ id: "ar-ensam-2026", programmeId: "pr-ensam-gindus", year: 2026, streams: ["SMA", "SMB", "SPC", "STM"], route: "preselection-exam", formulaId: "f-nat", notes_fr: "Présélection sur la note de l'examen national uniquement, puis concours écrit.", notes_ar: "الانتقاء بنقطة الامتحان الوطني فقط، ثم مباراة كتابية.", registrationOpens: "2026-06-08", registrationDeadline: "2026-06-26", examDate: "2026-07-20", preselectionDate: "2026-07-05" }),
  R({ id: "ar-encg-2026", programmeId: "pr-encg-mg", year: 2026, streams: ["SECO", "SMA", "SMB", "SPC", "SVT", "LETTRES"], route: "preselection-exam", formulaId: "f-n80-r20", notes_fr: "Présélection puis TAFEM (test d'aptitude : culture, logique, langues).", notes_ar: "انتقاء أولي ثم اختبار التافيم: ثقافة عامة ومنطق ولغات.", registrationOpens: "2026-06-12", registrationDeadline: "2026-07-02", examDate: "2026-07-27", preselectionDate: "2026-07-12" }),
  R({ id: "ar-encgta-2026", programmeId: "pr-encgta-mg", year: 2026, streams: ["SECO", "SMA", "SMB", "SPC", "SVT", "LETTRES"], route: "preselection-exam", formulaId: "f-n80-r20", notes_fr: "Même processus national ENCG-TAFEM.", notes_ar: "نفس المسار الوطني ENCG-TAFEM.", registrationOpens: "2026-06-12", registrationDeadline: "2026-07-02", examDate: "2026-07-27", preselectionDate: "2026-07-12" }),
  R({ id: "ar-fstmo-2026", programmeId: "pr-fstmo-info", year: 2026, streams: ["SMA", "SMB", "SPC", "STM", "STE"], route: "preselection-exam", formulaId: "f-avg50-n50", notes_fr: "Présélection 50% moyenne + 50% national, puis examen écrit.", notes_ar: "انتقاء 50٪ معدل + 50٪ وطني ثم امتحان كتابي.", registrationOpens: "2026-06-14", registrationDeadline: "2026-06-29", examDate: "2026-07-22", preselectionDate: "2026-07-08" }),
  R({ id: "ar-fstfe-2026", programmeId: "pr-fstfe-info", year: 2026, streams: ["SMA", "SMB", "SPC", "STM", "STE"], route: "preselection-exam", formulaId: "f-avg50-n50", notes_fr: "Même principe de présélection 50/50.", notes_ar: "نفس مبدأ الانتقاء 50/50.", registrationOpens: "2026-06-14", registrationDeadline: "2026-06-29", examDate: "2026-07-22", preselectionDate: "2026-07-08" }),
  R({ id: "ar-estc-2026", programmeId: "pr-estc-dut-info", year: 2026, streams: ["SMA", "SPC", "STM", "STE"], route: "preselection-exam", formulaId: "f-nat", notes_fr: "Présélection nationale entre bacheliers techniques et scientifiques, puis test écrit.", notes_ar: "انتقاء وطني بين حاملي البكالوريا التقنية والعلمية، ثم اختبار كتابي.", registrationOpens: "2026-06-16", registrationDeadline: "2026-07-03", examDate: "2026-07-24", preselectionDate: "2026-07-11" }),
  R({ id: "ar-ests-2026", programmeId: "pr-ests-dut-te", year: 2026, streams: ["SECO", "SMA", "SMB", "SPC", "STE", "STM"], route: "preselection-exam", formulaId: "f-nat", notes_fr: "Présélection sur examen national puis test.", notes_ar: "انتقاء بالامتحان الوطني ثم اختبار.", registrationOpens: "2026-06-16", registrationDeadline: "2026-07-03", examDate: "2026-07-24", preselectionDate: "2026-07-11" }),
  R({ id: "ar-cpge-2026", programmeId: "pr-cpge-mpsi", year: 2026, streams: ["SMA", "SMB", "SPC"], route: "file", formulaId: null, notes_fr: "Sélection sur dossier : notes de 1re et terminale, mentions, rang. Aucun seuil officiel n'est publié.", notes_ar: "الانتقاء بالملف: نقط السنة الأولى والثانية باك والميزات والرتبة. لا عتبة رسمية منشورة.", registrationOpens: "2026-06-20", registrationDeadline: "2026-07-05", examDate: null, preselectionDate: "2026-07-15" }),
  R({ id: "ar-ena-2026", programmeId: "pr-ena-archi", year: 2026, streams: ["SMA", "SPC", "SVT", "SMB"], route: "exam", formulaId: null, notes_fr: "Concours propre : épreuves de dessin, d'expression et de culture générale.", notes_ar: "مباراة خاصة: اختبارات في الرسم والتعبير والثقافة العامة.", registrationOpens: "2026-06-18", registrationDeadline: "2026-07-08", examDate: "2026-07-30", preselectionDate: null }),
  R({ id: "ar-iav-2026", programmeId: "pr-iav-agro", year: 2026, streams: ["SVT", "SPC", "SMA"], route: "exam", formulaId: "f-n75-r25", notes_fr: "Présélection sur dossier et note pondérée, puis épreuves propres de l'institut.", notes_ar: "انتقاء بالملف والنقطة الموزونة، ثم اختبارات خاصة بالمعهد.", registrationOpens: "2026-06-05", registrationDeadline: "2026-06-25", examDate: "2026-07-18", preselectionDate: "2026-07-03" }),
  R({ id: "ar-insea-2026", programmeId: "pr-insea-data", year: 2026, streams: ["SMA", "SMB", "SPC"], route: "exam", formulaId: "f-n75-r25", notes_fr: "Concours propre fortement mathématique après présélection.", notes_ar: "مباراة خاصة قوية في الرياضيات بعد الانتقاء الأولي.", registrationOpens: "2026-06-18", registrationDeadline: "2026-07-04", examDate: "2026-07-28", preselectionDate: "2026-07-13" }),
  R({ id: "ar-ofppt-2026", programmeId: "pr-ofppt-ts-dev", year: 2026, streams: ["SMA", "SMB", "SPC", "SVT", "SECO", "STM", "STE", "LETTRES"], route: "exam", formulaId: null, notes_fr: "Inscription gratuite en ligne, test d'orientation sur place.", notes_ar: "تسجيل مجاني عبر الإنترنت واختبار توجيه بالمعهد.", registrationOpens: "2026-05-20", registrationDeadline: "2026-07-15", examDate: "2026-07-20", preselectionDate: null }),
  R({ id: "ar-um6ss-2026", programmeId: "pr-um6ss-med", year: 2026, streams: ["SVT", "SPC", "SMA"], route: "exam", formulaId: "f-n75-r25", notes_fr: "Candidature en ligne, présélection sur dossier pondéré, tests écrits et oraux.", notes_ar: "الترشيح عبر الإنترنت، انتقاء بالملف الموزون، اختبارات كتابية وشفوية.", registrationOpens: "2026-05-25", registrationDeadline: "2026-06-24", examDate: "2026-07-12", preselectionDate: "2026-07-01" }),
  R({ id: "ar-um6ss-nurse-2026", programmeId: "pr-um6ss-nurse", year: 2026, streams: ["SVT", "SPC", "SMA", "SMB"], route: "file", formulaId: null, notes_fr: "Sélection sur dossier puis entretien de motivation.", notes_ar: "انتقاء بالملف ثم مقابلة تحفيزية.", registrationOpens: "2026-05-25", registrationDeadline: "2026-07-10", examDate: null, preselectionDate: "2026-07-18" }),
  R({ id: "ar-uir-eng-2026", programmeId: "pr-uir-eng", year: 2026, streams: ["SMA", "SMB", "SPC", "STM", "STE"], route: "interview", formulaId: null, notes_fr: "Candidature en ligne, tests d'aptitude et entretien. Bourses au mérite selon la note du bac.", notes_ar: "ترشيح عبر الإنترنت، اختبارات قدرات ومقابلة. منح استحقاق حسب نقطة البكالوريا.", registrationOpens: "2026-04-01", registrationDeadline: "2026-08-31", examDate: null, preselectionDate: null }),
  R({ id: "ar-uir-bus-2026", programmeId: "pr-uir-bus", year: 2026, streams: ["SECO", "SMA", "SMB", "SPC", "SVT", "LETTRES"], route: "interview", formulaId: null, notes_fr: "Admission sur dossier, test d'anglais et entretien.", notes_ar: "قبول بالملف واختبار إنجليزية ومقابلة.", registrationOpens: "2026-04-01", registrationDeadline: "2026-08-31", examDate: null, preselectionDate: null }),
  R({ id: "ar-uic-eng-2026", programmeId: "pr-uic-eng", year: 2026, streams: ["SMA", "SMB", "SPC", "STM", "STE"], route: "file", formulaId: null, notes_fr: "Étude du dossier scolaire puis entretien.", notes_ar: "دراسة الملف الدراسي ثم مقابلة.", registrationOpens: "2026-04-15", registrationDeadline: "2026-09-10", examDate: null, preselectionDate: null }),
  R({ id: "ar-uic-droit-2026", programmeId: "pr-uic-droit", year: 2026, streams: ["LETTRES", "SECO", "SMA", "SMB", "SPC", "SVT"], route: "file", formulaId: null, notes_fr: "Étude du dossier puis entretien de motivation.", notes_ar: "دراسة الملف ثم مقابلة تحفيزية.", registrationOpens: "2026-04-15", registrationDeadline: "2026-09-10", examDate: null, preselectionDate: null }),
];

/* ------------------------------ thresholds ------------------------------ */
let srcFor = (instId: string): string => INSTITUTIONS.find((i) => i.id === instId)?.sourceId ?? "src-cursussup";
const ruleToInst = (ruleId: string): string => {
  const rule = RULES.find((r) => r.id === ruleId)!;
  return PROGRAMMES.find((p) => p.id === rule.programmeId)!.institutionId;
};

/**
 * Build one threshold record per year for a stream. `null` = Not published.
 * All records are confidence "example" — the pipeline replaces them with
 * official values before launch.
 */
const TH = (
  ruleId: string,
  stream: BacStream,
  stage: ThresholdStage,
  kind: ThresholdKind,
  values: Record<number, number | null>
): Threshold[] =>
  Object.entries(values).map(([year, value]) => ({
    ruleId,
    year: Number(year),
    stream,
    stage,
    value,
    scale: 20,
    kind,
    confidence: "example" as const,
    sourceId: srcFor(ruleToInst(ruleId)),
    verifiedAt: VERIFIED,
  }));

const pe = "preselection" as const;

export const THRESHOLDS: Threshold[] = [
  // Médecine Rabat / Casa (présélection 75/25)
  ...TH("ar-fmp-rabat-2026", "SVT", pe, "last-admitted", { 2023: 18.1, 2024: 18.3, 2025: 18.55 }),
  ...TH("ar-fmp-rabat-2026", "SPC", pe, "last-admitted", { 2023: 17.85, 2024: 18.05, 2025: 18.3 }),
  ...TH("ar-fmp-rabat-2026", "SMA", pe, "last-admitted", { 2023: 18.05, 2024: 18.25, 2025: 18.5 }),
  ...TH("ar-fmp-rabat-2026", "SMB", pe, "last-admitted", { 2023: 17.7, 2024: 17.9, 2025: 18.15 }),
  ...TH("ar-fmp-casa-2026", "SVT", pe, "last-admitted", { 2023: 17.9, 2024: 18.1, 2025: 18.35 }),
  ...TH("ar-fmp-casa-2026", "SPC", pe, "last-admitted", { 2023: 17.6, 2024: 17.85, 2025: 18.1 }),
  ...TH("ar-fmp-casa-2026", "SMA", pe, "last-admitted", { 2023: 17.85, 2024: 18.05, 2025: 18.3 }),
  ...TH("ar-fmp-casa-2026", "SMB", pe, "last-admitted", { 2023: 17.5, 2024: 17.7, 2025: 17.95 }),
  // ENSA Marrakech / Tanger / Agadir (présélection 75/25)
  ...TH("ar-ensama-2026", "SPC", pe, "last-admitted", { 2023: 15.9, 2024: 16.1, 2025: 16.35 }),
  ...TH("ar-ensama-2026", "SMA", pe, "last-admitted", { 2023: 16.15, 2024: 16.35, 2025: 16.6 }),
  ...TH("ar-ensama-2026", "SMB", pe, "last-admitted", { 2023: 15.75, 2024: 15.95, 2025: 16.2 }),
  ...TH("ar-ensama-2026", "STM", pe, "last-admitted", { 2023: 14.2, 2024: 14.5, 2025: 14.8 }),
  ...TH("ar-ensama-2026", "STE", pe, "last-admitted", { 2023: 14.3, 2024: 14.6, 2025: 14.9 }),
  ...TH("ar-ensata-2026", "SPC", pe, "last-admitted", { 2023: 15.5, 2024: 15.75, 2025: 16.0 }),
  ...TH("ar-ensata-2026", "SMA", pe, "last-admitted", { 2023: 15.8, 2024: 16.0, 2025: 16.25 }),
  ...TH("ar-ensata-2026", "SMB", pe, "last-admitted", { 2023: 15.4, 2024: 15.6, 2025: 15.85 }),
  ...TH("ar-ensata-2026", "STM", pe, "last-admitted", { 2023: 13.9, 2024: 14.2, 2025: 14.5 }),
  ...TH("ar-ensaa-2026", "SPC", pe, "last-admitted", { 2023: 15.2, 2024: 15.5, 2025: 15.75 }),
  ...TH("ar-ensaa-2026", "SMA", pe, "last-admitted", { 2023: 15.5, 2024: 15.8, 2025: 16.05 }),
  ...TH("ar-ensaa-2026", "SMB", pe, "last-admitted", { 2023: 15.1, 2024: 15.3, 2025: 15.55 }),
  ...TH("ar-ensaa-2026", "STE", pe, "last-admitted", { 2023: 13.8, 2024: 14.0, 2025: 14.3 }),
  // ENSAM (national only)
  ...TH("ar-ensam-2026", "SPC", pe, "last-admitted", { 2023: 16.4, 2024: 16.6, 2025: 16.85 }),
  ...TH("ar-ensam-2026", "SMA", pe, "last-admitted", { 2023: 16.6, 2024: 16.8, 2025: 17.05 }),
  ...TH("ar-ensam-2026", "SMB", pe, "last-admitted", { 2023: 16.25, 2024: 16.45, 2025: 16.7 }),
  ...TH("ar-ensam-2026", "STM", pe, "last-admitted", { 2023: 14.6, 2024: 14.9, 2025: 15.1 }),
  // ENCG (80/20)
  ...TH("ar-encg-2026", "SECO", pe, "last-admitted", { 2023: 14.9, 2024: 15.15, 2025: 15.4 }),
  ...TH("ar-encg-2026", "SMA", pe, "last-admitted", { 2023: 15.2, 2024: 15.45, 2025: 15.7 }),
  ...TH("ar-encg-2026", "SPC", pe, "last-admitted", { 2023: 14.7, 2024: 14.9, 2025: 15.15 }),
  ...TH("ar-encg-2026", "LETTRES", pe, "last-admitted", { 2023: 14.0, 2024: null, 2025: 14.4 }),
  ...TH("ar-encgta-2026", "SECO", pe, "last-admitted", { 2023: 14.4, 2024: 14.7, 2025: 14.95 }),
  ...TH("ar-encgta-2026", "SMA", pe, "last-admitted", { 2023: 14.7, 2024: 14.95, 2025: 15.2 }),
  ...TH("ar-encgta-2026", "SPC", pe, "last-admitted", { 2023: 14.2, 2024: 14.4, 2025: 14.65 }),
  // FST (50/50)
  ...TH("ar-fstmo-2026", "SPC", pe, "last-admitted", { 2023: 13.9, 2024: 14.2, 2025: 14.5 }),
  ...TH("ar-fstmo-2026", "SMA", pe, "last-admitted", { 2023: 14.2, 2024: 14.5, 2025: 14.8 }),
  ...TH("ar-fstmo-2026", "STM", pe, "last-admitted", { 2023: 12.7, 2024: 13.0, 2025: 13.3 }),
  ...TH("ar-fstmo-2026", "STE", pe, "last-admitted", { 2023: 12.8, 2024: 13.1, 2025: 13.4 }),
  ...TH("ar-fstfe-2026", "SPC", pe, "last-admitted", { 2023: 13.5, 2024: 13.8, 2025: 14.1 }),
  ...TH("ar-fstfe-2026", "SMA", pe, "last-admitted", { 2023: 13.8, 2024: 14.1, 2025: 14.4 }),
  ...TH("ar-fstfe-2026", "STM", pe, "last-admitted", { 2023: 12.3, 2024: 12.6, 2025: 12.9 }),
  // EST (national only)
  ...TH("ar-estc-2026", "SPC", pe, "last-admitted", { 2023: 13.4, 2024: 13.7, 2025: 14.0 }),
  ...TH("ar-estc-2026", "SMA", pe, "last-admitted", { 2023: 13.7, 2024: 14.0, 2025: 14.3 }),
  ...TH("ar-estc-2026", "STM", pe, "last-admitted", { 2023: 12.5, 2024: 12.8, 2025: 13.1 }),
  ...TH("ar-estc-2026", "STE", pe, "last-admitted", { 2023: 12.6, 2024: 12.9, 2025: 13.2 }),
  ...TH("ar-ests-2026", "SECO", pe, "last-admitted", { 2023: 12.2, 2024: 12.5, 2025: 12.8 }),
  ...TH("ar-ests-2026", "SMA", pe, "last-admitted", { 2023: 12.9, 2024: 13.2, 2025: 13.5 }),
  // IAV & INSEA (présélection avant concours)
  ...TH("ar-iav-2026", "SVT", pe, "last-admitted", { 2023: 15.9, 2024: 16.1, 2025: 16.35 }),
  ...TH("ar-iav-2026", "SPC", pe, "last-admitted", { 2023: 15.6, 2024: 15.8, 2025: 16.05 }),
  ...TH("ar-iav-2026", "SMA", pe, "last-admitted", { 2023: 15.8, 2024: 16.0, 2025: 16.25 }),
  ...TH("ar-insea-2026", "SMA", pe, "last-admitted", { 2023: 16.9, 2024: 17.1, 2025: 17.35 }),
  ...TH("ar-insea-2026", "SMB", pe, "last-admitted", { 2023: 16.5, 2024: 16.7, 2025: 16.95 }),
  ...TH("ar-insea-2026", "SPC", pe, "last-admitted", { 2023: 16.4, 2024: 16.6, 2025: 16.85 }),
  // UM6SS médecine (privé)
  ...TH("ar-um6ss-2026", "SVT", "final", "last-admitted", { 2023: 15.3, 2024: 15.5, 2025: 15.8 }),
  ...TH("ar-um6ss-2026", "SPC", "final", "last-admitted", { 2023: 15.0, 2024: 15.2, 2025: 15.5 }),
  ...TH("ar-um6ss-2026", "SMA", "final", "last-admitted", { 2023: 15.2, 2024: 15.4, 2025: 15.7 }),
  // ENA architecture
  ...TH("ar-ena-2026", "SMA", "final", "last-admitted", { 2023: 14.2, 2024: null, 2025: 14.7 }),
  ...TH("ar-ena-2026", "SPC", "final", "last-admitted", { 2023: 13.9, 2024: 14.1, 2025: 14.4 }),
];

/* ----------------------------- scholarships ----------------------------- */
export const SCHOLARSHIPS: Scholarship[] = [
  {
    id: "sc-minhaty1", name_fr: "Bourse d'études — Palier 1 (social)", name_ar: "منحة دراسية — الشطر الأول (اجتماعي)",
    provider_fr: "État marocain / ONOUSC (Minhaty)", provider_ar: "الدولة المغربية / المكتب الوطني (منحتي)",
    type: "state-need", ageCap: 26, minBacGrade: null, needsRSU: true, honoursRequired: false, forSectors: ["public"], fields: null,
    amountMAD: 6334, payment_fr: "Par année universitaire", payment_ar: "عن السنة الجامعية",
    renewal_fr: "Renouvelable sous conditions de réussite jusqu'en master", renewal_ar: "قابلة للتجديد بشروط النجاح إلى الماستر",
    window_fr: "Demande en ligne juste après les résultats du bac", window_ar: "طلب عبر الإنترنت مباشرة بعد نتائج البكالوريا",
    deadlineISO: "2026-07-31",
    docs_fr: ["Baccalauréat ou relevé de notes", "CIN du demandeur", "Preuve d'inscription au RSU (registre social)", "Attestation de scolarité"],
    docs_ar: ["شهادة البكالوريا أو كشف النقط", "البطاقة الوطنية", "إثبات التسجيل في السجل الاجتماعي الموحد", "شهادة التمدرس"],
    howto_fr: "Créer un compte sur minhaty.ma, remplir le formulaire et suivre le dossier en ligne. Aucun déplacement nécessaire pour la demande.",
    howto_ar: "أنشئ حساباً على minhaty.ma واملأ الاستمارة وتتبع الملف عبر الإنترنت. لا حاجة للتنقل لتقديم الطلب.",
    officialUrl: "https://www.minhaty.ma", sourceId: "src-press-2024", lastVerified: VERIFIED,
  },
  {
    id: "sc-minhaty2", name_fr: "Bourse d'études — Palier 2 (social et scientifique)", name_ar: "منحة دراسية — الشطر الثاني (اجتماعي وعلمي)",
    provider_fr: "État marocain / ONOUSC (Minhaty)", provider_ar: "الدولة المغربية / المكتب الوطني (منحتي)",
    type: "state-need", ageCap: 30, minBacGrade: null, needsRSU: true, honoursRequired: false, forSectors: ["public"], fields: null,
    amountMAD: 7334, payment_fr: "Par année universitaire", payment_ar: "عن السنة الجامعية",
    renewal_fr: "Pour étudiants déjà boursiers palier 1 ou nouveaux inscrits sous conditions", renewal_ar: "للطلبة حاملي الشطر الأول سابقاً أو المسجلين الجدد بشروط",
    window_fr: "Même plateforme et calendrier que le palier 1", window_ar: "نفس المنصة والتوقيت مع الشطر الأول",
    deadlineISO: "2026-07-31",
    docs_fr: ["Mêmes pièces que le palier 1", "Attestation de réussite de l'année précédente le cas échéant"],
    docs_ar: ["نفس وثائق الشطر الأول", "شهادة النجاح للسنة الماضية عند الاقتضاء"],
    howto_fr: "Demande en ligne sur minhaty.ma. Ne pas être fonctionnaire ni salarié.",
    howto_ar: "الطلب عبر منحة الإنترنت minhaty.ma. يجب ألا تكون موظفاً ولا أجيراً.",
    officialUrl: "https://www.minhaty.ma", sourceId: "src-press-2024", lastVerified: VERIFIED,
  },
  {
    id: "sc-excellence", name_fr: "Bourses d'excellence du Ministère", name_ar: "منح التفوق الوزارية",
    provider_fr: "Ministère de l'Enseignement Supérieur", provider_ar: "وزارة التعليم العالي",
    type: "merit", ageCap: null, minBacGrade: 16, needsRSU: false, honoursRequired: true, forSectors: null, fields: null,
    amountMAD: null, payment_fr: "Montant non publié — vérifier l'appel annuel", payment_ar: "المبلغ غير منشور — راجع الإعلان السنوي",
    renewal_fr: "Selon l'appel à candidatures annuel", renewal_ar: "حسب الإعلان السنوي",
    window_fr: "Appel annuel publié sur les canaux officiels", window_ar: "إعلان سنوي عبر القنوات الرسمية",
    deadlineISO: null,
    docs_fr: ["Baccalauréat avec mentions", "Dossier académique"], docs_ar: ["بكالوريا بميزات", "ملف أكاديمي"],
    howto_fr: "Suivre l'appel officiel ; les meilleurs dossiers par filière sont présélectionnés.",
    howto_ar: "تتبع الإعلان الرسمي؛ تنتقي أفضل الملفات حسب الشعبة.",
    officialUrl: "https://www.enssup.gov.ma", sourceId: "src-enssup", lastVerified: VERIFIED,
  },
  {
    id: "sc-uir-merit", name_fr: "Bourses au mérite UIR (frais de scolarité)", name_ar: "منح الاستحقاق بالجامعة الدولية للرباط",
    provider_fr: "Université Internationale de Rabat", provider_ar: "الجامعة الدولية للرباط",
    type: "private", ageCap: null, minBacGrade: 14, needsRSU: false, honoursRequired: false, forSectors: ["private"], fields: null,
    amountMAD: null, payment_fr: "Réduction sur les droits, selon note du bac (barème publié par l'université)", payment_ar: "تخفيض من الرسوم حسب نقطة البكالوريا (سلم تنشره الجامعة)",
    renewal_fr: "Conditionnée aux résultats annuels", renewal_ar: "مشروطة بالنتائج السنوية",
    window_fr: "Lors de la candidature en ligne", window_ar: "عند الترشيح عبر الإنترنت",
    deadlineISO: "2026-08-31",
    docs_fr: ["Relevés du bac", "Formulaire de bourse"], docs_ar: ["كشوف البكالوريا", "استمارة المنحة"],
    howto_fr: "Demande intégrée au formulaire d'admission en ligne.", howto_ar: "الطلب مدمج في استمارة القبول عبر الإنترنت.",
    officialUrl: "https://www.uir.ac.ma", sourceId: "src-uir", lastVerified: VERIFIED,
  },
  {
    id: "sc-fondation", name_fr: "Bourses de fondations et entreprises", name_ar: "منح المؤسسات والشركات",
    provider_fr: "Fondations et entreprises marocaines", provider_ar: "المؤسسات والشركات المغربية",
    type: "foundation", ageCap: null, minBacGrade: null, needsRSU: false, honoursRequired: false, forSectors: null, fields: null,
    amountMAD: null, payment_fr: "Variable selon programme et promoteur", payment_ar: "متغير حسب البرنامج والجهة",
    renewal_fr: "Selon le programme", renewal_ar: "حسب البرنامج",
    window_fr: "Fenêtres variables dans l'année", window_ar: "نوافذ متفرقة خلال السنة",
    deadlineISO: null,
    docs_fr: ["Dossier social et académique", "Lettre de motivation"], docs_ar: ["ملف اجتماعي وأكاديمي", "رسالة تحفيز"],
    howto_fr: "Rechercher les fondations actives dans votre ville et suivre leurs appels annuels.",
    howto_ar: "ابحث عن المؤسسات النشطة في مدينتك وتتبع إعلاناتها السنوية.",
    officialUrl: "https://www.enssup.gov.ma", sourceId: "src-enssup", lastVerified: VERIFIED,
  },
  {
    id: "sc-abroad", name_fr: "Bourses d'études à l'étranger", name_ar: "منح الدراسة بالخارج",
    provider_fr: "État marocain et gouvernements étrangers", provider_ar: "الدولة المغربية وحكومات أجنبية",
    type: "abroad", ageCap: null, minBacGrade: 15, needsRSU: false, honoursRequired: false, forSectors: null, fields: null,
    amountMAD: null, payment_fr: "Selon pays et programme", payment_ar: "حسب البلد والبرنامج",
    renewal_fr: "Selon le programme", renewal_ar: "حسب البرنامج",
    window_fr: "Appels gouvernementaux, souvent octobre–février", window_ar: "إعلانات حكومية، غالباً أكتوبر–فبراير",
    deadlineISO: null,
    docs_fr: ["Excellent dossier académique", "Tests de langue selon destination"], docs_ar: ["ملف أكاديمي ممتاز", "اختبارات لغة حسب الوجهة"],
    howto_fr: "Suivre les appels du Ministère et des ambassadeurs/programmes pays (France, Espagne, Chine…).",
    howto_ar: "تتبع إعلانات الوزارة وبرامج البلدان (فرنسا، إسبانيا، الصين…).",
    officialUrl: "https://www.enssup.gov.ma", sourceId: "src-enssup", lastVerified: VERIFIED,
  },
];

/* ------------------------------- calendar ------------------------------- */
export const EVENTS: CalendarEvent[] = [
  { id: "ev-med-deadline", title_fr: "Clôture candidatures — Concours médecine", title_ar: "آخر أجل للترشيح — مباراة الطب", institutionId: "fmp-rabat", kind: "registration", dateStart: "2026-06-30", dateEnd: null, note_fr: "Dossier en ligne sur la plateforme du concours commun.", note_ar: "الملف عبر الإنترنت على منصة المباراة المشتركة.", sourceId: "src-med-concours" },
  { id: "ev-med-prel", title_fr: "Résultats de présélection — Médecine", title_ar: "نتائج الانتقاء الأولي — الطب", institutionId: "fmp-rabat", kind: "preselection", dateStart: "2026-07-10", dateEnd: null, note_fr: "Consultable en ligne.", note_ar: "تطالع عبر الإنترنت.", sourceId: "src-med-concours" },
  { id: "ev-med-exam", title_fr: "Épreuves écrites — Concours médecine", title_ar: "الاختبارات الكتابية — مباراة الطب", institutionId: "fmp-rabat", kind: "exam", dateStart: "2026-07-25", dateEnd: null, note_fr: "QCM dans les centres de concours.", note_ar: "أسئلة متعددة الخيارات بمراكز المباراة.", sourceId: "src-med-concours" },
  { id: "ev-ensa-deadline", title_fr: "Clôture candidatures — Réseau ENSA", title_ar: "آخر أجل للترشيح — مدارس ENSA", institutionId: "ensa-marrakech", kind: "registration", dateStart: "2026-06-28", dateEnd: null, note_fr: "Valable pour toutes les ENSA.", note_ar: "يسري على جميع مدارس إنسا.", sourceId: "src-ensa-net" },
  { id: "ev-ensa-exam", title_fr: "Concours écrit commun — ENSA", title_ar: "المباراة الكتابية المشتركة — إنسا", institutionId: "ensa-marrakech", kind: "exam", dateStart: "2026-07-21", dateEnd: null, note_fr: "Réservé aux présélectionnés.", note_ar: "للمقبولين في الانتقاء الأولي.", sourceId: "src-ensa-net" },
  { id: "ev-encg-tafem", title_fr: "TAFEM — ENCG", title_ar: "اختبار التافيم — إنسج", institutionId: "encg-casa", kind: "exam", dateStart: "2026-07-27", dateEnd: null, note_fr: "Test d'aptitude national.", note_ar: "اختبار وطني للقدرات.", sourceId: "src-encg-net" },
  { id: "ev-fst-exam", title_fr: "Examens d'accès — FST", title_ar: "امتحانات الولوج — كليات العلوم والتقنيات", institutionId: "fst-mohammedia", kind: "exam", dateStart: "2026-07-22", dateEnd: null, note_fr: "Après présélection 50/50.", note_ar: "بعد انتقاء 50/50.", sourceId: "src-fst-net" },
  { id: "ev-est-deadline", title_fr: "Clôture candidatures — EST", title_ar: "آخر أجل للترشيح — المدارس العليا للتكنولوجيا", institutionId: "est-casa", kind: "registration", dateStart: "2026-07-03", dateEnd: null, note_fr: "Sur la plateforme nationale.", note_ar: "على المنصة الوطنية.", sourceId: "src-est-net" },
  { id: "ev-cpge-deadline", title_fr: "Clôture dossiers — CPGE", title_ar: "آخر أجل للملفات — الأقسام التحضيرية", institutionId: "cpge-rabat", kind: "registration", dateStart: "2026-07-05", dateEnd: null, note_fr: "Dossier scolaire complet.", note_ar: "الملف الدراسي الكامل.", sourceId: "src-cursussup" },
  { id: "ev-minhaty-open", title_fr: "Ouverture des demandes — Minhaty", title_ar: "فتح الطلبات — منحتي", institutionId: null, kind: "scholarship", dateStart: "2026-06-19", dateEnd: null, note_fr: "Juste après les résultats du bac.", note_ar: "مباشرة بعد نتائج البكالوريا.", sourceId: "src-minhaty" },
  { id: "ev-minhaty-close", title_fr: "Clôture des demandes — Minhaty", title_ar: "إغلاق الطلبات — منحتي", institutionId: null, kind: "scholarship", dateStart: "2026-07-31", dateEnd: null, note_fr: "Ne pas rater la fenêtre : aucune prolongation garantie.", note_ar: "لا تفوّت المهلة: لا تمديد مضمون.", sourceId: "src-minhaty" },
  { id: "ev-iav-exam", title_fr: "Épreuves — IAV Hassan II", title_ar: "اختبارات — معهد الحسن الثاني", institutionId: "iav-rabat", kind: "exam", dateStart: "2026-07-18", dateEnd: null, note_fr: "Après présélection.", note_ar: "بعد الانتقاء الأولي.", sourceId: "src-iav" },
  { id: "ev-ena-exam", title_fr: "Concours — École Nationale d'Architecture", title_ar: "مباراة — المدرسة الوطنية للهندسة المعمارية", institutionId: "ena-rabat", kind: "exam", dateStart: "2026-07-30", dateEnd: null, note_fr: "Dessin, expression, culture générale.", note_ar: "رسم وتعبير وثقافة عامة.", sourceId: "src-enssup" },
  { id: "ev-uir-deadline", title_fr: "Clôture admissions — UIR", title_ar: "آخر أجل للقبول — الجامعة الدولية للرباط", institutionId: "uir-rabat", kind: "registration", dateStart: "2026-08-31", dateEnd: null, note_fr: "Sessions d'admission mensuelles avant la clôture.", note_ar: "جلسات قبول شهرية قبل الإغلاق.", sourceId: "src-uir" },
  { id: "ev-faculty-reg", title_fr: "Inscriptions fac ouvertes — Universités", title_ar: "فتح التسجيل بالكليات", institutionId: "fsjes-casa", kind: "registration", dateStart: "2026-07-01", dateEnd: "2026-09-20", note_fr: "Inscription en ligne puis validation sur place.", note_ar: "تسجيل عبر الإنترنت ثم التأكيد بالكلية.", sourceId: "src-cursussup" },
  { id: "ev-ofppt-reg", title_fr: "Inscriptions OFPPT", title_ar: "تسجيلات مكتب التكوين المهني", institutionId: "ofppt-casa", kind: "registration", dateStart: "2026-05-20", dateEnd: "2026-07-15", note_fr: "Inscription gratuite en ligne.", note_ar: "تسجيل مجاني عبر الإنترنت.", sourceId: "src-ofppt" },
];

/* ------------------------------- look-ups ------------------------------- */
export const institutionById = (id: string) => INSTITUTIONS.find((i) => i.id === id);
export const programmeById = (id: string) => PROGRAMMES.find((p) => p.id === id);
export const programmesOf = (instId: string) => PROGRAMMES.filter((p) => p.institutionId === instId);
export const rulesOf = (progId: string) => RULES.filter((r) => r.programmeId === progId);
export const thresholdsOf = (ruleId: string) => THRESHOLDS.filter((t) => t.ruleId === ruleId);
export const sourceById = (id: string) => SOURCES.find((s) => s.id === id);
export const formulaById = (id: string | null) => FORMULAS.find((f) => f.id === id) ?? null;
