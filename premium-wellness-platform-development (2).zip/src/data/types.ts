/**
 * Data model — records are shaped like database rows. Every factual number
 * carried on screen links to a Source id and a last-verified date.
 *
 * ACCURACY CONTRACT
 * - Scores live on the /20 bac scale; other scales stored on the record.
 * - preselection thresholds and final cut-offs are never mixed.
 * - One record per academic year; history is never overwritten.
 * - A null value means "Not published" — it must never be estimated.
 */

export type BacStream = "SMA" | "SMB" | "SPC" | "SVT" | "SECO" | "LETTRES" | "STM" | "STE";
export type Sector = "public" | "private";
export type RouteType = "open" | "preselection-exam" | "exam" | "file" | "interview";
export type ThresholdStage = "preselection" | "final";
export type ThresholdKind = "cutoff" | "last-admitted";
export type Confidence = "official" | "example";
export type Lang = "fr" | "ar";

export interface Source {
  id: string;
  publisher_fr: string;
  publisher_ar: string;
  docType: "page" | "pdf" | "announcement" | "press";
  url: string;
  retrievedAt: string; // ISO date
}

export interface FormulaInput {
  key: "overall" | "national" | "regional";
  weight: number; // 0..1, all weights sum to 1
}

/** Stored AS DATA, never hard-coded in components. */
export interface Formula {
  id: string;
  label_fr: string;
  label_ar: string;
  inputs: FormulaInput[];
  scale: number; // nominative scale, e.g. 20
}

export interface Institution {
  id: string;
  name_fr: string;
  name_ar: string;
  short_fr: string;
  short_ar: string;
  aliases: string[]; // latin + arabic spellings for Darija search
  category_fr: string;
  category_ar: string;
  categoryKey:
    | "faculty" | "medicine" | "engineering" | "business" | "fst"
    | "est" | "cpge" | "institute" | "vocational" | "private";
  sector: Sector;
  city_fr: string;
  city_ar: string;
  region_key: string;
  lat: number;
  lng: number;
  website: string;
  recognition_fr: string;
  recognition_ar: string;
  lastVerified: string; // ISO
  sourceId: string;
  about_fr: string;
  about_ar: string;
}

export interface Programme {
  id: string;
  institutionId: string;
  name_fr: string;
  name_ar: string;
  field: "science" | "engineering" | "medicine" | "law" | "economics" | "letters" | "architecture" | "agronomy" | "statistics" | "media" | "health" | "business" | "tech";
  level: "DUT" | "Licence" | "Ingénieur" | "Doctorat" | "Technicien" | "CPGE";
  durationYears: number;
  languages: ("fr" | "ar" | "en")[];
  tuitionMAD: number | null; // null = not published / n/a
  seats: number | null;
}

export interface AdmissionRule {
  id: string;
  programmeId: string;
  year: number;
  streams: BacStream[];
  route: RouteType;
  formulaId: string | null; // null for open enrolment / pure file review
  notes_fr: string;
  notes_ar: string;
  registrationOpens: string;
  registrationDeadline: string;
  examDate: string | null;
  preselectionDate: string | null;
}

export interface Threshold {
  ruleId: string;
  year: number;
  stream: BacStream;
  stage: ThresholdStage;
  value: number | null; // null = Not published
  scale: number;
  kind: ThresholdKind;
  confidence: Confidence;
  sourceId: string;
  verifiedAt: string;
}

export interface Scholarship {
  id: string;
  name_fr: string;
  name_ar: string;
  provider_fr: string;
  provider_ar: string;
  type: "state-need" | "merit" | "private" | "foundation" | "abroad";
  ageCap: number | null;
  minBacGrade: number | null;
  needsRSU: boolean;
  honoursRequired: boolean;
  forSectors: Sector[] | null; // null = any
  fields: Programme["field"][] | null;
  amountMAD: number | null; // per year
  payment_fr: string;
  payment_ar: string;
  renewal_fr: string;
  renewal_ar: string;
  window_fr: string;
  window_ar: string;
  deadlineISO: string | null;
  docs_fr: string[];
  docs_ar: string[];
  howto_fr: string;
  howto_ar: string;
  officialUrl: string;
  sourceId: string;
  lastVerified: string;
}

export interface CalendarEvent {
  id: string;
  title_fr: string;
  title_ar: string;
  institutionId: string | null;
  kind: "registration" | "preselection" | "exam" | "scholarship";
  dateStart: string; // ISO
  dateEnd: string | null;
  note_fr: string;
  note_ar: string;
  sourceId: string;
}

/* ------------------------------ streams ------------------------------ */

export const STREAMS: { key: BacStream; fr: string; ar: string }[] = [
  { key: "SMA", fr: "Sciences Maths A", ar: "علوم رياضية أ" },
  { key: "SMB", fr: "Sciences Maths B", ar: "علوم رياضية ب" },
  { key: "SPC", fr: "Sciences Physiques", ar: "علوم فيزيائية" },
  { key: "SVT", fr: "Sciences de la Vie et de la Terre", ar: "علوم الحياة والأرض" },
  { key: "SECO", fr: "Sciences Économiques", ar: "علوم اقتصادية" },
  { key: "LETTRES", fr: "Lettres et Sciences Humaines", ar: "آداب وعلوم إنسانية" },
  { key: "STM", fr: "Sciences et Technologies Mécaniques", ar: "علوم وتكنولوجيات ميكانيكية" },
  { key: "STE", fr: "Sciences et Technologies Électriques", ar: "علوم وتكنولوجيات كهربائية" },
];

export const REGIONS = [
  "casa-settat", "rabat-sale", "marrakech-safi", "fes-meknes",
  "tanger-tetouan", "souss-massa", "oriental",
] as const;
export type RegionKey = (typeof REGIONS)[number];

export const streamName = (key: BacStream, lang: Lang): string =>
  STREAMS.find((s) => s.key === key)?.[lang] ?? key;
