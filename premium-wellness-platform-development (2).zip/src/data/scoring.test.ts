import { describe, expect, it } from "vitest";
import { classify, computeScore, history, requiredInputs } from "./scoring";
import type { Formula, Threshold } from "./types";

const NR_75_25: Formula = {
  id: "n75r25",
  label_fr: "N 75% + R 25%",
  label_ar: "",
  inputs: [
    { key: "national", weight: 0.75 },
    { key: "regional", weight: 0.25 },
  ],
  scale: 20,
};

const AVG50_N50: Formula = {
  id: "avg50n50",
  label_fr: "Moyenne 50% + National 50%",
  label_ar: "",
  inputs: [
    { key: "overall", weight: 0.5 },
    { key: "national", weight: 0.5 },
  ],
  scale: 20,
};

const N_ONLY: Formula = {
  id: "n-only",
  label_fr: "National uniquement",
  label_ar: "",
  inputs: [{ key: "national", weight: 1 }],
  scale: 20,
};

const BAD: Formula = { ...N_ONLY, id: "bad", inputs: [{ key: "national", weight: 0.5 }] };

const th = (year: number, value: number | null): Threshold => ({
  ruleId: "r1",
  year,
  stream: "SMA",
  stage: "preselection",
  value,
  scale: 20,
  kind: "cutoff",
  confidence: "example",
  sourceId: "src-example",
  verifiedAt: "2026-01-10",
});

describe("computeScore — every formula type", () => {
  it("computes national*0.75 + regional*0.25 (medicine/ENSA style)", () => {
    expect(computeScore(NR_75_25, { national: 16, regional: 14 })).toBe(15.5);
  });
  it("computes overall 50% + national 50% (FST style)", () => {
    expect(computeScore(AVG50_N50, { overall: 15, national: 17 })).toBe(16);
  });
  it("computes national-only (ENSAM style)", () => {
    expect(computeScore(N_ONLY, { national: 15.4 })).toBe(15.4);
  });
  it("returns null when a required exam score is missing — never guesses", () => {
    expect(computeScore(NR_75_25, { national: 16 })).toBeNull();
    expect(computeScore(AVG50_N50, { overall: 15 })).toBeNull();
  });
  it("rejects out-of-scale inputs", () => {
    expect(computeScore(N_ONLY, { national: 21 })).toBeNull();
    expect(computeScore(N_ONLY, { national: -1 })).toBeNull();
  });
  it("throws on malformed weights", () => {
    expect(() => computeScore(BAD, { national: 15 })).toThrow();
  });
});

describe("requiredInputs", () => {
  it("asks only for inputs present in the selected formulas", () => {
    expect(requiredInputs([NR_75_25, N_ONLY], ["n75r25", "n-only"]).sort()).toEqual([
      "national",
      "regional",
    ]);
    expect(requiredInputs([AVG50_N50], ["avg50n50"])).toEqual(["overall", "national"]);
  });
});

describe("classify — three result groups", () => {
  it("strong at +0.5 or more above the threshold", () => {
    const r = classify(16.5, [th(2024, 16)], "SMA", "preselection");
    expect(r.verdict).toBe("strong");
    expect(r.gap).toBe(0.5);
  });
  it("possible within the 0.5 band above and 1 below", () => {
    expect(classify(16.2, [th(2024, 16)], "SMA", "preselection").verdict).toBe("possible");
    expect(classify(15.5, [th(2024, 16)], "SMA", "preselection").verdict).toBe("possible");
  });
  it("out of reach more than 1 point below", () => {
    const r = classify(14.9, [th(2024, 16)], "SMA", "preselection");
    expect(r.verdict).toBe("outOfReach");
    expect(r.gap).toBeCloseTo(-1.1);
  });
  it("notPublished when value is null or no threshold exists", () => {
    expect(classify(16, [th(2024, null)], "SMA", "preselection").verdict).toBe("notPublished");
    expect(classify(16, [], "SMA", "preselection").verdict).toBe("notPublished");
    expect(classify(null, [th(2024, 16)], "SMA", "preselection").verdict).toBe("notPublished");
  });
  it("uses the latest year and never mixes preselection with final", () => {
    const older = th(2022, 14);
    const newer = th(2024, 16);
    const finalStage = { ...th(2024, 10), stage: "final" as const };
    expect(classify(15.7, [older, newer], "SMA", "preselection").threshold?.year).toBe(2024);
    expect(classify(15.7, [newer, finalStage], "SMA", "preselection").threshold?.value).toBe(16);
  });
});

describe("history", () => {
  it("returns ascending years and keeps null gaps", () => {
    const h = history([th(2024, 16), th(2022, 15), th(2023, null)], "r1", "SMA", "preselection");
    expect(h.map((x) => x.year)).toEqual([2022, 2023, 2024]);
    expect(h[1].value).toBeNull();
  });
});
