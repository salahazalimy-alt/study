import { ReactNode, useEffect, useState } from "react";
import { Link, NavLink, useLocation } from "react-router-dom";
import {
  AlertTriangle, ArrowLeft, Award, BookMarked, Bookmark, CalendarDays,
  CheckCircle2, ExternalLink, Flag, GitCompareArrows, GraduationCap,
  Languages, ListChecks, Moon, Search, Sun, X,
} from "lucide-react";
import { useI18n } from "./i18n";
import { useShortlist } from "./store";
import { sourceById } from "./data/records";
import type { BacStream, Lang, Threshold } from "./data/types";
import { streamName } from "./data/types";
import { cn } from "@/utils/cn";
import { fmtScore } from "./data/scoring";

/* -------------------------------- theme -------------------------------- */
const themeKey = "masar:theme";
function readTheme(): "light" | "dark" {
  try {
    const saved = localStorage.getItem(themeKey);
    if (saved === "light" || saved === "dark") return saved;
  } catch { /* ignore */ }
  return window.matchMedia?.("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}

export function useTheme() {
  const [theme, setTheme] = useState<"light" | "dark">(readTheme);
  useEffect(() => {
    document.documentElement.classList.toggle("dark", theme === "dark");
    try { localStorage.setItem(themeKey, theme); } catch { /* ignore */ }
  }, [theme]);
  return { theme, toggle: () => setTheme((t) => (t === "dark" ? "light" : "dark")) };
}

/* -------------------------------- layout ------------------------------- */
export function Logo() {
  const { lang } = useI18n();
  return (
    <Link to="/" className="flex items-center gap-2.5" aria-label="Masar home">
      <span className="grid h-9 w-9 place-items-center rounded-xl bg-[var(--c-accent)] text-white">
        <GraduationCap className="h-5 w-5" />
      </span>
      <span className="text-lg font-extrabold tracking-tight">
        {lang === "ar" ? "مسار" : "MASAR"}
        <span className="ms-1.5 hidden text-[0.7rem] font-medium text-[var(--c-faint)] sm:inline">
          {lang === "ar" ? "MASAR" : "مسار"}
        </span>
      </span>
    </Link>
  );
}

export function DemoBanner() {
  const { t } = useI18n();
  return (
    <div
      role="note"
      className="border-b border-[var(--c-warn-soft)] bg-[var(--c-demo-soft)] px-4 py-2 text-center text-[0.78rem] text-[var(--c-demo)]"
    >
      <AlertTriangle className="me-1 inline h-3.5 w-3.5 align-[-2px]" />
      <strong className="font-semibold">{t("example.bannerTitle")}</strong> — {t("example.bannerBody")}
    </div>
  );
}

export function CookieConsent() {
  const { t } = useI18n();
  const [visible, setVisible] = useState(() => {
    try { return localStorage.getItem("masar:cookie") !== "1"; } catch { return false; }
  });
  if (!visible) return null;
  return (
    <div className="fixed inset-x-0 bottom-[4.5rem] z-50 mx-auto max-w-lg px-4 sm:bottom-6">
      <div className="card flex items-center gap-4 p-4 shadow-xl">
        <p className="flex-1 text-[0.8rem] leading-snug text-[var(--c-sub)]">{t("cookie.text")}</p>
        <button
          type="button"
          className="btn btn-primary !min-h-[42px] shrink-0 px-4 py-2 text-sm"
          onClick={() => {
            setVisible(false);
            try { localStorage.setItem("masar:cookie", "1"); } catch { /* ignore */ }
          }}
        >
          {t("cookie.accept")}
        </button>
      </div>
    </div>
  );
}

export function Layout({ children }: { children: ReactNode }) {
  const { t, lang, setLang } = useI18n();
  const { theme, toggle } = useTheme();
  const shortlist = useShortlist();
  const location = useLocation();

  const navItems = [
    { to: "/schools", label: t("nav.schools") },
    { to: "/compare", label: `${t("nav.compare")}` },
    { to: "/scholarships", label: t("nav.scholarships") },
    { to: "/calendar", label: t("nav.calendar") },
    { to: "/guides", label: t("nav.guides") },
  ];

  const mobileNav = [
    { to: "/", icon: Search, label: t("nav.home") },
    { to: "/schools", icon: ListChecks, label: t("nav.schools") },
    { to: "/scholarships", icon: Award, label: t("nav.scholarships") },
    { to: "/shortlist", icon: Bookmark, label: `${t("nav.saved")} (${shortlist.items.length})` },
  ];

  return (
    <div className="min-h-screen pb-[4.6rem] sm:pb-0">
      <DemoBanner />
      <header className="sticky top-0 z-40 border-b border-[var(--c-line)] bg-[color-mix(in_srgb,var(--c-bg)_88%,transparent)] backdrop-blur-lg">
        <div className="mx-auto flex h-16 max-w-6xl items-center gap-3 px-4 sm:px-6">
          <Logo />
          <nav className="ms-4 hidden items-center gap-1 md:flex" aria-label="Primary">
            {navItems.map((n) => (
              <NavLink
                key={n.to}
                to={n.to}
                className={({ isActive }) =>
                  cn(
                    "rounded-lg px-3 py-2 text-[0.88rem] font-medium transition-colors",
                    isActive
                      ? "bg-[var(--c-accent-soft)] text-[var(--c-accent)]"
                      : "text-[var(--c-sub)] hover:text-[var(--c-ink)]"
                  )
                }
              >
                {n.label}
              </NavLink>
            ))}
          </nav>
          <div className="ms-auto flex items-center gap-1.5">
            <Link
              to="/shortlist"
              aria-label={t("nav.saved")}
              className="relative grid h-11 w-11 place-items-center rounded-xl text-[var(--c-sub)] transition-colors hover:bg-[var(--c-accent-soft)] hover:text-[var(--c-accent)]"
            >
              <BookMarked className="h-5 w-5" />
              {shortlist.items.length > 0 && (
                <span className="absolute -end-0.5 -top-0.5 grid h-5 w-5 place-items-center rounded-full bg-[var(--c-accent)] text-[0.62rem] font-bold text-white">
                  {shortlist.items.length}
                </span>
              )}
            </Link>
            <button
              type="button"
              onClick={toggle}
              aria-label={theme === "dark" ? t("theme.light") : t("theme.dark")}
              className="grid h-11 w-11 place-items-center rounded-xl text-[var(--c-sub)] transition-colors hover:bg-[var(--c-accent-soft)] hover:text-[var(--c-accent)]"
            >
              {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </button>
            <button
              type="button"
              onClick={() => setLang(lang === "ar" ? "fr" : "ar")}
              className={cn(
                "flex h-11 items-center gap-1.5 rounded-xl border-[1.5px] border-[var(--c-line-strong)] px-3.5 text-[0.86rem] font-semibold text-[var(--c-ink)] transition-colors hover:border-[var(--c-accent)]"
              )}
            >
              <Languages className="h-4 w-4" />
              {t("lang.switch")}
            </button>
          </div>
        </div>
      </header>

      <div className="min-h-[60vh]">{children}</div>

      {/* Footer */}
      <footer className="mt-16 border-t border-[var(--c-line)] px-4 py-10 sm:px-6">
        <div className="mx-auto flex max-w-6xl flex-col gap-6 sm:flex-row sm:items-start sm:justify-between">
          <div className="max-w-md">
            <Logo />
            <p className="mt-4 text-[0.82rem] leading-relaxed text-[var(--c-sub)]">{t("legal.independence")}</p>
            <p className="mt-2 text-[0.82rem] leading-relaxed text-[var(--c-sub)]">{t("legal.disclaimer")}</p>
          </div>
          <nav className="flex flex-col gap-2.5 text-[0.86rem]" aria-label="Footer">
            <Link to="/guides" className="font-medium text-[var(--c-sub)] hover:text-[var(--c-accent)]">{t("nav.guides")}</Link>
            <Link to="/legal" className="font-medium text-[var(--c-sub)] hover:text-[var(--c-accent)]">{t("legal.title")}</Link>
            <Link to="/admin" className="font-medium text-[var(--c-sub)] hover:text-[var(--c-accent)]">{t("nav.admin")}</Link>
          </nav>
        </div>
        <p className="mx-auto mt-8 max-w-6xl border-t border-[var(--c-line)] pt-5 text-[0.72rem] text-[var(--c-faint)]">
          MASAR مسار · {new Date().getFullYear()} · {location.pathname}
        </p>
      </footer>

      {/* Mobile bottom nav */}
      <nav
        className="mobile-bar grid grid-cols-4 gap-1 sm:hidden"
        aria-label="Quick actions"
      >
        {mobileNav.map((n) => {
          const active = n.to === "/" ? location.pathname === "/" : location.pathname.startsWith(n.to);
          return (
            <Link
              key={n.to}
              to={n.to}
              className={cn(
                "flex min-h-[48px] flex-col items-center justify-center gap-0.5 rounded-xl text-[0.66rem] font-semibold transition-colors",
                active ? "text-[var(--c-accent)]" : "text-[var(--c-faint)]"
              )}
            >
              <n.icon className="h-5 w-5" />
              {n.label}
            </Link>
          );
        })}
      </nav>

      <CookieConsent />
    </div>
  );
}

/* ------------------------------- sections ------------------------------ */
export function PageTitle({ eyebrow, title, intro }: { eyebrow: string; title: string; intro?: string }) {
  return (
    <header className="mx-auto max-w-3xl px-4 pt-10 sm:px-6 sm:pt-14">
      <p className="eyebrow">{eyebrow}</p>
      <h1 className="mt-3 text-[clamp(1.6rem,4.5vw,2.4rem)] font-extrabold leading-tight tracking-tight text-[var(--c-ink)]">
        {title}
      </h1>
      {intro && <p className="mt-4 leading-relaxed text-[var(--c-sub)]">{intro}</p>}
    </header>
  );
}

export function BackLink({ to = "/" }: { to?: string }) {
  const { t } = useI18n();
  return (
    <Link to={to} className="inline-flex items-center gap-1.5 text-[0.84rem] font-semibold text-[var(--c-sub)] hover:text-[var(--c-accent)]">
      <ArrowLeft className="mirror-icon h-4 w-4" />
      {t("back")}
    </Link>
  );
}

export function EmptyState({ title, body }: { title?: string; body?: string }) {
  const { t } = useI18n();
  return (
    <div className="card fade-up grid place-items-center gap-2 px-6 py-12 text-center">
      <Search className="h-6 w-6 text-[var(--c-faint)]" />
      <p className="font-bold text-[var(--c-ink)]">{title ?? t("empty.title")}</p>
      <p className="max-w-sm text-[0.86rem] text-[var(--c-sub)]">{body ?? t("empty.body")}</p>
    </div>
  );
}

export function SkeletonCard() {
  return (
    <div className="card space-y-3 p-5" aria-hidden>
      <div className="skeleton h-4 w-2/3" />
      <div className="skeleton h-3 w-1/2" />
      <div className="skeleton h-8 w-full" />
    </div>
  );
}

/* ------------------------------ trust bits ------------------------------ */
export function SourceNote({ sourceId, verifiedAt }: { sourceId: string; verifiedAt: string }) {
  const { t, lang, fmtDate } = useI18n();
  const src = sourceById(sourceId);
  return (
    <p className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[0.7rem] text-[var(--c-faint)]">
      <span className="tag tag-demo">{t("example.badge")}</span>
      {src && (
        <a href={src.url} target="_blank" rel="noreferrer" className="inline-flex items-center gap-0.5 underline decoration-dotted underline-offset-2 hover:text-[var(--c-accent)]">
          {t("source.label")}: {lang === "ar" ? src.publisher_ar : src.publisher_fr}
          <ExternalLink className="h-3 w-3" />
        </a>
      )}
      <span>· {t("verified.on")} {fmtDate(verifiedAt)}</span>
    </p>
  );
}

export function ThresholdValue({ t: th, big = false }: { t: Threshold | null | undefined; big?: boolean }) {
  const { t: tr, lang } = useI18n();
  if (!th || th.value === null) {
    return <span className="text-[0.85rem] font-medium text-[var(--c-faint)]">{tr("notPublished")}</span>;
  }
  return (
    <span className={cn("num font-bold text-[var(--c-ink)]", big ? "text-2xl" : "text-[0.95rem]")}>
      {fmtScore(th.value, lang === "ar" ? "ar-MA-u-nu-latn" : "fr-MA")}
      <span className="ms-1 text-[0.68rem] font-medium text-[var(--c-faint)]">/20</span>
    </span>
  );
}

export function ReportError({ contextLabel }: { contextLabel: string }) {
  const { t } = useI18n();
  const [open, setOpen] = useState(false);
  const [msg, setMsg] = useState("");
  const [sent, setSent] = useState(false);

  function submit() {
    try {
      const existing = JSON.parse(localStorage.getItem("masar:reports") ?? "[]") as unknown[];
      existing.push({ at: new Date().toISOString(), context: contextLabel, message: msg });
      localStorage.setItem("masar:reports", JSON.stringify(existing));
    } catch { /* ignore */ }
    setSent(true);
    setMsg("");
  }

  return (
    <div className="inline-block">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border-[1.5px] border-[var(--c-line)] px-3 text-[0.78rem] font-semibold text-[var(--c-sub)] transition-colors hover:border-[var(--c-warn)] hover:text-[var(--c-warn)]"
      >
        <Flag className="h-3.5 w-3.5" />
        {t("error.report")}
      </button>
      {open && (
        <div className="fade-up card mt-2 w-72 p-4 shadow-xl">
          {sent ? (
            <p className="flex items-start gap-2 text-[0.82rem] text-[var(--c-good)]">
              <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" />
              {t("error.sent")}
            </p>
          ) : (
            <>
              <label htmlFor="report-msg" className="label">{contextLabel}</label>
              <textarea
                id="report-msg"
                rows={3}
                value={msg}
                onChange={(e) => setMsg(e.target.value)}
                className="field !min-h-0 text-sm"
                placeholder="…"
              />
              <div className="mt-2 flex gap-2">
                <button
                  type="button"
                  onClick={submit}
                  disabled={msg.trim().length < 4}
                  className="btn btn-primary !min-h-[40px] flex-1 px-3 py-1.5 text-sm disabled:opacity-40"
                >
                  {t("share")}
                </button>
                <button type="button" onClick={() => setOpen(false)} aria-label="close" className="btn btn-icon btn-outline !min-h-[40px]">
                  <X className="h-4 w-4" />
                </button>
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
}

/* -------------------------------- charts -------------------------------- */
const SERIES_COLORS = ["#0e7a5f", "#2a5ea8", "#946200", "#a33b32", "#7048a6", "#0e7a8f", "#a85000", "#407040"];

export interface TrendSeries {
  stream: BacStream;
  points: { year: number; value: number | null }[];
}

export function TrendChart({ series, height = 220, label }: { series: TrendSeries[]; height?: number; label: string }) {
  const { lang, fmtNum, t } = useI18n();
  const years = [...new Set(series.flatMap((s) => s.points.map((p) => p.year)))].sort((a, b) => a - b);
  const allVals = series.flatMap((s) => s.points.map((p) => p.value)).filter((v): v is number => v !== null);
  if (allVals.length === 0) return null;
  const minV = Math.min(...allVals) - 0.5;
  const maxV = Math.max(...allVals) + 0.5;

  const W = 640, H = height, padL = 44, padR = 14, padT = 18, padB = 34;
  const x = (year: number) =>
    years.length === 1 ? W / 2 : padL + ((year - years[0]) / (years[years.length - 1] - years[0])) * (W - padL - padR);
  const y = (v: number) => padT + (1 - (v - minV) / (maxV - minV || 1)) * (H - padT - padB);

  return (
        <figure role="img" aria-label={label} className="w-full">
      <svg viewBox={`0 0 ${W} ${H}`} className="h-auto w-full" style={{ direction: "ltr" }}>
        {/* gridlines */}
        {[0, 0.25, 0.5, 0.75, 1].map((f) => {
          const val = minV + f * (maxV - minV);
          return (
            <g key={f}>
              <line x1={padL} x2={W - padR} y1={y(val)} y2={y(val)} stroke="var(--c-line)" strokeDasharray="4 5" />
              <text x={padL - 8} y={y(val) + 4} textAnchor="end" fontSize="11" fill="var(--c-faint)" className="num">
                {fmtNum(val, { maximumFractionDigits: 1 })}
              </text>
            </g>
          );
        })}
        {years.map((yr) => (
          <text key={yr} x={x(yr)} y={H - 12} textAnchor="middle" fontSize="12" fontWeight="600" fill="var(--c-sub)" className="num">
            {yr}
          </text>
        ))}
        {series.map((s, si) => {
          const color = SERIES_COLORS[si % SERIES_COLORS.length];
          const segments: { year: number; value: number }[][] = [];
          let cur: { year: number; value: number }[] = [];
          for (const p of s.points.slice().sort((a, b) => a.year - b.year)) {
            if (p.value === null) { if (cur.length) segments.push(cur); cur = []; }
            else cur.push({ year: p.year, value: p.value });
          }
          if (cur.length) segments.push(cur);
          return (
            <g key={s.stream}>
              {segments.map((seg, i) => (
                <polyline
                  key={i}
                  fill="none"
                  stroke={color}
                  strokeWidth="2.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeDasharray={seg.length === 1 ? "1 0.1" : undefined}
                  points={seg.map((p) => `${x(p.year)},${y(p.value)}`).join(" ")}
                />
              ))}
              {s.points.filter((p) => p.value !== null).map((p) => (
                <circle key={p.year} cx={x(p.year)} cy={y(p.value!)} r="4.5" fill="var(--c-surface)" stroke={color} strokeWidth="2.5" />
              ))}
              {s.points.filter((p) => p.value === null).map((p) => (
                <g key={p.year}>
                  <rect x={x(p.year) - 3} y={y((minV + maxV) / 2) - 3} width="6" height="6" rx="1.5" fill="none" stroke="var(--c-faint)" strokeDasharray="2 2" />
                </g>
              ))}
            </g>
          );
        })}
      </svg>
      <figcaption className="mt-1 flex flex-wrap gap-x-5 gap-y-1.5">
        {series.map((s, si) => (
          <span key={s.stream} className="inline-flex items-center gap-1.5 text-[0.74rem] font-semibold text-[var(--c-sub)]">
            <span className="inline-block h-1 w-4 rounded-full" style={{ background: SERIES_COLORS[si % SERIES_COLORS.length] }} />
            {streamName(s.stream, lang as Lang)}
          </span>
        ))}
        <span className="inline-flex items-center gap-1.5 text-[0.74rem] text-[var(--c-faint)]">
          <span className="inline-block h-2.5 w-2.5 rounded-sm border border-dashed border-[var(--c-faint)]" />
          {t("notPublished")}
        </span>
      </figcaption>
    </figure>
  );
}

export function Sparkline({ points }: { points: (number | null)[] }) {
  const vals = points.filter((v): v is number => v !== null);
  if (vals.length < 2) return <span className="text-[0.75rem] text-[var(--c-faint)]">—</span>;
  const min = Math.min(...vals), max = Math.max(...vals);
  const W = 76, H = 26;
  const pts = points.map((v, i) => {
    if (v === null) return null;
    const px = (i / (points.length - 1)) * W;
    const py = H - ((v - min) / (max - min || 1)) * (H - 6) - 3;
    return `${px},${py}`;
  });
  const path = pts.filter(Boolean).join(" ");
  return (
    <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} aria-hidden style={{ direction: "ltr" }}>
      <polyline points={path} fill="none" stroke="var(--c-accent)" strokeWidth="2.2" strokeLinecap="round" />
    </svg>
  );
}

/* ------------------------- badge tokens reused ------------------------- */
export { CalendarDays, GitCompareArrows };
