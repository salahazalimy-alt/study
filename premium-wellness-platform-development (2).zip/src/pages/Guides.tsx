import { useState } from "react";
import { BookOpen, ChevronDown, Globe, HelpCircle, Map as MapIcon } from "lucide-react";
import { useI18n } from "@/i18n";
import { PageTitle } from "@/components";
import { STREAMS } from "@/data/types";
import { cn } from "@/utils/cn";

const STREAM_MAP: Record<string, { fr: string; ar: string }> = {
  SMA: { fr: "Ingénierie (ENSA/ENSAM), INSEA, CPGE MPSI, médecine, FST, écoles privées d'ingénieurs.", ar: "الهندسة (إنسا/إنسام)، إنسيا، الأقسام التحضيرية MPSI، الطب، كليات العلوم والتقنيات، المدارس الخاصة." },
  SMB: { fr: "Mêmes portes que SMA avec seuils parfois plus souples ; CPGE PSI orienté théorie.", ar: "نفس الأبواب مع عتبات أحياناً أخف؛ تحضيري PSI بتوجه نظري." },
  SPC: { fr: "Médecine, ENSA/ENSAM, FST, IAV, ENA architecture, écoles privées santé/ingénierie.", ar: "الطب، إنسا/إنسام، كليات العلوم والتقنيات، معهد الزراعة، المعمار، مدارس خاصة." },
  SVT: { fr: "Médecine et santé avant tout, IAV, biologie en faculté des sciences, ISPITS.", ar: "الطب والصحة أولاً، معهد الزراعة، البيولوجيا بكلية العلوم، معاهد الصحة." },
  SECO: { fr: "ENCG-TAFEM, FSJES économie/gestion, ISCAE (via prépa), EST techniques de management.", ar: "إنسج، كليات الاقتصاد والتدبير، إسكاي عن طريق التحضيرية، إست تقنيات التدبير." },
  LETTRES: { fr: "Facultés de lettres/droit, ISIC journalisme, enseignement, certaines ENCG.", ar: "كليات الآداب والحقوق، المعهد العالي للإعلام، التعليم، وبعض مدارس التجارة." },
  STM: { fr: "EST (génie mécanique), ENSA avec seuils dédiés, OFPPT, licences professionnelles.", ar: "إست (ميكانيكا)، إنسا بعتبات مخصصة، أوفبت، إجازات مهنية." },
  STE: { fr: "EST (génie électrique), ENSA avec seuils dédiés, OFPPT, FST.", ar: "إست (كهرباء)، إنسا بعتبات مخصصة، أوفبت، كليات العلوم والتقنيات." },
};

const PLATFORMS: { name: string; fr: string[]; ar: string[] }[] = [
  {
    name: "Cursussup",
    fr: [
      "Créez un compte sur cursussup.gov.ma avec votre code Massar.",
      "Complétez le dossier (relevés, choix de filières, villes).",
      "Classez vos vœux par ordre de préférence avant la date limite.",
      "Suivez les résultats de présélection et confirmez chaque convocation.",
    ],
    ar: [
      "أنشئ حساباً على cursussup.gov.ma برمز ماسار.",
      "أكمل الملف: كشوف النقط، اختيار الشعب والمدن.",
      "رتب رغباتك حسب الأفضلية قبل آخر أجل.",
      "تتبع نتائج الانتقاء الأولي وأكد كل استدعاء.",
    ],
  },
  {
    name: "Minhaty (bourses)",
    fr: [
      "Connectez-vous sur minhaty.ma après les résultats du bac.",
      "Vérifiez que la famille est inscrite au RSU (registre social unifié).",
      "Téléversez la preuve RSU, la CIN et l'attestation de scolarité.",
      "Suivez le dossier en ligne ; aucun déplacement n'est requis pour la demande.",
    ],
    ar: [
      "ادخل إلى minhaty.ma بعد نتائج البكالوريا.",
      "تأكد أن العائلة مسجلة في السجل الاجتماعي الموحد.",
      "حمّل إثبات السجل، البطاقة الوطنية وشهادة التمدرس.",
      "تتبع الملف إلكترونياً؛ لا حاجة للتنقل.",
    ],
  },
  {
    name: "Concours (médecine, ENSA, ENCG…)",
    fr: [
      "Chaque réseau a son site de candidature : déposez le dossier en ligne à temps.",
      "Présélection publiée par liste : surveillez la date annoncée.",
      "Présentez-vous au concours écrit avec convocation imprimée.",
      "Les résultats finaux ouvrent l'inscription définitive, avec délai strict.",
    ],
    ar: [
      "كل شبكة لها موقع ترشيح: قدّم الملف عبر الإنترنت قبل الأجل.",
      "الانتقاء الأولي يُنشر باللوائح: راقب التاريخ المعلن.",
      "احضر المباراة الكتابية مع الاستدعاء مطبوعاً.",
      "النتائج النهائية تفتح التسجيل النهائي بأجل صارم.",
    ],
  },
];

const GLOSSARY: { term_fr: string; term_ar: string; def_fr: string; def_ar: string }[] = [
  { term_fr: "Seuil de présélection", term_ar: "عتبة الانتقاء الأولي", def_fr: "Note minimale qui permet d'être convoqué au concours. Ce n'est pas la note d'admission finale.", def_ar: "أدنى نقطة للتوصل باستدعاء المباراة. ليست نقطة القبول النهائي." },
  { term_fr: "Dernier admis", term_ar: "آخر مقبول", def_fr: "Note du dernier candidat admis l'année passée. Indique le niveau réel, pas une règle.", def_ar: "نقطة آخر مترشح مقبول العام الماضي. مؤشر للمستوى، ليست قاعدة." },
  { term_fr: "Examen national", term_ar: "الامتحان الوطني", def_fr: "Partie unifiée du bac (juin), coefficient fort dans beaucoup de formules.", def_ar: "الجزء الموحد من البكالوريا (يونيو)، معامل مهم بكثير من الصيغ." },
  { term_fr: "Examen régional", term_ar: "الامتحان الجهوي", def_fr: "Partie régionale du bac (1re année), pondérée dans certaines formules.", def_ar: "الجزء الجهوي (السنة الأولى)، يدخل ببعض الصيغ." },
  { term_fr: "Contrôle continu", term_ar: "المراقبة المستمرة", def_fr: "Notes de l'année scolaire intégrées à la moyenne du bac.", def_ar: "نقط السنة الدراسية المندمجة في معدل البكالوريا." },
  { term_fr: "Concours", term_ar: "مباراة", def_fr: "Épreuve écrite/orale d'accès à une école sélective.", def_ar: "اختبار كتابي/شفوي للولوج لمدرسة سيليكتيف." },
  { term_fr: "TAFEM", term_ar: "تافيم", def_fr: "Test d'aptitude des ENCG : culture, logique, langues.", def_ar: "اختبار قدرات مدارس إنسج: ثقافة ومنطق ولغات." },
  { term_fr: "Accès ouvert", term_ar: "ولوج مفتوح", def_fr: "Inscription possible avec le simple baccalauréat, sans concours.", def_ar: "تسجيل ممكن بالبكالوريا فقط، دون مباراة." },
  { term_fr: "DUT", term_ar: "دبلوم جامعي في التكنولوجيا", def_fr: "Diplôme universitaire de technologie, 2 ans en EST.", def_ar: "دبلوم تقني جامعي، سنتان بالمدارس العليا للتكنولوجيا." },
  { term_fr: "Reconnaissance d'État", term_ar: "اعتراف الدولة", def_fr: "Une école privée reconnue délivre des diplômes à valeur officielle. À vérifier toujours.", def_ar: "المدرسة الخاصة المعترف بها تمنح دبلومات بقيمة رسمية. تحقق دائماً." },
  { term_fr: "RSU", term_ar: "السجل الاجتماعي الموحد", def_fr: "Registre social unifié : la base des aides sociales, requis pour Minhaty.", def_ar: "قاعدة المساعدات الاجتماعية المطلوبة لمنحتي." },
  { term_fr: "CPGE", term_ar: "الأقسام التحضيرية", def_fr: "Deux années intensives préparant aux concours des grandes écoles.", def_ar: "سنتان مكثفتان تحضران لمباريات المدارس العليا." },
];

const FAQ: { q_fr: string; q_ar: string; a_fr: string; a_ar: string }[] = [
  {
    q_fr: "Le seuil affiché garantit-il mon admission ?",
    q_ar: "هل العتبة المعروضة تضمن قبولي؟",
    a_fr: "Non. C'est le seuil de l'année passée : la demande change chaque année. L'écart affiché (+0,8 etc.) mesure votre marge. L'établissement décide toujours.",
    a_ar: "لا. هذه عتبة العام الماضي: الطلب يتغير كل سنة. الفرق المعروض يقيس هامشك. المؤسسة هي من تقرر دائماً.",
  },
  {
    q_fr: "Pourquoi certains seuils disent « Non publié » ?",
    q_ar: "لماذا بعض العتبات مكتوب «غير منشور»؟",
    a_fr: "Parce que l'école ne les rend pas publics. Nous ne les estimons jamais : chiffrer pour chiffrer tromperait les familles.",
    a_ar: "لأن المدرسة لا تنشرها. لا نقدرها أبداً: التخمين يضلل الأسر.",
  },
  {
    q_fr: "Comment sont calculées les notes pondérées ?",
    q_ar: "كيف تُحسب النقط الموزونة؟",
    a_fr: "Chaque école publie sa formule (par ex. 75% national + 25% régional). Le calculateur applique exactement ces poids, rien d'autre.",
    a_ar: "كل مدرسة تنشر صيغتها (مثلاً 75٪ وطني + 25٪ جهوي). الحاسبة تطبق هذه الأوزان فقط.",
  },
  {
    q_fr: "Mes données sont-elles envoyées quelque part ?",
    q_ar: "هل تُرسل معطياتي لمكان ما؟",
    a_fr: "Non. Vos notes et réponses restent dans ce navigateur. Pas de compte, pas de suivi. Conformité loi 09-08.",
    a_ar: "لا. نقطك وأجوبتك تبقى في هذا المتصفح. بلا حساب ولا تتبع. وفق القانون 09-08.",
  },
  {
    q_fr: "Je suis parent : comment lire les résultats avec mon enfant ?",
    q_ar: "أنا ولي أمر: كيف نقرأ النتائج مع ابني؟",
    a_fr: "Regardez la marge (+0,8), pas la note brute. Diversifiez : une « forte chance », une « possible » et une option ouverte ou privée dans le budget.",
    a_ar: "انظر الهامش (+0,8) لا النقطة الخام. نوّع: «حظ قوي» و«ممكن» وخيار مفتوح أو خاص ضمن الميزانية.",
  },
  {
    q_fr: "Le site est-il officiel ?",
    q_ar: "هل الموقع رسمي؟",
    a_fr: "Non — Masar est indépendant. Les décisions appartiennent aux établissements ; chaque fiche pointe vers leur site officiel.",
    a_ar: "لا — مسار مستقل. القرار للمؤسسات؛ كل ملف يحيل لموقعها الرسمي.",
  },
];

function Section({ icon: Icon, title, children, defaultOpen = false }: { icon: typeof BookOpen; title: string; children: React.ReactNode; defaultOpen?: boolean }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <section className="card overflow-hidden">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-expanded={open}
        className="flex w-full items-center justify-between gap-3 p-5 text-start"
      >
        <span className="flex items-center gap-3">
          <span className="grid h-10 w-10 place-items-center rounded-xl bg-[var(--c-accent-soft)] text-[var(--c-accent)]">
            <Icon className="h-5 w-5" />
          </span>
          <span className="text-[1.02rem] font-extrabold">{title}</span>
        </span>
        <ChevronDown className={cn("h-5 w-5 shrink-0 text-[var(--c-faint)] transition-transform", open && "rotate-180")} />
      </button>
      <div className={cn("grid transition-[grid-template-rows] duration-300", open ? "[grid-template-rows:1fr]" : "[grid-template-rows:0fr]")}>
        <div className="overflow-hidden">
          <div className="border-t border-[var(--c-line)] p-5 sm:p-6">{children}</div>
        </div>
      </div>
    </section>
  );
}

export default function Guides() {
  const { t, lang } = useI18n();
  return (
    <>
      <PageTitle eyebrow="Masar · Reference" title={t("guides.title")} intro={t("legal.disclaimer")} />
      <div className="mx-auto mt-8 max-w-4xl space-y-4 px-4 pb-16 sm:px-6">
        <Section icon={MapIcon} title={t("guides.streams")} defaultOpen>
          <ul className="space-y-3">
            {STREAMS.map((s) => (
              <li key={s.key} className="flex flex-col gap-1 rounded-xl bg-[var(--c-raised)] p-4 sm:flex-row sm:items-start sm:gap-4">
                <span className="w-44 shrink-0 font-bold">{s[lang]}</span>
                <span className="text-[0.88rem] leading-relaxed text-[var(--c-sub)]">{STREAM_MAP[s.key][lang]}</span>
              </li>
            ))}
          </ul>
        </Section>

        <Section icon={Globe} title={t("guides.platforms")}>
          <div className="space-y-6">
            {PLATFORMS.map((p) => (
              <div key={p.name}>
                <h3 className="font-extrabold">{p.name}</h3>
                <ol className="mt-2 space-y-2">
                  {p[lang].map((step, i) => (
                    <li key={i} className="flex items-start gap-3 text-[0.9rem] leading-relaxed text-[var(--c-sub)]">
                      <span className="num grid h-6 w-6 shrink-0 place-items-center rounded-full bg-[var(--c-accent-soft)] text-[0.72rem] font-extrabold text-[var(--c-accent)]">
                        {i + 1}
                      </span>
                      {step}
                    </li>
                  ))}
                </ol>
              </div>
            ))}
          </div>
        </Section>

        <Section icon={BookOpen} title={t("guides.glossary")}>
          <div className="overflow-x-auto">
            <table className="table-clean min-w-[480px]">
              <thead>
                <tr>
                  <th>Français</th>
                  <th>العربية</th>
                  <th>{lang === "ar" ? "التعريف" : "Définition"}</th>
                </tr>
              </thead>
              <tbody>
                {GLOSSARY.map((g) => (
                  <tr key={g.term_fr}>
                    <td className="font-bold">{g.term_fr}</td>
                    <td className="font-bold" dir="rtl" lang="ar">{g.term_ar}</td>
                    <td className="text-[0.85rem] text-[var(--c-sub)]">{lang === "ar" ? g.def_ar : g.def_fr}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Section>

        <Section icon={HelpCircle} title={t("guides.faq")}>
          <div className="space-y-2.5">
            {FAQ.map((f) => (
              <details key={f.q_fr} className="group rounded-xl border border-[var(--c-line)] bg-[var(--c-raised)] p-4 open:bg-[var(--c-surface)]">
                <summary className="cursor-pointer list-none font-bold leading-snug [&::-webkit-details-marker]:hidden">
                  {lang === "ar" ? f.q_ar : f.q_fr}
                </summary>
                <p className="mt-2.5 text-[0.88rem] leading-relaxed text-[var(--c-sub)]">
                  {lang === "ar" ? f.a_ar : f.a_fr}
                </p>
              </details>
            ))}
          </div>
        </Section>
      </div>
    </>
  );
}
