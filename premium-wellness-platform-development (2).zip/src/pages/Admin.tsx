import { ChangeEvent, useRef, useState } from "react";
import { CheckCircle2, ClipboardList, Flag, History, ShieldCheck, Upload, XCircle } from "lucide-react";
import { useI18n } from "@/i18n";
import { PageTitle } from "@/components";
import { INSTITUTIONS, RULES, THRESHOLDS } from "@/data/records";
import { STREAMS, type ThresholdStage } from "@/data/types";
import { cn } from "@/utils/cn";

interface CsvRow { raw: string; ruleId: string; stream: string; year: number; stage: string; value: number | null }
interface CheckResult { row: CsvRow; ok: boolean; reasons: string[] }

const STAGES: ThresholdStage[] = ["preselection", "final"];
const STREAM_KEYS = new Set<string>(STREAMS.map((s) => s.key));

function parseCsv(text: string): CsvRow[] {
  return text
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter((l) => l && !l.startsWith("#"))
    .map((line) => {
      const [ruleId = "", stream = "", year = "", stage = "", value = ""] = line.split(",").map((c) => c.trim());
      const v = value.toLowerCase();
      return {
        raw: line,
        ruleId,
        stream,
        year: Number(year),
        stage,
        value: v === "" || v === "null" || v === "np" ? null : Number(v.replace(",", ".")),
      };
    });
}

function validate(row: CsvRow, existing: Set<string>, seenInFile: Set<string>): CheckResult {
  const reasons: string[] = [];
  if (!RULES.some((r) => r.id === row.ruleId)) reasons.push("ruleId inconnu");
  if (!STREAM_KEYS.has(row.stream)) reasons.push("filière hors liste officielle");
  if (!Number.isInteger(row.year) || row.year < 2020 || row.year > 2027) reasons.push("année invalide");
  if (!STAGES.includes(row.stage as ThresholdStage)) reasons.push("stage ≠ preselection/final");
  if (row.value !== null && (Number.isNaN(row.value) || row.value < 0 || row.value > 20)) reasons.push("hors échelle /20");
  const key = `${row.ruleId}|${row.stream}|${row.year}|${row.stage}`;
  if (existing.has(key)) reasons.push("doublon avec la base");
  if (seenInFile.has(key)) reasons.push("doublon dans le fichier");
  seenInFile.add(key);
  return { row, ok: reasons.length === 0, reasons };
}

export default function Admin() {
  const { t, fmtNum } = useI18n();
  const fileRef = useRef<HTMLInputElement>(null);
  const [csvText, setCsvText] = useState("");
  const [results, setResults] = useState<CheckResult[] | null>(null);
  const [audit, setAudit] = useState<string[]>(() => {
    try { return JSON.parse(localStorage.getItem("masar:audit") ?? "[]"); } catch { return []; }
  });
  const [reports] = useState<{ at: string; context: string; message: string }[]>(() => {
    try { return JSON.parse(localStorage.getItem("masar:reports") ?? "[]"); } catch { return []; }
  });

  const existing = new Set(THRESHOLDS.map((th) => `${th.ruleId}|${th.stream}|${th.year}|${th.stage}`));

  function runValidation() {
    const seen = new Set<string>();
    const parsed = parseCsv(csvText);
    setResults(parsed.map((r) => validate(r, existing, seen)));
  }

  function onFile(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    file.text().then(setCsvText);
  }

  function publish() {
    if (!results) return;
    const okCount = results.filter((r) => r.ok).length;
    const entry = `${new Date().toLocaleString()} — import CSV : ${fmtNum(okCount)} ${t("adm.valid").toString()}, ${fmtNum(results.length - okCount)} ${t("adm.invalid")} (local only)`;
    const next = [entry, ...audit].slice(0, 30);
    setAudit(next);
    try { localStorage.setItem("masar:audit", JSON.stringify(next)); } catch { /* ignore */ }
  }

  const validCount = results?.filter((r) => r.ok).length ?? 0;

  return (
    <>
      <PageTitle eyebrow="Masar · Admin" title={t("adm.title")} intro={t("adm.note")} />
      <div className="mx-auto mt-8 max-w-5xl space-y-8 px-4 pb-16 sm:px-6">
        {/* stats + table */}
        <section className="grid gap-3 sm:grid-cols-3">
          <div className="card p-5">
            <p className="num text-3xl font-extrabold text-[var(--c-accent)]">{fmtNum(INSTITUTIONS.length)}</p>
            <p className="mt-1 text-[0.8rem] font-semibold text-[var(--c-sub)]">{t("nav.schools")}</p>
          </div>
          <div className="card p-5">
            <p className="num text-3xl font-extrabold text-[var(--c-accent)]">{fmtNum(RULES.length)}</p>
            <p className="mt-1 text-[0.8rem] font-semibold text-[var(--c-sub)]">Admission rules · 2026</p>
          </div>
          <div className="card p-5">
            <p className="num text-3xl font-extrabold text-[var(--c-accent)]">{fmtNum(THRESHOLDS.length)}</p>
            <p className="mt-1 text-[0.8rem] font-semibold text-[var(--c-sub)]">Thresholds · every row sourced & dated</p>
          </div>
        </section>

        <section aria-labelledby="inst-h">
          <h2 id="inst-h" className="flex items-center gap-2 text-lg font-extrabold">
            <ClipboardList className="h-5 w-5 text-[var(--c-accent)]" />
            Fiches institution
          </h2>
          <div className="card mt-3 max-h-96 overflow-auto">
            <table className="table-clean min-w-[600px]">
              <thead className="sticky top-0 bg-[var(--c-surface)]">
                <tr>
                  <th>Établissement</th>
                  <th>Secteur</th>
                  <th>Ville</th>
                  <th>Dernière vérif.</th>
                  <th>Source</th>
                </tr>
              </thead>
              <tbody>
                {INSTITUTIONS.map((i) => (
                  <tr key={i.id}>
                    <td className="font-semibold">{i.short_fr}</td>
                    <td>{t(i.sector)}</td>
                    <td>{i.city_fr}</td>
                    <td className="num">{i.lastVerified}</td>
                    <td className="num text-[0.78rem] text-[var(--c-faint)]">{i.sourceId}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        {/* CSV import */}
        <section aria-labelledby="import-h">
          <h2 id="import-h" className="flex items-center gap-2 text-lg font-extrabold">
            <Upload className="h-5 w-5 text-[var(--c-accent)]" />
            {t("adm.import")}
          </h2>
          <p className="mt-1 text-[0.8rem] text-[var(--c-sub)]">{t("adm.importHelp")}</p>
          <div className="card mt-3 p-5">
            <div className="flex flex-wrap gap-2.5">
              <button type="button" onClick={() => fileRef.current?.click()} className="btn btn-outline text-sm">
                <Upload className="h-4 w-4" /> CSV
              </button>
              <input ref={fileRef} type="file" accept=".csv,text/csv,text/plain" onChange={onFile} className="hidden" />
              <button type="button" onClick={runValidation} disabled={!csvText.trim()} className="btn btn-primary text-sm disabled:opacity-40">
                Valider
              </button>
              {results && (
                <button type="button" onClick={publish} disabled={validCount === 0} className="btn btn-soft text-sm disabled:opacity-40">
                  <ShieldCheck className="h-4 w-4" /> Publier (local)
                </button>
              )}
            </div>
            <label htmlFor="csv-in" className="label mt-4">CSV</label>
            <textarea
              id="csv-in"
              rows={6}
              value={csvText}
              onChange={(e) => setCsvText(e.target.value)}
              className="field font-mono text-[0.8rem]"
              placeholder={"ar-encg-2026,SECO,2025,preselection,15.4\nar-ensama-2026,SMA,2026,preselection,np"}
              spellCheck={false}
            />
            {results && (
              <div className="fade-up mt-4" aria-live="polite">
                <p className="text-sm font-bold">
                  <span className="text-[var(--c-good)]">{fmtNum(validCount)} {t("adm.valid")}</span>
                  {" · "}
                  <span className="text-[var(--c-bad)]">{fmtNum(results.length - validCount)} {t("adm.invalid")}</span>
                </p>
                <ul className="mt-2.5 max-h-56 space-y-1.5 overflow-auto font-mono text-[0.74rem]">
                  {results.map((r, i) => (
                    <li key={i} className={cn("flex items-start gap-2 rounded-lg px-3 py-1.5", r.ok ? "bg-[var(--c-good-soft)] text-[var(--c-good)]" : "bg-[var(--c-bad-soft)] text-[var(--c-bad)]")}>
                      {r.ok ? <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0" /> : <XCircle className="mt-0.5 h-3.5 w-3.5 shrink-0" />}
                      <span>
                        {r.row.raw}
                        {!r.ok && <em className="ms-2 font-sans not-italic opacity-80">({r.reasons.join(" · ")})</em>}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </section>

        {/* audit + reports */}
        <section className="grid gap-4 md:grid-cols-2">
          <div className="card p-5">
            <h2 className="flex items-center gap-2 text-base font-extrabold">
              <History className="h-4.5 w-4.5 text-[var(--c-accent)]" />
              {t("adm.audit")}
            </h2>
            <ul className="mt-3 space-y-2 text-[0.8rem]">
              {audit.length === 0 && <li className="text-[var(--c-faint)]">—</li>}
              {audit.map((a, i) => (
                <li key={i} className="rounded-lg bg-[var(--c-raised)] px-3 py-2 text-[var(--c-sub)]">{a}</li>
              ))}
            </ul>
          </div>
          <div className="card p-5">
            <h2 className="flex items-center gap-2 text-base font-extrabold">
              <Flag className="h-4.5 w-4.5 text-[var(--c-warn)]" />
              {t("adm.queue")}
            </h2>
            <ul className="mt-3 space-y-2 text-[0.8rem]">
              {reports.length === 0 && <li className="text-[var(--c-faint)]">—</li>}
              {reports.map((r, i) => (
                <li key={i} className="rounded-lg bg-[var(--c-raised)] px-3 py-2">
                  <p className="font-semibold text-[var(--c-ink)]">{r.context}</p>
                  <p className="text-[var(--c-sub)]">{r.message}</p>
                  <p className="num mt-0.5 text-[0.68rem] text-[var(--c-faint)]">{r.at.slice(0, 16).replace("T", " ")}</p>
                </li>
              ))}
            </ul>
          </div>
        </section>
      </div>
    </>
  );
}
