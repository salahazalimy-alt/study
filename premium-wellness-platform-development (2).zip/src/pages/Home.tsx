import { FormEvent, useMemo, useRef, useState } from "react";
import { Link } from "react-router-dom";
import {
  ArrowRight, BookMarked, BookOpen, CalendarDays, CheckCircle2, GitCompareArrows,
  GraduationCap, LineChart, MapPin, MinusCircle, PlusCircle, Sparkles, TrendingDown,
  TrendingUp, Wallet,
} from "lucide-react";
import { useI18n, pick } from "@/i18n";
import { EmptyState, SourceNote } from "@/components";
import { FORMULAS, RULES, THRESHOLDS, institutionById, programmeById, sourceById } from "@/data/records";
import { classify, computeScore, fmtGap, fmtScore, stageForRoute, type ScoreInputs, type Verdict, type VerdictResult } from "@/data/scoring";
import { STREAMS, type AdmissionRule, type BacStream, type Institution, type Programme } from "@/data/types";
import { useCompare, useShortlist } from "@/store";
import { cn } from "@/utils/cn";

interface ResultItem {
  institution: Institution;
  programme: Programme;
  rule: AdmissionRule;
  verdict: VerdictResult | null; // null → open / file-based
  kind: "strong" | "possible" | "outOfReach" | "notPublished" | "open" | "file";
}

const VERDICT_STYLE: Record<string, { chip: string; icon: typeof TrendingUp }> = {
  strong: { chip: "tag-good", icon: TrendingUp },
  possible: { chip: "tag-warn", icon: TrendingUp },
  outOfReach: { chip: "tag-bad", icon: TrendingDown },
  notPublished: { chip: "tag-line", icon: MinusCircle },
  open: { chip: "tag-info", icon: CheckCircle2 },
  file: { chip: "tag-info", icon: BookOpen },
};

function ResultCard({ item }: { item: ResultItem }) {
  const { t, lang, fmtDate, fmtNum } = useI18n();
  const shortlist = useShortlist();
  const compare = useCompare();
  const [compareMsg, setCompareMsg] = useState(false);

  const saved = shortlist.has(item.institution.id);
  const inCompare = compare.has(item.institution.id);
  const style = VERDICT_STYLE[item.kind];
  const Icon = style.icon;
  const v = item.verdict;
  const latestTh = v?.threshold;
  const loc = lang === "ar" ? "ar-MA-u-nu-latn" : "fr-MA";

  return (
    <article className="card card-hover fade-up p-5">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="flex flex-wrap items-center gap-2">
            <span className={cn("tag", style.chip)}>
              <Icon className="h-3 w-3" />
              {item.kind === "open"
                ? t("route.open")
                : item.kind === "file"
                  ? t("checker.noFormula")
                  : t(`verdict.${item.kind}`)}
            </span>
          </p>
          <h3 className="mt-2.5 text-[1.02rem] font-bold leading-snug text-[var(--c-ink)]">
            <Link to={`/school/${item.institution.id}`} className="hover:text-[var(--c-accent)] hover:underline underline-offset-4">
              {pick(item.institution, "name", lang)}
            </Link>
          </h3>
          <p className="mt-0.5 text-[0.85rem] font-medium text-[var(--c-sub)]">
            {pick(item.programme, "name", lang)}
          </p>
        </div>
        <span className={cn("tag shrink-0", item.institution.sector === "public" ? "tag-good" : "tag-info")}>
          {t(item.institution.sector)}
        </span>
      </div>

      {/* threshold + gap */}
      <div className="mt-4 rounded-xl bg-[var(--c-raised)] p-3.5">
        {latestTh && v?.computed !== null && v?.computed !== undefined ? (
          <div className="flex flex-wrap items-end justify-between gap-3">
            <div>
              <p className="text-[0.68rem] font-bold uppercase tracking-wide text-[var(--c-faint)]">
                {t(latestTh.stage === "preselection" ? "card.thresholdPre" : "card.thresholdFinal")} · {latestTh.year}
              </p>
              <p className="num mt-0.5 text-xl font-extrabold text-[var(--c-ink)]">
                {fmtScore(latestTh.value, loc)}<span className="text-[0.7rem] font-medium text-[var(--c-faint)]">/20</span>
              </p>
            </div>
            {v.gap !== null && (
              <div className="text-end">
                <p className="text-[0.68rem] font-bold uppercase tracking-wide text-[var(--c-faint)]">{t("card.yourScore")}</p>
                <p className="num mt-0.5 text-xl font-extrabold text-[var(--c-ink)]">{fmtScore(v.computed, loc)}</p>
                <p className={cn("num mt-0.5 text-[0.8rem] font-bold", v.gap >= 0 ? "text-[var(--c-good)]" : "text-[var(--c-bad)]")}>
                  {fmtGap(v.gap, loc)}{" "}
                  {t(v.gap >= 0 ? "verdict.above" : "verdict.below")} {latestTh.year}*
                </p>
              </div>
            )}
          </div>
        ) : (
          <p className="text-[0.85rem] font-medium text-[var(--c-sub)]">
            {item.kind === "open" ? t("checker.openAccess") : item.kind === "file" ? t("checker.noFormula") : t("verdict.notPublished")}
          </p>
        )}
        {latestTh && <SourceNote sourceId={latestTh.sourceId} verifiedAt={latestTh.verifiedAt} />}
      </div>

      <div className="mt-3.5 flex flex-wrap items-center gap-x-4 gap-y-1.5 text-[0.8rem] text-[var(--c-sub)]">
        <span className="inline-flex items-center gap-1">
          <MapPin className="h-3.5 w-3.5 text-[var(--c-faint)]" />
          {pick(item.institution, "city", lang)}
        </span>
        <span className={cn("tag tag-line !py-0.5")}>{t(`route.${item.rule.route}`)}</span>
        <span className="inline-flex items-center gap-1">
          <CalendarDays className="h-3.5 w-3.5 text-[var(--c-faint)]" />
          {t("deadline.label")} {fmtDate(item.rule.registrationDeadline)}
        </span>
        {item.programme.tuitionMAD !== null && (
          <span className="inline-flex items-center gap-1">
            <Wallet className="h-3.5 w-3.5 text-[var(--c-faint)]" />
            {fmtNum(item.programme.tuitionMAD)} {t("madYear")}
          </span>
        )}
        {item.programme.seats !== null && (
          <span className="inline-flex items-center gap-1">
            <GraduationCap className="h-3.5 w-3.5 text-[var(--c-faint)]" />
            {fmtNum(item.programme.seats)} {t("seats")}
          </span>
        )}
      </div>

      <div className="mt-4 flex flex-wrap items-center gap-2 border-t border-[var(--c-line)] pt-3.5">
        <Link to={`/school/${item.institution.id}`} className="btn btn-soft !min-h-[40px] px-3.5 py-1.5 text-[0.82rem]">
          {t("detail.howToApply")}
          <ArrowRight className="mirror-icon h-3.5 w-3.5" />
        </Link>
        <button
          type="button"
          onClick={() => shortlist.toggle(item.institution.id)}
          aria-pressed={saved}
          className={cn("btn btn-outline !min-h-[40px] px-3.5 py-1.5 text-[0.82rem]", saved && "border-[var(--c-accent)] text-[var(--c-accent)]")}
        >
          {saved ? <CheckCircle2 className="h-3.5 w-3.5" /> : <PlusCircle className="h-3.5 w-3.5" />}
          {saved ? t("saved.in") : t("saved.add")}
        </button>
        <button
          type="button"
          onClick={() => {
            const r = compare.toggle(item.institution.id, 4);
            if (!r.ok) { setCompareMsg(true); window.setTimeout(() => setCompareMsg(false), 2200); }
          }}
          aria-pressed={inCompare}
          className={cn("btn btn-outline !min-h-[40px] px-3.5 py-1.5 text-[0.82rem]", inCompare && "border-[var(--c-accent)] text-[var(--c-accent)]")}
        >
          <GitCompareArrows className="h-3.5 w-3.5" />
          {inCompare ? t("compare.in") : t("compare.add")}
        </button>
      </div>
      {compareMsg && (
        <p role="alert" className="mt-2 text-[0.78rem] font-semibold text-[var(--c-warn)]">{t("compare.limit")}</p>
      )}
    </article>
  );
}

export default function Home() {
  const { t, lang, fmtNum } = useI18n();
  const [stream, setStream] = useState<BacStream | null>(null);
  const [overall, setOverall] = useState("");
  const [national, setNational] = useState("");
  const [regional, setRegional] = useState("");
  const [results, setResults] = useState<ResultItem[] | null>(null);
  const [formError, setFormError] = useState<string | null>(null);
  const resultsRef = useRef<HTMLDivElement>(null);

  const parse = (s: string): number | null => {
    if (!s.trim()) return null;
    const n = Number(s.replace(",", "."));
    return Number.isFinite(n) ? n : NaN;
  };

  function computeResults(e?: FormEvent) {
    e?.preventDefault();
    setFormError(null);
    if (!stream) {
      setFormError(lang === "ar" ? "اختار شعبة البكالوريا أولاً." : "Choisissez d'abord votre filière de bac.");
      return;
    }
    const nums = [overall, national, regional].map(parse);
    if (nums.some((n) => n !== null && (Number.isNaN(n) || n < 0 || n > 20))) {
      setFormError(lang === "ar" ? "النقط كتكون دائماً بين 0 و 20." : "Les notes sont toujours entre 0 et 20.");
      return;
    }
    const inputs: ScoreInputs = {
      overall: nums[0] === null ? null : nums[0],
      national: nums[1] === null ? null : nums[1],
      regional: nums[2] === null ? null : nums[2],
    };

    const items: ResultItem[] = [];
    for (const rule of RULES) {
      if (!rule.streams.includes(stream)) continue;
      const programme = programmeById(rule.programmeId);
      if (!programme) continue;
      const institution = institutionById(programme.institutionId);
      if (!institution) continue;

      if (rule.route === "open" || !rule.formulaId) {
        items.push({ institution, programme, rule, verdict: null, kind: rule.route === "open" ? "open" : "file" });
        continue;
      }
      const formula = FORMULAS.find((f) => f.id === rule.formulaId);
      if (!formula) continue;
      const computed = computeScore(formula, inputs);
      const verdict = classify(computed, THRESHOLDS.filter((th) => th.ruleId === rule.id), stream, stageForRoute(rule.route));
      if (verdict.verdict === "notPublished" && computed === null) continue; // missing inputs → skip rather than guess
      items.push({
        institution, programme, rule, verdict,
        kind: verdict.verdict,
      });
    }
    const order: Verdict[] = ["strong", "possible", "outOfReach", "notPublished"];
    items.sort((a, b) => {
      const rank = (k: ResultItem["kind"]) => k === "open" ? 99 : k === "file" ? 98 : order.indexOf(k as Verdict);
      return rank(a.kind) - rank(b.kind);
    });
    setResults(items);
    window.setTimeout(() => resultsRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 60);
  }

  const groups = useMemo(() => {
    if (!results) return null;
    return {
      strong: results.filter((r) => r.kind === "strong"),
      possible: results.filter((r) => r.kind === "possible"),
      outOfReach: results.filter((r) => r.kind === "outOfReach"),
      other: results.filter((r) => r.kind === "notPublished" || r.kind === "file"),
      open: results.filter((r) => r.kind === "open"),
    };
  }, [results]);

  return (
    <>
      {/* ------------------------------- hero ------------------------------- */}
      <section className="relative overflow-hidden px-4 pb-10 pt-12 sm:px-6 sm:pt-20">
        <div
          aria-hidden
          className="pointer-events-none absolute inset-x-0 top-[-30%] h-[120%] opacity-70"
          style={{
            background:
              "radial-gradient(60% 50% at 50% 20%, color-mix(in srgb, var(--c-accent) 14%, transparent), transparent 70%)",
          }}
        />
        <div className="relative mx-auto max-w-3xl text-center">
          <p className="eyebrow fade-up">{t("home.eyebrow")}</p>
          <h1 className="fade-up mt-4 text-[clamp(1.9rem,7vw,3.6rem)] font-extrabold leading-[1.12] tracking-tight [animation-delay:80ms]">
            {t("home.title")}
          </h1>
          <p className="fade-up mx-auto mt-5 max-w-xl leading-relaxed text-[var(--c-sub)] [animation-delay:160ms]">
            {t("home.sub")}
          </p>
        </div>

        {/* -------------------------- score checker -------------------------- */}
        <form
          onSubmit={computeResults}
          className="fade-up card relative mx-auto mt-10 max-w-3xl p-5 shadow-[0_24px_60px_-24px_rgb(14_122_95/0.25)] sm:p-7 [animation-delay:240ms]"
          aria-label={t("checker.title")}
        >
          <h2 className="flex items-center gap-2 text-lg font-extrabold">
            <Sparkles className="h-5 w-5 text-[var(--c-accent)]" />
            {t("checker.title")}
          </h2>
          <p className="mt-1 text-[0.8rem] text-[var(--c-faint)]">{t("checker.onlyAsked")}</p>

          <fieldset className="mt-5">
            <legend className="label">{t("checker.stream")} *</legend>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
              {STREAMS.map((s) => (
                <button
                  key={s.key}
                  type="button"
                  aria-pressed={stream === s.key}
                  onClick={() => setStream(s.key)}
                  className="chip w-full justify-center !text-[0.8rem]"
                >
                  {s[lang]}
                </button>
              ))}
            </div>
          </fieldset>

          <div className="mt-5 grid gap-3 sm:grid-cols-3">
            <div>
              <label htmlFor="in-overall" className="label">{t("checker.overall")}</label>
              <input
                id="in-overall" inputMode="decimal" className="field num" placeholder="14,50"
                value={overall} onChange={(e) => setOverall(e.target.value)}
              />
            </div>
            <div>
              <label htmlFor="in-national" className="label">{t("checker.national")}</label>
              <input
                id="in-national" inputMode="decimal" className="field num" placeholder="15,75"
                value={national} onChange={(e) => setNational(e.target.value)}
              />
              <p className="mt-1.5 text-[0.68rem] leading-snug text-[var(--c-faint)]">{t("checker.nationalHint")}</p>
            </div>
            <div>
              <label htmlFor="in-regional" className="label">{t("checker.regional")}</label>
              <input
                id="in-regional" inputMode="decimal" className="field num" placeholder="14,00"
                value={regional} onChange={(e) => setRegional(e.target.value)}
              />
              <p className="mt-1.5 text-[0.68rem] leading-snug text-[var(--c-faint)]">{t("checker.regionalHint")}</p>
            </div>
          </div>

          {formError && (
            <p role="alert" className="mt-4 rounded-lg bg-[var(--c-bad-soft)] px-4 py-2.5 text-[0.85rem] font-medium text-[var(--c-bad)]">
              {formError}
            </p>
          )}

          <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:items-center">
            <button type="submit" className="btn btn-primary flex-1 text-base sm:flex-none sm:px-10">
              {t("checker.cta")}
              <ArrowRight className="mirror-icon h-4.5 w-4.5" />
            </button>
            {results && (
              <button type="button" className="btn btn-outline sm:flex-none" onClick={computeResults}>
                {t("checker.recalc")}
              </button>
            )}
            <p className="text-center text-[0.72rem] text-[var(--c-faint)] sm:text-start">{t("checker.guide")}</p>
          </div>
        </form>
      </section>

      {/* ------------------------------ results ------------------------------ */}
      {results && groups && (
        <section ref={resultsRef} className="scroll-mt-24 px-4 sm:px-6" aria-live="polite">
          <div className="mx-auto max-w-4xl">
            <h2 className="text-xl font-extrabold tracking-tight sm:text-2xl">
              {t("results.title")}{" "}
              <span className="ms-2 text-[0.85rem] font-semibold text-[var(--c-faint)]">
                {fmtNum(results.length)} {t("results.count")} · {stream ? STREAMS.find((s) => s.key === stream)?.[lang] : ""}
              </span>
            </h2>

            {([
              ["strong", groups.strong],
              ["possible", groups.possible],
              ["outOfReach", groups.outOfReach],
              ["notPublished", groups.other],
              ["open", groups.open],
            ] as const).map(([key, list]) =>
              list.length === 0 ? null : (
                <div key={key} className="mt-7">
                  <h3 className="mb-3 flex items-center gap-2 text-[0.9rem] font-extrabold uppercase tracking-wide">
                    <span
                      className={cn(
                        "tag",
                        key === "strong" ? "tag-good" : key === "possible" ? "tag-warn" : key === "outOfReach" ? "tag-bad" : "tag-info"
                      )}
                    >
                      {key === "notPublished" ? t("verdict.notPublished") : key === "open" ? t("route.open") : t(`verdict.${key}`)}
                    </span>
                    <span className="text-[var(--c-faint)]">· {list.length}</span>
                    {key !== "open" && key !== "notPublished" && (
                      <span className="hidden text-[0.72rem] font-medium normal-case tracking-normal text-[var(--c-faint)] sm:inline">
                        — {t(`verdict.${key}Why`)}
                      </span>
                    )}
                  </h3>
                  <div className="grid gap-3.5">
                    {list.map((item) => (
                      <ResultCard key={item.rule.id} item={item} />
                    ))}
                  </div>
                </div>
              )
            )}
            {results.length === 0 && <EmptyState />}

            <p className="mt-8 rounded-xl border border-dashed border-[var(--c-line-strong)] p-4 text-[0.78rem] leading-relaxed text-[var(--c-sub)]">
              * {t("verdict.lastYear")} — {t("legal.disclaimer")}{" "}
              <span className="tag tag-demo ms-1">{t("example.badge")}</span>
            </p>
          </div>
        </section>
      )}

      {/* ---------------------------- quick actions ---------------------------- */}
      <section className="mx-auto mt-16 max-w-6xl px-4 sm:px-6">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { to: "/schools", icon: LineChart, title: t("reverse.title"), body: t("detail.trend") },
            { to: "/scholarships", icon: BookMarked, title: t("sch.title"), body: t("sch.matcher.title") },
            { to: "/calendar", icon: CalendarDays, title: t("cal.title"), body: t("cal.ics") },
            { to: "/guides", icon: BookOpen, title: t("guides.title"), body: t("guides.streams") },
          ].map((c) => (
            <Link key={c.to} to={c.to} className="card card-hover group p-5">
              <c.icon className="h-5 w-5 text-[var(--c-accent)]" />
              <h3 className="mt-3 font-bold leading-snug">{c.title}</h3>
              <p className="mt-1 text-[0.8rem] text-[var(--c-sub)]">{c.body}</p>
              <span className="mt-3 inline-flex items-center gap-1 text-[0.8rem] font-bold text-[var(--c-accent)]">
                <ArrowRight className="mirror-icon h-4 w-4 transition-transform group-hover:translate-x-1 rtl:group-hover:-translate-x-1" />
              </span>
            </Link>
          ))}
        </div>

        <p className="mt-8 text-center text-[0.72rem] text-[var(--c-faint)]">
          {t("legal.independence")}
        </p>
        <div className="sr-only">
          {sourceById("src-cursussup")?.url}
        </div>
      </section>
    </>
  );
}
