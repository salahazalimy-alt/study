import { Cookie, Gavel, Scale, ShieldCheck } from "lucide-react";
import { useI18n } from "@/i18n";
import { PageTitle } from "@/components";

export default function Legal() {
  const { t } = useI18n();
  const blocks = [
    { icon: Scale, title: t("legal.independence"), body: "Masar does not reproduce government or school logos and does not claim official status. All figures link to their official source with a last-verified date. حيث لا يستعمل مسار أي شعار رسمي وكل الأرقام تشير إلى مصادرها الرسمية مع تاريخ آخر تحقق." },
    { icon: Gavel, title: "Guidance, never a guarantee / توجيه فقط", body: `${t("legal.disclaimer")} Thresholds shown are last year's facts, labelled as such. Institutions decide admissions; platforms like Cursussup decide registrations. / العتبات المعروضة حقائق عن السنة الماضية وموسومة كذلك.` },
    { icon: ShieldCheck, title: "Loi 09-08 · Privacy", body: "Answers, grades and lists are stored in this browser's local storage only — nothing is transmitted. Minors are the core audience: no account, no ads, no tracking. Deleting site data removes everything. / الأجوبة والنقط تبقى في متصفحك فقط. لا حساب ولا إعلانات ولا تتبع." },
    { icon: Cookie, title: "Stockage local / التخزين المحلي", body: "Local storage holds: language, theme, shortlist and compare selections, cookie acknowledgement, imported admin demo rows. Nothing else. / التخزين المحلي يحفظ اللغة والمظهر واللوائح فقط." },
  ];
  return (
    <>
      <PageTitle eyebrow="Masar · Transparence" title={t("legal.title")} />
      <div className="mx-auto mt-8 max-w-3xl space-y-4 px-4 pb-16 sm:px-6">
        {blocks.map((b) => (
          <section key={b.title} className="card p-5 sm:p-6">
            <h2 className="flex items-start gap-3 font-extrabold leading-snug">
              <b.icon className="mt-0.5 h-5 w-5 shrink-0 text-[var(--c-accent)]" />
              {b.title}
            </h2>
            <p className="mt-3 text-[0.9rem] leading-relaxed text-[var(--c-sub)]">{b.body}</p>
          </section>
        ))}
      </div>
    </>
  );
}
