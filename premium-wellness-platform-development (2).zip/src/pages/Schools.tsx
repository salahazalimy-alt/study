import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowRight, CheckCircle2, GitCompareArrows, MapPin, PlusCircle, RotateCcw, Search, Wallet } from "lucide-react";
import { useI18n, pick } from "@/i18n";
import { EmptyState, PageTitle } from "@/components";
import { INSTITUTIONS, PROGRAMMES, RULES, THRESHOLDS } from "@/data/records";
import { history } from "@/data/scoring";
import { Sparkline } from "@/components";
import { REGIONS, STREAMS, type BacStream, type Programme, type Sector } from "@/data/types";
import { matchesInstitution } from "@/utils/search";
import { useCompare, useShortlist } from "@/store";
import { cn } from "@/utils/cn";

const FIELDS: Programme["field"][] = [
  "science", "engineering", "medicine", "law", "economics", "letters",
  "architecture", "agronomy", "statistics", "media", "health", "business", "tech",
];
const LEVELS: Programme["level"][] = ["DUT", "Licence", "Ingénieur", "Doctorat", "Technicien", "CPGE"];

export default function Schools() {
  const { t, lang, fmtDate, fmtNum } = useI18n();
  const shortlist = useShortlist();
  const compare = useCompare();
  const [q, setQ] = useState("");
  const [sector, setSector] = useState<Sector | "all">("all");
  const [region, setRegion] = useState<string>("all");
  const [field, setField] = useState<string>("all");
  const [level, setLevel] = useState<string>("all");
  const [maxTuition, setMaxTuition] = useState("");
  const [stream, setStream] = useState<BacStream | "all">("all");
  const [compareMsg, setCompareMsg] = useState(false);

  const filtered = useMemo(() => {
    const maxT = maxTuition.trim() ? Number(maxTuition.replace(",", ".")) : null;
    return INSTITUTIONS.filter((inst) => {
      if (!matchesInstitution(inst, q)) return false;
      if (sector !== "all" && inst.sector !== sector) return false;
      if (region !== "all" && inst.region_key !== region) return false;
      const progs = PROGRAMMES.filter((p) => p.institutionId === inst.id);
      if (field !== "all" && !progs.some((p) => p.field === field)) return false;
      if (level !== "all" && !progs.some((p) => p.level === level)) return false;
      if (maxT !== null && Number.isFinite(maxT)) {
        // public (tuition null) always passes the cap; private must be under it
        const ok = progs.some((p) => p.tuitionMAD === null || p.tuitionMAD <= maxT);
        if (!ok) return false;
      }
      if (stream !== "all") {
        const ok = progs.some((p) => RULES.some((r) => r.programmeId === p.id && r.streams.includes(stream)));
        if (!ok) return false;
      }
      return true;
    }).sort((a, b) => a.name_fr.localeCompare(b.name_fr, "fr"));
  }, [q, sector, region, field, level, maxTuition, stream]);

  const hasFilters = q || sector !== "all" || region !== "all" || field !== "all" || level !== "all" || maxTuition || stream !== "all";

  return (
    <>
      <PageTitle eyebrow="Masar · Explorer" title={t("schools.title")} intro={t("home.sub")} />

      <section className="mx-auto mt-8 max-w-6xl px-4 sm:px-6">
        {/* search */}
        <div className="relative">
          <Search className="mirror-icon pointer-events-none absolute start-4 top-1/2 h-5 w-5 -translate-y-1/2 text-[var(--c-faint)]" />
          <input
            type="search"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder={t("search.placeholder")}
            aria-label={t("search.placeholder")}
            className="field !min-h-[56px] !ps-12 text-base"
          />
        </div>

        {/* filters */}
        <div className="card mt-4 space-y-4 p-4 sm:p-5">
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            <div>
              <span className="label">{t("filters.sector")}</span>
              <div className="flex gap-2">
                {(["all", "public", "private"] as const).map((s) => (
                  <button key={s} type="button" aria-pressed={sector === s} onClick={() => setSector(s)} className="chip flex-1 justify-center">
                    {s === "all" ? t("filters.all") : t(s)}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label htmlFor="f-region" className="label">{t("filters.region")}</label>
              <select id="f-region" className="field" value={region} onChange={(e) => setRegion(e.target.value)}>
                <option value="all">{t("filters.all")}</option>
                {REGIONS.map((r) => (
                  <option key={r} value={r}>{t(`region.${r}`)}</option>
                ))}
              </select>
            </div>
            <div>
              <label htmlFor="f-field" className="label">{t("filters.field")}</label>
              <select id="f-field" className="field" value={field} onChange={(e) => setField(e.target.value)}>
                <option value="all">{t("filters.all")}</option>
                {FIELDS.map((f) => (
                  <option key={f} value={f}>{t(`field.${f}`)}</option>
                ))}
              </select>
            </div>
            <div>
              <label htmlFor="f-level" className="label">{t("filters.level")}</label>
              <select id="f-level" className="field" value={level} onChange={(e) => setLevel(e.target.value)}>
                <option value="all">{t("filters.all")}</option>
                {LEVELS.map((l) => (
                  <option key={l} value={l}>{l}</option>
                ))}
              </select>
            </div>
            <div>
              <label htmlFor="f-stream" className="label">{t("checker.stream")}</label>
              <select id="f-stream" className="field" value={stream} onChange={(e) => setStream(e.target.value as BacStream | "all")}>
                <option value="all">{t("filters.all")}</option>
                {STREAMS.map((s) => (
                  <option key={s.key} value={s.key}>{s[lang]}</option>
                ))}
              </select>
            </div>
            <div>
              <label htmlFor="f-tuition" className="label">{t("filters.maxTuition")}</label>
              <input
                id="f-tuition" inputMode="numeric" className="field num" placeholder="80 000"
                value={maxTuition} onChange={(e) => setMaxTuition(e.target.value)}
              />
            </div>
          </div>
          {hasFilters ? (
            <button
              type="button"
              className="btn btn-outline !min-h-[40px] px-3.5 py-1.5 text-[0.8rem]"
              onClick={() => { setQ(""); setSector("all"); setRegion("all"); setField("all"); setLevel("all"); setMaxTuition(""); setStream("all"); }}
            >
              <RotateCcw className="h-3.5 w-3.5" />
              {t("filters.clear")}
            </button>
          ) : null}
        </div>

        {/* results */}
        <p aria-live="polite" className="mt-5 text-[0.85rem] font-semibold text-[var(--c-sub)]">
          {fmtNum(filtered.length)} / {fmtNum(INSTITUTIONS.length)} — {t("results.count")}
        </p>

        <div className="mt-3 grid gap-3.5 pb-6 md:grid-cols-2">
          {filtered.length === 0 && <EmptyState />}
          {filtered.map((inst) => {
            const progs = PROGRAMMES.filter((p) => p.institutionId === inst.id);
            const saved = shortlist.has(inst.id);
            const inCompare = compare.has(inst.id);
            const rule = RULES.find((r) => progs.some((p) => p.id === r.programmeId));
            // sparkline of the most-covered stream's preselection history
            const histSeries = rule
              ? rule.streams
                  .map((s) => history(THRESHOLDS, rule.id, s, "preselection"))
                  .find((h) => h.length > 0)
              : null;
            const spark = histSeries ? histSeries.map((h) => h.value) : [];
            const tuitions = progs.map((p) => p.tuitionMAD).filter((x): x is number => x !== null);
            return (
              <article key={inst.id} className="card card-hover fade-up flex flex-col p-5">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <h3 className="text-[1rem] font-bold leading-snug">
                      <Link to={`/school/${inst.id}`} className="hover:text-[var(--c-accent)] hover:underline underline-offset-4">
                        {pick(inst, "name", lang)}
                      </Link>
                    </h3>
                    <p className="mt-0.5 flex items-center gap-1 text-[0.8rem] text-[var(--c-sub)]">
                      <MapPin className="h-3.5 w-3.5 text-[var(--c-faint)]" />
                      {pick(inst, "city", lang)} · {t(`region.${inst.region_key}`)}
                    </p>
                  </div>
                  <span className={cn("tag shrink-0", inst.sector === "public" ? "tag-good" : "tag-info")}>{t(inst.sector)}</span>
                </div>

                <div className="mt-3 flex flex-wrap gap-1.5">
                  {progs.slice(0, 3).map((p) => (
                    <span key={p.id} className="tag tag-line">{pick(p, "name", lang)}</span>
                  ))}
                  {rule && (
                    <span className="tag tag-info">{t(`route.${rule.route}`)}</span>
                  )}
                  {tuitions.length > 0 && (
                    <span className="tag tag-line">
                      <Wallet className="h-3 w-3" /> {fmtNum(Math.min(...tuitions))}+ {t("madYear")}
                    </span>
                  )}
                </div>

                <div className="mt-3 flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2 text-[0.74rem] text-[var(--c-faint)]">
                    {t("detail.trend")}
                    <Sparkline points={spark} />
                  </div>
                  {rule && (
                    <span className="inline-flex items-center gap-1 text-[0.74rem] font-semibold text-[var(--c-sub)]">
                      {t("deadline.label")} {fmtDate(rule.registrationDeadline)}
                    </span>
                  )}
                </div>

                <div className="mt-4 flex flex-wrap gap-2 border-t border-[var(--c-line)] pt-3.5">
                  <Link to={`/school/${inst.id}`} className="btn btn-soft !min-h-[40px] px-3.5 py-1.5 text-[0.82rem]">
                    {t("detail.howToApply")}
                    <ArrowRight className="mirror-icon h-3.5 w-3.5" />
                  </Link>
                  <button
                    type="button"
                    aria-pressed={saved}
                    onClick={() => shortlist.toggle(inst.id)}
                    className={cn("btn btn-outline !min-h-[40px] px-3 py-1.5 text-[0.82rem]", saved && "border-[var(--c-accent)] text-[var(--c-accent)]")}
                  >
                    {saved ? <CheckCircle2 className="h-3.5 w-3.5" /> : <PlusCircle className="h-3.5 w-3.5" />}
                    {saved ? t("saved.in") : t("saved.add")}
                  </button>
                  <button
                    type="button"
                    aria-pressed={inCompare}
                    onClick={() => {
                      const r = compare.toggle(inst.id, 4);
                      if (!r.ok) { setCompareMsg(true); window.setTimeout(() => setCompareMsg(false), 2200); }
                    }}
                    className={cn("btn btn-outline !min-h-[40px] px-3 py-1.5 text-[0.82rem]", inCompare && "border-[var(--c-accent)] text-[var(--c-accent)]")}
                  >
                    <GitCompareArrows className="h-3.5 w-3.5" />
                    {inCompare ? t("compare.in") : t("compare.add")}
                  </button>
                </div>
                {compareMsg && (
                  <p role="alert" className="mt-2 text-[0.78rem] font-semibold text-[var(--c-warn)]">{t("compare.limit")}</p>
                )}
              </article>
            );
          })}
        </div>
      </section>
    </>
  );
}
