import { useEffect, useMemo, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { ArrowRight, BookMarked, FileDown, MapPin, Share2, Trash2 } from "lucide-react";
import { useI18n, pick } from "@/i18n";
import { PageTitle } from "@/components";
import { institutionById, programmesOf, rulesOf } from "@/data/records";
import { loadIdsFromQuery, useShortlist } from "@/store";
import { cn } from "@/utils/cn";

export default function Shortlist() {
  const { t, lang, fmtDate, fmtNum } = useI18n();
  const shortlist = useShortlist();
  const location = useLocation();
  const [copied, setCopied] = useState(false);

  // accept shared lists: #/shortlist?ids=a,b
  useEffect(() => {
    const ids = loadIdsFromQuery(location.search ?? location.hash);
    if (ids.length > 0) shortlist.set([...new Set([...ids])]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [location.search, location.hash]);

  const insts = useMemo(
    () => shortlist.items.map((id) => institutionById(id)).filter((x): x is NonNullable<typeof x> => !!x),
    [shortlist.items]
  );

  const shareUrl = `${window.location.origin}${window.location.pathname}#/shortlist?ids=${shortlist.items.join(",")}`;

  async function copyShare() {
    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    } catch { /* ignore */ }
  }

  return (
    <>
      <PageTitle eyebrow="Masar · Ma liste" title={t("saved.title")} intro={t("saved.stored")} />
      <div className="mx-auto mt-8 max-w-4xl px-4 sm:px-6">
        <div className="no-print flex flex-wrap gap-2.5">
          <button type="button" onClick={copyShare} disabled={!insts.length} className="btn btn-outline disabled:opacity-40">
            <Share2 className="h-4 w-4" />
            {copied ? t("copied") : t("saved.share")}
          </button>
          <a
            className={cn("btn btn-outline", !insts.length && "pointer-events-none opacity-40")}
            href={`https://wa.me/?text=${encodeURIComponent(`${t("saved.title")} — MASAR\n${shareUrl}`)}`}
            target="_blank" rel="noreferrer"
            aria-disabled={!insts.length}
          >
            {t("saved.whatsapp")}
          </a>
          <button type="button" onClick={() => window.print()} disabled={!insts.length} className="btn btn-outline disabled:opacity-40">
            <FileDown className="h-4 w-4" />
            {t("saved.pdf")}
          </button>
          <button type="button" onClick={() => shortlist.set([])} disabled={!insts.length} className="btn btn-outline disabled:opacity-40">
            <Trash2 className="h-4 w-4" />
            {t("filters.clear")}
          </button>
        </div>

        {insts.length === 0 ? (
          <div className="card mt-6 grid place-items-center gap-3 p-12 text-center">
            <BookMarked className="h-6 w-6 text-[var(--c-faint)]" />
            <p className="max-w-sm text-[0.9rem] text-[var(--c-sub)]">{t("saved.empty")}</p>
            <Link to="/schools" className="btn btn-primary mt-2">{t("nav.schools")}</Link>
          </div>
        ) : (
          <ol className="mt-6 space-y-3.5 pb-10">
            {insts.map((inst, idx) => {
              const progs = programmesOf(inst.id);
              const rule = progs.flatMap((p) => rulesOf(p.id))[0];
              return (
                <li key={inst.id} className="card flex flex-wrap items-center gap-4 p-4.5 sm:p-5">
                  <span className="num grid h-9 w-9 shrink-0 place-items-center rounded-full bg-[var(--c-raised)] font-extrabold text-[var(--c-accent)]">
                    {idx + 1}
                  </span>
                  <div className="min-w-0 flex-1">
                    <h3 className="font-bold leading-snug">
                      <Link to={`/school/${inst.id}`} className="hover:text-[var(--c-accent)] hover:underline underline-offset-4">
                        {pick(inst, "name", lang)}
                      </Link>
                    </h3>
                    <p className="mt-0.5 flex flex-wrap items-center gap-x-3 gap-y-0.5 text-[0.8rem] text-[var(--c-sub)]">
                      <span className="inline-flex items-center gap-1">
                        <MapPin className="h-3.5 w-3.5 text-[var(--c-faint)]" />
                        {pick(inst, "city", lang)}
                      </span>
                      <span className={cn("tag !text-[0.68rem]", inst.sector === "public" ? "tag-good" : "tag-info")}>{t(inst.sector)}</span>
                      {rule && (
                        <span>
                          {t("deadline.label")} <span className="num font-bold">{fmtDate(rule.registrationDeadline)}</span>
                        </span>
                      )}
                    </p>
                  </div>
                  <div className="no-print flex items-center gap-2">
                    <span className="text-[0.78rem] font-semibold text-[var(--c-faint)]">
                      {fmtNum(progs.length)} {t("detail.programmes").toLowerCase()}
                    </span>
                    <Link to={`/school/${inst.id}`} className="btn btn-icon btn-soft" aria-label={t("detail.howToApply")}>
                      <ArrowRight className="mirror-icon h-4 w-4" />
                    </Link>
                    <button
                      type="button"
                      onClick={() => shortlist.toggle(inst.id)}
                      aria-label={t("filters.clear")}
                      className="btn btn-icon btn-outline"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </li>
              );
            })}
          </ol>
        )}
        <p className="no-print pb-10 text-[0.75rem] text-[var(--c-faint)]">{t("legal.disclaimer")}</p>
      </div>
    </>
  );
}
