import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { Award, Bell, BellRing, CalendarPlus, FileText, ListTodo, PenLine } from "lucide-react";
import { useI18n, pick } from "@/i18n";
import { PageTitle } from "@/components";
import { EVENTS, institutionById } from "@/data/records";
import type { CalendarEvent } from "@/data/types";
import { cn } from "@/utils/cn";

const KIND_ICON = { registration: ListTodo, preselection: FileText, exam: PenLine, scholarship: Award } as const;
const KIND_TAG = { registration: "tag-info", preselection: "tag-warn", exam: "tag-bad", scholarship: "tag-good" } as const;

function icsFor(ev: CalendarEvent, lang: "fr" | "ar"): string {
  const stamp = new Date().toISOString().replace(/[-:]|\.\d+/g, "").slice(0, 15) + "Z";
  const dt = ev.dateStart.split("-").join("");
  const end = (ev.dateEnd ?? ev.dateStart).split("-").join("");
  const title = pick(ev as never as Record<string, string>, "title", lang);
  const desc = pick(ev as never as Record<string, string>, "note", lang);
  return [
    "BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//MASAR//orientation//MA",
    "BEGIN:VEVENT", `UID:${ev.id}@masar`, `DTSTAMP:${stamp}`,
    `DTSTART;VALUE=DATE:${dt}`, `DTEND;VALUE=DATE:${end}`,
    `SUMMARY:MASAR — ${title}`, `DESCRIPTION:${desc.replace(/\n/g, "\\n")}`,
    "BEGIN:VALARM", "TRIGGER:-P2D", "ACTION:DISPLAY", `DESCRIPTION:${title}`, "END:VALARM",
    "END:VEVENT", "END:VCALENDAR",
  ].join("\r\n");
}

function downloadIcs(ev: CalendarEvent, lang: "fr" | "ar") {
  const blob = new Blob([icsFor(ev, lang)], { type: "text/calendar;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `masar-${ev.id}.ics`;
  a.click();
  URL.revokeObjectURL(url);
}

export default function Calendar() {
  const { t, lang, fmtDate, fmtNum } = useI18n();
  const [kind, setKind] = useState<string>("all");
  const [reminders, setReminders] = useState<string[]>(() => {
    try { return JSON.parse(localStorage.getItem("masar:reminders") ?? "[]"); } catch { return []; }
  });

  const events = useMemo(
    () =>
      EVENTS.filter((e) => (kind === "all" ? true : e.kind === kind)).sort((a, b) =>
        a.dateStart.localeCompare(b.dateStart)
      ),
    [kind]
  );

  async function toggleReminder(ev: CalendarEvent) {
    if (reminders.includes(ev.id)) {
      const next = reminders.filter((x) => x !== ev.id);
      setReminders(next);
      try { localStorage.setItem("masar:reminders", JSON.stringify(next)); } catch { /* ignore */ }
      return;
    }
    if ("Notification" in window && Notification.permission === "default") {
      try { await Notification.requestPermission(); } catch { /* ignore */ }
    }
    const next = [...reminders, ev.id];
    setReminders(next);
    try { localStorage.setItem("masar:reminders", JSON.stringify(next)); } catch { /* ignore */ }
    if ("Notification" in window && Notification.permission === "granted") {
      const soon = new Date(ev.dateStart).getTime() - Date.now() < 14 * 86400000;
      if (soon) {
        try {
          new Notification("MASAR — " + pick(ev as never as Record<string, string>, "title", lang), {
            body: `${fmtDate(ev.dateStart)} · 2d`,
          });
        } catch { /* some browsers need a service worker — flag still saved */ }
      }
    }
  }

  const months = useMemo(() => {
    const map = new Map<string, CalendarEvent[]>();
    for (const e of events) {
      const k = e.dateStart.slice(0, 7);
      if (!map.has(k)) map.set(k, []);
      map.get(k)!.push(e);
    }
    return [...map.entries()];
  }, [events]);

  return (
    <>
      <PageTitle
        eyebrow="Masar · Calendrier"
        title={t("cal.title")}
        intro={t("checker.guide")}
      />
      <div className="mx-auto mt-8 max-w-4xl px-4 sm:px-6">
        <div className="flex flex-wrap gap-2" role="group" aria-label={t("cal.title")}>
          {(["all", "registration", "preselection", "exam", "scholarship"] as const).map((k) => (
            <button key={k} type="button" aria-pressed={kind === k} onClick={() => setKind(k)} className="chip">
              {k === "all" ? t("cal.all") : t(`cal.kind.${k}`)}
            </button>
          ))}
        </div>

        <div className="mt-8 space-y-8 pb-10">
          {months.map(([month, list]) => (
            <section key={month}>
              <h2 className="num mb-3 text-sm font-extrabold uppercase tracking-[0.12em] text-[var(--c-faint)]">
                {fmtDate(month + "-01", { month: "long", year: "numeric" })}
              </h2>
              <div className="space-y-3">
                {list.map((ev) => {
                  const inst = ev.institutionId ? institutionById(ev.institutionId) : null;
                  const Icon = KIND_ICON[ev.kind];
                  const reminded = reminders.includes(ev.id);
                  return (
                    <article key={ev.id} className="card card-hover flex flex-wrap items-center gap-4 p-4 sm:p-5">
                      <div className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-[var(--c-raised)] text-center">
                        <div>
                          <p className="num text-lg font-extrabold leading-none">{ev.dateStart.slice(8, 10)}</p>
                          <p className="num mt-0.5 text-[0.6rem] font-bold uppercase text-[var(--c-faint)]">
                            {fmtDate(ev.dateStart, { month: "short" })}
                          </p>
                        </div>
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="flex flex-wrap items-center gap-2">
                          <span className={cn("tag", KIND_TAG[ev.kind])}>
                            <Icon className="h-3 w-3" />
                            {t(`cal.kind.${ev.kind}`)}
                          </span>
                          <span className="tag tag-demo">{t("example.badge")}</span>
                          {ev.dateEnd && (
                            <span className="num text-[0.72rem] text-[var(--c-faint)]">
                              → {fmtDate(ev.dateEnd)}
                            </span>
                          )}
                        </p>
                        <h3 className="mt-1.5 text-[0.95rem] font-bold leading-snug">
                          {pick(ev, "title", lang)}
                        </h3>
                        <p className="mt-0.5 text-[0.8rem] text-[var(--c-sub)]">
                          {pick(ev, "note", lang)}
                          {inst && (
                            <>
                              {" — "}
                              <Link to={`/school/${inst.id}`} className="font-semibold text-[var(--c-accent)] hover:underline underline-offset-2">
                                {pick(inst, "short", lang)}
                              </Link>
                            </>
                          )}
                        </p>
                      </div>
                      <div className="flex flex-col gap-2 sm:flex-row">
                        <button
                          type="button"
                          onClick={() => downloadIcs(ev, lang)}
                          className="btn btn-outline !min-h-[40px] px-3 py-1.5 text-[0.78rem]"
                        >
                          <CalendarPlus className="h-3.5 w-3.5" />
                          {t("cal.ics")}
                        </button>
                        <button
                          type="button"
                          onClick={() => toggleReminder(ev)}
                          aria-pressed={reminded}
                          className={cn("btn !min-h-[40px] px-3 py-1.5 text-[0.78rem]", reminded ? "btn-soft" : "btn-outline")}
                        >
                          {reminded ? <BellRing className="h-3.5 w-3.5" /> : <Bell className="h-3.5 w-3.5" />}
                          {reminded ? t("cal.remindOn") : t("cal.remind")}
                        </button>
                      </div>
                    </article>
                  );
                })}
              </div>
            </section>
          ))}
          {events.length === 0 && (
            <p className="text-center text-[var(--c-sub)]">{t("empty.title")}</p>
          )}
        </div>
        <p className="pb-10 text-[0.75rem] text-[var(--c-faint)]">
          {fmtNum(events.length)} · {t("legal.disclaimer")}
        </p>
      </div>
    </>
  );
}
