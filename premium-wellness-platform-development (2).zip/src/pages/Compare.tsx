import { Link } from "react-router-dom";
import { Award, MapPin, RotateCcw, Trash2, Wallet } from "lucide-react";
import { useI18n, pick } from "@/i18n";
import { PageTitle } from "@/components";
import { SCHOLARSHIPS, institutionById, programmesOf, rulesOf, thresholdsOf } from "@/data/records";
import { fmtScore, history } from "@/data/scoring";
import { useCompare } from "@/store";
import { cn } from "@/utils/cn";

export default function Compare() {
  const { t, lang, fmtNum } = useI18n();
  const compare = useCompare();
  const loc = lang === "ar" ? "ar-MA-u-nu-latn" : "fr-MA";

  const insts = compare.items.map((id) => institutionById(id)).filter((x): x is NonNullable<typeof x> => !!x);

  if (insts.length === 0) {
    return (
      <>
        <PageTitle eyebrow="Masar · Comparer" title={t("compare.title")} />
        <div className="mx-auto mt-10 max-w-3xl px-4 text-center sm:px-6">
          <div className="card grid place-items-center gap-3 p-12">
            <GitCompareArrowsIcon />
            <p className="max-w-sm text-[0.92rem] text-[var(--c-sub)]">{t("compare.empty")}</p>
            <Link to="/schools" className="btn btn-primary mt-2">{t("nav.schools")}</Link>
          </div>
        </div>
      </>
    );
  }

  const rows: { label: string; render: (id: string) => React.ReactNode }[] = [
    {
      label: t("compare.col.sector"),
      render: (id) => {
        const s = institutionById(id)!.sector;
        return <span className={cn("tag", s === "public" ? "tag-good" : "tag-info")}>{t(s)}</span>;
      },
    },
    {
      label: t("compare.col.threshold"),
      render: (id) => {
        const rule = programmesOf(id).flatMap((p) => rulesOf(p.id)).find((r) => thresholdsOf(r.id).some((x) => x.value !== null));
        if (!rule) return <span className="text-[0.85rem] text-[var(--c-faint)]">{t("notPublished")}</span>;
        const latest = rule.streams
          .flatMap((s) => history(thresholdsOf(rule.id), rule.id, s, "preselection"))
          .filter((h) => h.value !== null && h.year === 2025);
        if (!latest.length) return <span className="text-[0.85rem] text-[var(--c-faint)]">{t("notPublished")}</span>;
        const min = Math.min(...latest.map((h) => h.value!));
        const max = Math.max(...latest.map((h) => h.value!));
        return (
          <span className="num font-bold">
            {fmtScore(min, loc)} – {fmtScore(max, loc)}
            <span className="ms-1 text-[0.68rem] font-medium text-[var(--c-faint)]">/20 · 2025*</span>
          </span>
        );
      },
    },
    {
      label: t("compare.col.cost"),
      render: (id) => {
        const tuit = programmesOf(id).map((p) => p.tuitionMAD).filter((x): x is number => x !== null);
        if (!tuit.length) return <span className="tag tag-good">{t("public")}</span>;
        return (
          <span className="num font-semibold">
            <Wallet className="me-1 inline h-3.5 w-3.5 text-[var(--c-faint)]" />
            {fmtNum(Math.min(...tuit))} – {fmtNum(Math.max(...tuit))} {t("madYear")}
          </span>
        );
      },
    },
    {
      label: t("compare.col.city"),
      render: (id) => {
        const i = institutionById(id)!;
        return (
          <span className="font-semibold">
            <MapPin className="me-1 inline h-3.5 w-3.5 text-[var(--c-faint)]" />
            {pick(i, "city", lang)}
          </span>
        );
      },
    },
    {
      label: t("compare.col.duration"),
      render: (id) => {
        const ds = [...new Set(programmesOf(id).map((p) => p.durationYears))].sort((a, b) => a - b);
        return <span className="num font-semibold">{ds.map((d) => `${fmtNum(d)} ${t("duration.years")}`).join(" / ")}</span>;
      },
    },
    {
      label: t("compare.col.language"),
      render: (id) => {
        const langs = [...new Set(programmesOf(id).flatMap((p) => p.languages))];
        return <span className="font-semibold">{langs.map((l) => l.toUpperCase()).join(" · ")}</span>;
      },
    },
    {
      label: t("compare.col.scholarships"),
      render: (id) => {
        const sector = institutionById(id)!.sector;
        const list = SCHOLARSHIPS.filter((s) => s.forSectors === null || s.forSectors.includes(sector));
        return (
          <span className="font-semibold">
            <Award className="me-1 inline h-3.5 w-3.5 text-[var(--c-accent)]" />
            {fmtNum(list.length)} — {list[0] ? pick(list[0], "name", lang) : ""}
          </span>
        );
      },
    },
  ];

  return (
    <>
      <PageTitle eyebrow="Masar · Comparer" title={t("compare.title")} />
      <div className="mx-auto mt-8 max-w-6xl px-4 sm:px-6">
        <div className="mb-4 flex justify-end">
          <button type="button" onClick={() => compare.set([])} className="btn btn-outline !min-h-[40px] px-3.5 py-1.5 text-[0.8rem]">
            <RotateCcw className="h-3.5 w-3.5" /> {t("filters.clear")}
          </button>
        </div>
        <div className="card overflow-x-auto">
          <table className="table-clean min-w-[640px]">
            <thead>
              <tr>
                <th className="w-40" />
                {insts.map((i) => (
                  <th key={i.id} className="align-top">
                    <Link to={`/school/${i.id}`} className="text-[0.95rem] font-bold normal-case tracking-normal text-[var(--c-ink)] hover:text-[var(--c-accent)]">
                      {pick(i, "name", lang)}
                    </Link>
                    <button
                      type="button"
                      onClick={() => compare.toggle(i.id)}
                      aria-label={`${t("filters.clear")} — ${pick(i, "name", lang)}`}
                      className="ms-1.5 inline-grid h-7 w-7 place-items-center rounded-md text-[var(--c-faint)] hover:text-[var(--c-bad)]"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr key={row.label}>
                  <td className="text-[0.78rem] font-bold uppercase tracking-wide text-[var(--c-faint)]">{row.label}</td>
                  {insts.map((i) => (
                    <td key={i.id}>{row.render(i.id)}</td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="mt-4 text-[0.75rem] text-[var(--c-faint)]">* {t("verdict.lastYear")} — {t("legal.disclaimer")}</p>
      </div>
    </>
  );
}

function GitCompareArrowsIcon() {
  return (
    <svg className="h-7 w-7 text-[var(--c-faint)]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" aria-hidden>
      <circle cx="5" cy="6" r="2.4" /><circle cx="5" cy="18" r="2.4" /><circle cx="19" cy="6" r="2.4" />
      <path d="M5 8.4v7.2M19 8.4c0 4-4.5 4.5-7 4.6" />
    </svg>
  );
}
