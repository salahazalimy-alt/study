import { FormEvent, useState } from "react";
import { AlertTriangle, Award, CalendarDays, CheckCircle2, ExternalLink, FileCheck2 } from "lucide-react";
import { useI18n, pick } from "@/i18n";
import { PageTitle, SourceNote } from "@/components";
import { SCHOLARSHIPS } from "@/data/records";
import type { Sector } from "@/data/types";

interface Answers {
  age: number | null;
  grade: number | null;
  honours: boolean | null;
  rsu: "yes" | "no" | "unknown" | null;
  sector: "any" | Sector | "abroad";
}

export default function Scholarships() {
  const { t, lang, fmtNum, fmtDate } = useI18n();
  const [form, setForm] = useState<Answers>({ age: null, grade: null, honours: null, rsu: null, sector: "any" });
  const [matched, setMatched] = useState<{ id: string; caution: boolean }[] | null>(null);

  function runMatch(e: FormEvent) {
    e.preventDefault();
    const res = SCHOLARSHIPS.map((s) => {
      if (s.type === "state-need") {
        if (form.sector === "abroad") return null;
        if (form.rsu === "no") return null;
        if (s.ageCap !== null && form.age !== null && form.age > s.ageCap) return null;
        return { id: s.id, caution: form.rsu !== "yes" };
      }
      if (s.type === "merit") {
        if (form.sector === "abroad") return null;
        const ok = (form.grade !== null && s.minBacGrade !== null && form.grade >= s.minBacGrade) || form.honours === true;
        const caution = !ok;
        return { id: s.id, caution };
      }
      if (s.type === "private") {
        if (form.sector === "public" || form.sector === "abroad") return null;
        const caution = !(form.grade !== null && s.minBacGrade !== null && form.grade >= s.minBacGrade);
        return { id: s.id, caution };
      }
      if (s.type === "foundation") return { id: s.id, caution: true };
      if (s.type === "abroad") {
        if (form.sector !== "abroad") return null;
        const caution = !(form.grade !== null && s.minBacGrade !== null && form.grade >= s.minBacGrade);
        return { id: s.id, caution };
      }
      return { id: s.id, caution: true };
    }).filter((x): x is { id: string; caution: boolean } => x !== null);
    setMatched(res);
  }

  const visible = matched === null ? SCHOLARSHIPS : SCHOLARSHIPS.filter((s) => matched.some((m) => m.id === s.id));

  return (
    <>
      <PageTitle
        eyebrow="Masar · Bourses"
        title={t("sch.title")}
        intro={t("sch.mayQualify")}
      />

      <div className="mx-auto mt-8 max-w-6xl space-y-8 px-4 sm:px-6">
        {/* matcher */}
        <section className="card p-5 sm:p-7" aria-labelledby="match-h">
          <h2 id="match-h" className="flex items-center gap-2 text-lg font-extrabold">
            <Award className="h-5 w-5 text-[var(--c-accent)]" />
            {t("sch.matcher.title")}
          </h2>
          <p className="mt-1.5 text-[0.8rem] text-[var(--c-sub)]">{t("sch.noneAnswers")}</p>

          <form onSubmit={runMatch} className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
            <div>
              <label htmlFor="sc-age" className="label">{t("sch.age")}</label>
              <input
                id="sc-age" inputMode="numeric" className="field num" placeholder="18"
                value={form.age ?? ""} onChange={(e) => setForm((f) => ({ ...f, age: e.target.value ? Number(e.target.value) : null }))}
              />
            </div>
            <div>
              <label htmlFor="sc-grade" className="label">{t("sch.grade")}</label>
              <input
                id="sc-grade" inputMode="decimal" className="field num" placeholder="15,25"
                value={form.grade ?? ""} onChange={(e) => setForm((f) => ({ ...f, grade: e.target.value ? Number(e.target.value.replace(",", ".")) : null }))}
              />
            </div>
            <div>
              <label htmlFor="sc-mention" className="label">{t("sch.mention")}</label>
              <select
                id="sc-mention" className="field"
                value={form.honours === null ? "" : form.honours ? "yes" : "no"}
                onChange={(e) => setForm((f) => ({ ...f, honours: e.target.value === "" ? null : e.target.value === "yes" }))}
              >
                <option value="">—</option>
                <option value="yes">{t("sch.mention.bien")}</option>
                <option value="no">{t("sch.mention.none")}</option>
              </select>
            </div>
            <div>
              <label htmlFor="sc-rsu" className="label">{t("sch.rsu")}</label>
              <select
                id="sc-rsu" className="field" value={form.rsu ?? ""}
                onChange={(e) => setForm((f) => ({ ...f, rsu: (e.target.value || null) as Answers["rsu"] }))}
              >
                <option value="">—</option>
                <option value="yes">{t("sch.yes")}</option>
                <option value="no">{t("sch.no")}</option>
                <option value="unknown">{t("sch.dontKnow")}</option>
              </select>
            </div>
            <div>
              <label htmlFor="sc-sector" className="label">{t("sch.sectorQ")}</label>
              <select
                id="sc-sector" className="field" value={form.sector}
                onChange={(e) => setForm((f) => ({ ...f, sector: e.target.value as Answers["sector"] }))}
              >
                <option value="any">{t("sch.any")}</option>
                <option value="public">{t("public")}</option>
                <option value="private">{t("private")}</option>
                <option value="abroad">{t("sch.abroad")}</option>
              </select>
            </div>
            <div className="sm:col-span-2 lg:col-span-5">
              <button type="submit" className="btn btn-primary">
                <CheckCircle2 className="h-4.5 w-4.5" />
                {t("sch.results")}
              </button>
            </div>
          </form>

          {matched !== null && (
            <div className="fade-up mt-4 rounded-xl border border-[var(--c-accent)]/30 bg-[var(--c-accent-soft)]/60 p-4" aria-live="polite">
              <p className="text-[0.86rem] font-semibold text-[var(--c-accent)]">
                {matched.length > 0 ? `${t("sch.results")} — ${fmtNum(matched.length)}` : t("sch.none")}
              </p>
              <p className="mt-1 text-[0.78rem] text-[var(--c-sub)]">{t("sch.mayQualify")}</p>
            </div>
          )}
        </section>

        {/* note about changing rules */}
        <div className="flex items-start gap-3 rounded-xl border border-dashed border-[var(--c-warn)]/50 bg-[var(--c-warn-soft)]/50 p-4 text-[0.82rem] leading-relaxed text-[var(--c-warn)]">
          <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
          {t("sch.noteChanged")}
        </div>

        {/* cards */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {visible.map((s) => {
            const m = matched?.find((x) => x.id === s.id);
            return (
              <article key={s.id} className="card card-hover flex flex-col p-5 sm:p-6">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="font-bold leading-snug">{pick(s, "name", lang)}</p>
                    <p className="mt-1 text-[0.78rem] text-[var(--c-sub)]">{pick(s, "provider", lang)}</p>
                  </div>
                  {m && (
                    <span className={cn2("tag shrink-0", m.caution ? "tag-warn" : "tag-good")}>
                      {m.caution ? "≈" : "✓"} {t("sch.results")}
                    </span>
                  )}
                </div>
                <p className="num mt-3 text-2xl font-extrabold text-[var(--c-accent)]">
                  {s.amountMAD !== null ? `${fmtNum(s.amountMAD)} ${t("madYear")}` : t("notPublished")}
                </p>
                <p className="mt-1 text-[0.78rem] text-[var(--c-sub)]">{pick(s, "renewal", lang)}</p>

                <div className="mt-4 space-y-2 border-t border-[var(--c-line)] pt-4 text-[0.8rem]">
                  <p className="flex items-center gap-2 font-semibold text-[var(--c-sub)]">
                    <CalendarDays className="h-3.5 w-3.5 text-[var(--c-faint)]" />
                    {t("sch.nextDeadline")}: {" "}
                    <span className="num font-bold text-[var(--c-ink)]">
                      {s.deadlineISO ? fmtDate(s.deadlineISO) : pick(s, "window", lang)}
                    </span>
                  </p>
                  <div>
                    <p className="flex items-center gap-2 font-bold">
                      <FileCheck2 className="h-3.5 w-3.5 text-[var(--c-faint)]" />
                      {t("sch.docs")}
                    </p>
                    <ul className="mt-1.5 list-disc space-y-1 ps-5 text-[var(--c-sub)]">
                      {(lang === "ar" ? s.docs_ar : s.docs_fr).map((d) => (
                        <li key={d}>{d}</li>
                      ))}
                    </ul>
                  </div>
                  <p className="pt-1 leading-relaxed text-[var(--c-sub)]">{pick(s, "howto", lang)}</p>
                </div>

                <div className="mt-auto pt-4">
                  <a href={s.officialUrl} target="_blank" rel="noreferrer" className="btn btn-soft !min-h-[42px] w-full text-[0.85rem]">
                    {t("sch.howto")}
                    <ExternalLink className="h-4 w-4" />
                  </a>
                  <div className="mt-2">
                    <SourceNote sourceId={s.sourceId} verifiedAt={s.lastVerified} />
                  </div>
                </div>
              </article>
            );
          })}
        </div>
        <div className="h-4" />
      </div>
    </>
  );
}

// tiny alias so state style reads cleanly
function cn2(...xs: (string | false | undefined)[]) {
  return xs.filter(Boolean).join(" ");
}
