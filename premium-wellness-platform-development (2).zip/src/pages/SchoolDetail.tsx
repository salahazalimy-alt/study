import { useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import {
  Award, CalendarDays, CheckCircle2, ExternalLink, FileText, GitCompareArrows,
  Landmark, Languages as LangIcon, LineChart, MapPin, MousePointerClick, Share2,
  ShieldCheck, Timer, Wallet,
} from "lucide-react";
import { useI18n, pick } from "@/i18n";
import { BackLink, ReportError, SourceNote, ThresholdValue, TrendChart } from "@/components";
import { SCHOLARSHIPS, institutionById, programmesOf, rulesOf, thresholdsOf } from "@/data/records";
import { fmtScore, history } from "@/data/scoring";
import { STREAMS, type BacStream } from "@/data/types";
import { useCompare, useShortlist } from "@/store";
import { cn } from "@/utils/cn";

const STEP_ORDER: Record<string, string[]> = {
  "preselection-exam": ["step.register", "step.preselection", "step.exam"],
  exam: ["step.register", "step.exam"],
  file: ["step.file"],
  interview: ["step.file", "step.interview"],
  open: ["step.register"],
};

export default function SchoolDetail() {
  const { id } = useParams();
  const { t, lang, fmtDate, fmtNum } = useI18n();
  const shortlist = useShortlist();
  const compare = useCompare();
  const [streamSel, setStreamSel] = useState<BacStream | null>(null);
  const [copied, setCopied] = useState(false);
  const [compareMsg, setCompareMsg] = useState(false);

  const inst = id ? institutionById(id) : undefined;
  const progs = useMemo(() => (inst ? programmesOf(inst.id) : []), [inst]);
  const rules = useMemo(() => progs.flatMap((p) => rulesOf(p.id)), [progs]);
  const rule = rules.find((r) => thresholdsOf(r.id).length > 0) ?? rules[0];
  const loc = lang === "ar" ? "ar-MA-u-nu-latn" : "fr-MA";

  // preselection when published, otherwise final cut-offs — never mixed in one chart
  const stageWithData = useMemo(() => {
    if (!rule) return "preselection" as const;
    const th = thresholdsOf(rule.id);
    const preHas = th.some((x) => x.stage === "preselection" && x.value !== null);
    const finHas = th.some((x) => x.stage === "final" && x.value !== null);
    return preHas || !finHas ? ("preselection" as const) : ("final" as const);
  }, [rule]);

  const trend = useMemo(() => {
    if (!rule) return [];
    return rule.streams.map((s) => ({
      stream: s,
      points: history(thresholdsOf(rule.id), rule.id, s, stageWithData).map((x) => ({ year: x.year, value: x.value })),
    })).filter((srs) => srs.points.some((p) => p.value !== null));
  }, [rule, stageWithData]);

  const activeStream = (rule && streamSel && rule.streams.includes(streamSel)) ? streamSel : rule?.streams[0] ?? null;
  const latestForStream = useMemo(() => {
    if (!rule || !activeStream) return null;
    return history(thresholdsOf(rule.id), rule.id, activeStream, stageWithData).filter((h) => h.value !== null).at(-1) ?? null;
  }, [rule, activeStream, stageWithData]);

  const scholarships = useMemo(() => {
    if (!inst) return [];
    return SCHOLARSHIPS.filter(
      (s) =>
        (s.forSectors === null || s.forSectors.includes(inst.sector))
    );
  }, [inst]);

  if (!inst) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-20 text-center">
        <p className="text-lg font-bold">404</p>
        <BackLink to="/schools" />
      </div>
    );
  }

  const osm = `https://www.openstreetmap.org/export/embed.html?bbox=${inst.lng - 0.04}%2C${inst.lat - 0.03}%2C${inst.lng + 0.04}%2C${inst.lat + 0.03}&layer=mapnik&marker=${inst.lat}%2C${inst.lng}`;

  async function share() {
    const url = window.location.href;
    const text = `${pick(inst!, "name", lang)} — MASAR`;
    if (navigator.share) {
      try { await navigator.share({ title: text, url }); return; } catch { /* cancelled */ }
    }
    try { await navigator.clipboard.writeText(url); setCopied(true); window.setTimeout(() => setCopied(false), 2000); } catch { /* ignore */ }
  }

  const saved = shortlist.has(inst.id);
  const inCompare = compare.has(inst.id);

  return (
    <article className="mx-auto max-w-4xl px-4 pb-16 sm:px-6">
      {/* header */}
      <div className="pt-8 sm:pt-10">
        <BackLink to="/schools" />
        <div className="mt-5 flex flex-wrap items-start justify-between gap-4">
          <div className="min-w-0 flex-1">
            <p className="eyebrow">{pick(inst, "category", lang)}</p>
            <h1 className="mt-2 text-[clamp(1.5rem,4.6vw,2.3rem)] font-extrabold leading-tight tracking-tight">
              {pick(inst, "name", lang)}
            </h1>
            <div className="mt-3 flex flex-wrap items-center gap-2">
              <span className={cn("tag", inst.sector === "public" ? "tag-good" : "tag-info")}>{t(inst.sector)}</span>
              <span className="tag tag-line">
                <MapPin className="h-3 w-3" /> {pick(inst, "city", lang)} · {t(`region.${inst.region_key}`)}
              </span>
              <span className="tag tag-line">
                <ShieldCheck className="h-3 w-3" /> {pick(inst, "recognition", lang)}
              </span>
              <span className="tag tag-demo">{t("example.badge")}</span>
            </div>
            <SourceNote sourceId={inst.sourceId} verifiedAt={inst.lastVerified} />
          </div>
          <div className="flex flex-wrap gap-2">
            <button type="button" onClick={share} className="btn btn-outline !min-h-[44px] px-4 py-2 text-sm">
              <Share2 className="h-4 w-4" />
              {copied ? t("copied") : t("share")}
            </button>
            <button
              type="button"
              aria-pressed={saved}
              onClick={() => shortlist.toggle(inst.id)}
              className={cn("btn !min-h-[44px] px-4 py-2 text-sm", saved ? "btn-primary" : "btn-outline")}
            >
              {saved ? <CheckCircle2 className="h-4 w-4" /> : <BookMarkedIcon />}
              {saved ? t("saved.in") : t("saved.add")}
            </button>
            <button
              type="button"
              aria-pressed={inCompare}
              onClick={() => {
                const r = compare.toggle(inst.id, 4);
                if (!r.ok) { setCompareMsg(true); window.setTimeout(() => setCompareMsg(false), 2200); }
              }}
              className={cn("btn btn-outline !min-h-[44px] px-4 py-2 text-sm", inCompare && "border-[var(--c-accent)] text-[var(--c-accent)]")}
            >
              <GitCompareArrows className="h-4 w-4" />
              {t("compare.add")}
            </button>
            {compareMsg && <p role="alert" className="w-full text-[0.78rem] font-semibold text-[var(--c-warn)]">{t("compare.limit")}</p>}
          </div>
        </div>
        <p className="mt-5 max-w-2xl leading-relaxed text-[var(--c-sub)]">{pick(inst, "about", lang)}</p>
      </div>

      {/* reverse-search hero block */}
      {rule && latestForStream && (
        <section className="card mt-8 p-5 sm:p-6" aria-labelledby="reverse-h">
          <h2 id="reverse-h" className="flex items-center gap-2 text-base font-extrabold">
            <LineChart className="h-4.5 w-4.5 text-[var(--c-accent)]" />
            {t("reverse.title")}
          </h2>
          <div className="mt-4 flex flex-wrap gap-2" role="group" aria-label={t("reverse.pickStream")}>
            {rule.streams.map((s) => (
              <button
                key={s}
                type="button"
                aria-pressed={activeStream === s}
                onClick={() => setStreamSel(s)}
                className="chip !min-h-[38px] !px-3.5 !py-1.5 !text-[0.8rem]"
              >
                {STREAMS.find((x) => x.key === s)?.[lang]}
              </button>
            ))}
          </div>
          <div className="mt-4 grid gap-5 sm:grid-cols-[13rem_1fr] sm:items-center">
            <div className="rounded-2xl bg-[var(--c-raised)] p-4 text-center">
              <p className="text-[0.7rem] font-bold uppercase tracking-wide text-[var(--c-faint)]">
                {t("reverse.needed")} · {activeStream ? STREAMS.find((x) => x.key === activeStream)?.[lang] : ""}
              </p>
              <p className="num mt-1 text-4xl font-extrabold text-[var(--c-accent)]">
                {latestForStream.value !== null ? fmtScore(latestForStream.value, loc) : t("notPublished")}
              </p>
              <p className="mt-1 text-[0.72rem] text-[var(--c-faint)]">
                {t("verdict.lastYear")} ({latestForStream.year})*
              </p>
              <SourceNote sourceId={latestForStream.sourceId} verifiedAt={latestForStream.verifiedAt} />
            </div>
            <div>
              <p className="label">{t("reverse.chart")}</p>
              <TrendChart
                label={t("reverse.chart")}
                series={trend.length ? trend.filter((s) => s.stream === activeStream) : []}
                height={170}
              />
            </div>
          </div>
        </section>
      )}

      {/* programmes */}
      <section className="mt-10" aria-labelledby="progs-h">
        <h2 id="progs-h" className="text-lg font-extrabold">{t("detail.programmes")}</h2>
        <div className="card mt-3 overflow-x-auto">
          <table className="table-clean min-w-[560px]">
            <thead>
              <tr>
                <th>{t("detail.programmes")}</th>
                <th>{t("filters.level")}</th>
                <th>{t("compare.col.duration")}</th>
                <th>{t("detail.languages")}</th>
                <th>{t("compare.col.cost")}</th>
              </tr>
            </thead>
            <tbody>
              {progs.map((p) => (
                <tr key={p.id}>
                  <td className="font-semibold">{pick(p, "name", lang)}</td>
                  <td>{p.level}{p.seats !== null ? ` · ${fmtNum(p.seats)} ${t("seats")}` : ""}</td>
                  <td className="num">{fmtNum(p.durationYears)} {t(p.durationYears > 1 ? "duration.years" : "duration.year")}</td>
                  <td>{p.languages.map((l) => l.toUpperCase()).join(" · ")}</td>
                  <td className="num">{p.tuitionMAD === null ? t("notPublished") : `${fmtNum(p.tuitionMAD)} ${t("madYear")}`}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* thresholds */}
      {rule && (
        <section className="mt-10" aria-labelledby="th-h">
          <h2 id="th-h" className="flex items-center gap-2 text-lg font-extrabold">
            <FileText className="h-4.5 w-4.5 text-[var(--c-accent)]" />
            {t("detail.thresholds")}
          </h2>
          <p className="mt-1.5 text-[0.8rem] text-[var(--c-sub)]">{t("detail.thresholdsNote")}</p>
          <div className="card mt-3 overflow-x-auto">
            <table className="table-clean min-w-[560px]">
              <thead>
                <tr>
                  <th>{t("checker.stream")}</th>
                  {[2023, 2024, 2025].map((y) => (
                    <th key={y} className="num">{y}*</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {rule.streams.map((s) => {
                  const histPre = history(thresholdsOf(rule.id), rule.id, s, "preselection");
                  const histFin = history(thresholdsOf(rule.id), rule.id, s, "final");
                  const hist = histPre.length ? histPre : histFin;
                  const anyVal = hist.some((h) => h.value !== null);
                  return (
                    <tr key={s}>
                      <td className="font-semibold">{STREAMS.find((x) => x.key === s)?.[lang]}</td>
                      {[2023, 2024, 2025].map((y) => {
                        const rec = hist.find((h) => h.year === y) ?? null;
                        return (
                          <td key={y}>
                            {anyVal || rec ? (
                              <>
                                <ThresholdValue t={rec} />
                                {rec && <span className="ms-1 align-middle"><span className="tag tag-demo !text-[0.6rem]">{t("example.badge")}</span></span>}
                              </>
                            ) : (
                              <span className="text-[0.85rem] text-[var(--c-faint)]">{t("notPublished")}</span>
                            )}
                          </td>
                        );
                      })}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <div className="mt-3">
            <TrendChart label={t("detail.trend")} series={trend} />
          </div>
          <SourceNote sourceId={inst.sourceId} verifiedAt={inst.lastVerified} />
        </section>
      )}

      {/* how to apply + dates */}
      {rule && (
        <section className="mt-10 grid gap-5 sm:grid-cols-2">
          <div className="card p-5 sm:p-6">
            <h2 className="flex items-center gap-2 text-base font-extrabold">
              <MousePointerClick className="h-4.5 w-4.5 text-[var(--c-accent)]" />
              {t("detail.howToApply")}
            </h2>
            <ol className="mt-4 space-y-3">
              {(STEP_ORDER[rule.route] ?? []).map((step, i) => (
                <li key={step} className="flex items-start gap-3">
                  <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-[var(--c-accent-soft)] text-[0.78rem] font-extrabold text-[var(--c-accent)]">
                    {i + 1}
                  </span>
                  <div>
                    <p className="text-[0.9rem] font-bold">{t(step)}</p>
                    {i === 0 && (
                      <a
                        href={inst.website}
                        target="_blank"
                        rel="noreferrer"
                        className="mt-0.5 inline-flex items-center gap-1 text-[0.78rem] font-semibold text-[var(--c-accent)] underline-offset-2 hover:underline"
                      >
                        {t("detail.officialSite")} <ExternalLink className="h-3 w-3" />
                      </a>
                    )}
                  </div>
                </li>
              ))}
            </ol>
            <p className="mt-4 rounded-lg bg-[var(--c-raised)] p-3 text-[0.78rem] leading-relaxed text-[var(--c-sub)]">
              {pick(rule, "notes", lang)}
            </p>
          </div>

          <div className="card p-5 sm:p-6">
            <h2 className="flex items-center gap-2 text-base font-extrabold">
              <CalendarDays className="h-4.5 w-4.5 text-[var(--c-accent)]" />
              {t("detail.dates")}
            </h2>
            <ul className="mt-4 space-y-2.5">
              {(
                [
                  ["detail.opens", rule.registrationOpens],
                  ["deadline.label", rule.registrationDeadline],
                  ["detail.preselection", rule.preselectionDate],
                  ["detail.exam", rule.examDate],
                ] as const
              ).map(([label, iso]) =>
                iso ? (
                  <li key={label} className="flex items-center justify-between gap-3 border-b border-[var(--c-line)] pb-2.5 last:border-none">
                    <span className="flex items-center gap-2 text-[0.85rem] font-semibold text-[var(--c-sub)]">
                      <Timer className="h-3.5 w-3.5 text-[var(--c-faint)]" />
                      {t(label)}
                    </span>
                    <span className="num text-[0.88rem] font-bold">{fmtDate(iso)}</span>
                  </li>
                ) : null
              )}
            </ul>
            <div className="mt-4 border-t border-[var(--c-line)] pt-4">
              <h3 className="flex items-center gap-2 text-[0.82rem] font-extrabold">
                <Wallet className="h-4 w-4 text-[var(--c-accent)]" />
                {t("detail.costs")}
              </h3>
              <ul className="mt-2 space-y-1.5">
                {progs.map((p) => (
                  <li key={p.id} className="flex justify-between gap-3 text-[0.84rem]">
                    <span className="text-[var(--c-sub)]">{pick(p, "name", lang)}</span>
                    <span className="num font-bold">
                      {p.tuitionMAD === null ? t("notPublished") : `${fmtNum(p.tuitionMAD)} ${t("madYear")}`}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </section>
      )}

      {/* scholarships */}
      <section className="mt-10" aria-labelledby="sch-h">
        <h2 className="flex items-center gap-2 text-lg font-extrabold">
          <Award className="h-4.5 w-4.5 text-[var(--c-accent)]" />
          {t("detail.scholarships")}
        </h2>
        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          {scholarships.slice(0, 4).map((s) => (
            <div key={s.id} className="card p-4.5 sm:p-5">
              <p className="font-bold leading-snug">{pick(s, "name", lang)}</p>
              <p className="mt-1 text-[0.78rem] text-[var(--c-sub)]">{pick(s, "provider", lang)}</p>
              <p className="num mt-2 text-lg font-extrabold text-[var(--c-accent)]">
                {s.amountMAD !== null ? `${fmtNum(s.amountMAD)} ${t("madYear")}` : t("notPublished")}
              </p>
              <SourceNote sourceId={s.sourceId} verifiedAt={s.lastVerified} />
            </div>
          ))}
        </div>
        <Link to="/scholarships" className="mt-4 inline-flex items-center gap-1.5 text-[0.86rem] font-bold text-[var(--c-accent)]">
          {t("sch.matcher.title")}
          <LangIcon className="h-4 w-4 mirror-icon" />
        </Link>
      </section>

      {/* map */}
      <section className="mt-10" aria-labelledby="map-h">
        <h2 className="flex items-center gap-2 text-lg font-extrabold">
          <MapPin className="h-4.5 w-4.5 text-[var(--c-accent)]" />
          {t("detail.map")}
        </h2>
        <div className="card mt-3 overflow-hidden">
          <iframe
            title={`${pick(inst, "name", lang)} — ${t("detail.map")}`}
            src={osm}
            loading="lazy"
            className="h-64 w-full border-0 sm:h-80"
          />
          <div className="flex items-center justify-between gap-3 border-t border-[var(--c-line)] p-3.5">
            <p className="text-[0.8rem] text-[var(--c-sub)]">
              {pick(inst, "city", lang)} — © OpenStreetMap contributors
            </p>
            <a
              href={`https://www.openstreetmap.org/?mlat=${inst.lat}&mlon=${inst.lng}#map=14/${inst.lat}/${inst.lng}`}
              target="_blank"
              rel="noreferrer"
              className="btn btn-outline !min-h-[38px] px-3 py-1 text-[0.78rem]"
            >
              <Landmark className="h-3.5 w-3.5" />
              {t("map.open")}
            </a>
          </div>
        </div>
      </section>

      <div className="mt-10 flex flex-wrap items-center gap-4">
        <a href={inst.website} target="_blank" rel="noreferrer" className="btn btn-primary">
          {t("detail.officialSite")}
          <ExternalLink className="h-4 w-4" />
        </a>
        <ReportError contextLabel={pick(inst, "name", lang)} />
      </div>
      <p className="mt-6 text-[0.75rem] text-[var(--c-faint)]">* {t("verdict.lastYear")} — {t("legal.disclaimer")}</p>
    </article>
  );
}

function BookMarkedIcon() {
  return (
    <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <path d="M17 3a2 2 0 0 1 2 2v16l-7-4-7 4V5a2 2 0 0 1 2-2z" />
    </svg>
  );
}
