import { useEffect } from "react";
import { HashRouter, Route, Routes, useLocation } from "react-router-dom";
import { LangProvider } from "@/i18n";
import { Layout } from "@/components";
import Home from "@/pages/Home";
import Schools from "@/pages/Schools";
import SchoolDetail from "@/pages/SchoolDetail";
import Scholarships from "@/pages/Scholarships";
import Calendar from "@/pages/Calendar";
import Shortlist from "@/pages/Shortlist";
import Compare from "@/pages/Compare";
import Guides from "@/pages/Guides";
import Legal from "@/pages/Legal";
import Admin from "@/pages/Admin";

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior });
  }, [pathname]);
  return null;
}

function Routed() {
  useLocation();
  return (
    <Layout>
      <ScrollToTop />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/schools" element={<Schools />} />
        <Route path="/school/:id" element={<SchoolDetail />} />
        <Route path="/scholarships" element={<Scholarships />} />
        <Route path="/calendar" element={<Calendar />} />
        <Route path="/shortlist" element={<Shortlist />} />
        <Route path="/compare" element={<Compare />} />
        <Route path="/guides" element={<Guides />} />
        <Route path="/legal" element={<Legal />} />
        <Route path="/admin" element={<Admin />} />
        <Route path="*" element={<Home />} />
      </Routes>
    </Layout>
  );
}

export default function App() {
  return (
    <LangProvider>
      <HashRouter>
        <Routed />
      </HashRouter>
    </LangProvider>
  );
}
