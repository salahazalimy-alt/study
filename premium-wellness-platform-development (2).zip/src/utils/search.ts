import type { Institution } from "@/data/types";

/**
 * Darija-friendly search: accent/diacritic-insensitive, latin + arabic
 * scripts, and each institution carries hand-written aliases (ENSA/ensa/إنسا…).
 */
export function normalize(s: string): string {
  return s
    .toLowerCase()
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "") // latin diacritics
    .replace(/[ً-ْٰـ]/g, "") // arabic harakat + tatweel
    .replace(/[إأآ]/g, "ا")
    .replace(/ة/g, "ه")
    .replace(/[^\p{L}\p{N} ]/gu, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export function matchesInstitution(inst: Institution, query: string): boolean {
  const q = normalize(query);
  if (!q) return true;
  const hay = [
    inst.name_fr, inst.name_ar, inst.short_fr, inst.short_ar,
    inst.city_fr, inst.city_ar, inst.category_fr,
    ...inst.aliases,
  ]
    .map(normalize)
    .join(" | ");
  return q.split(" ").every((word) => hay.includes(word));
}

/** "fuzzy_contains" style matching for any list with fr/ar labels. */
export function matchesText(query: string, ...fields: string[]): boolean {
  const q = normalize(query);
  if (!q) return true;
  const hay = fields.map(normalize).join(" | ");
  return q.split(" ").every((w) => hay.includes(w));
}
